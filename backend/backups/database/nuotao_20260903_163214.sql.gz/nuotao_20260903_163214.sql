--
-- PostgreSQL database dump
--

\restrict U6O4pAJG8iTMJBNSK4vfNr709O8aPvFPSVj8dxjxpw9xz0hg30sX7KpoJf4n7io

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE nuotao;
--
-- Name: nuotao; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE nuotao WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Chinese (Simplified)_China.936';


\unrestrict U6O4pAJG8iTMJBNSK4vfNr709O8aPvFPSVj8dxjxpw9xz0hg30sX7KpoJf4n7io
\connect nuotao
\restrict U6O4pAJG8iTMJBNSK4vfNr709O8aPvFPSVj8dxjxpw9xz0hg30sX7KpoJf4n7io

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_plans (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    activity_type character varying(32) DEFAULT 'other'::character varying NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    budget_total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    budget_currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    target_revenue numeric(12,2),
    target_orders integer,
    target_roas numeric(8,2),
    plan_json json DEFAULT '{}'::json NOT NULL,
    status character varying(16) DEFAULT 'draft'::character varying NOT NULL,
    approval_status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    created_by character varying(64),
    approved_by character varying(64),
    approved_at timestamp with time zone,
    reject_reason character varying(2000),
    parent_plan_id uuid,
    version integer DEFAULT 1 NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_alerts (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid,
    alert_type character varying(32) NOT NULL,
    status character varying(16) NOT NULL,
    severity character varying(8) NOT NULL,
    resource character varying(128) NOT NULL,
    dedup_key character varying(255) NOT NULL,
    message character varying(500),
    metadata_ json NOT NULL,
    threshold_snapshot json NOT NULL,
    ack_by character varying(64),
    ack_at timestamp with time zone,
    resolved_by character varying(64),
    resolved_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_approval_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_approval_roles (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    role_name character varying(64) NOT NULL,
    permissions json NOT NULL,
    actors json NOT NULL,
    enabled boolean NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_approval_slas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_approval_slas (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    approval_type character varying(32) NOT NULL,
    warning_after_seconds integer NOT NULL,
    expire_after_seconds integer NOT NULL,
    enabled boolean NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_approvals (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    approval_type character varying(32) NOT NULL,
    status character varying(16) NOT NULL,
    entity_type character varying(64) NOT NULL,
    entity_id character varying(64) NOT NULL,
    target_task_id uuid,
    agent_id uuid,
    actor character varying(64),
    action character varying(16),
    note character varying(500),
    metadata_ json NOT NULL,
    decided_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sla_warning_at timestamp with time zone,
    expires_at timestamp with time zone
);


--
-- Name: agent_budget_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_budget_policies (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid,
    policy_version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    is_current boolean DEFAULT true NOT NULL,
    monthly_budget numeric(12,2) DEFAULT '100'::numeric NOT NULL,
    max_cost_per_execution numeric(12,6) DEFAULT '5'::numeric NOT NULL,
    alert_threshold numeric(4,3) DEFAULT 0.8 NOT NULL,
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_evaluations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_evaluations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid,
    prediction jsonb DEFAULT '{}'::jsonb NOT NULL,
    actual_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    accuracy jsonb DEFAULT '{}'::jsonb NOT NULL,
    calibration jsonb DEFAULT '{}'::jsonb NOT NULL,
    prediction_result character varying(16),
    error_type character varying(32),
    success_flag boolean,
    confidence numeric(6,4),
    confidence_bucket character varying(8),
    human_rating integer,
    notes character varying(500),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_execution_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_execution_policies (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid,
    policy_version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    is_current boolean DEFAULT true NOT NULL,
    max_concurrent integer DEFAULT 3 NOT NULL,
    execution_timeout_seconds integer DEFAULT 300 NOT NULL,
    approval_timeout_seconds integer DEFAULT 86400 NOT NULL,
    max_context_size integer DEFAULT 20000 NOT NULL,
    retry_policy_id character varying(64) DEFAULT 'standard'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_executions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid,
    task_id uuid,
    context_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    input jsonb DEFAULT '{}'::jsonb NOT NULL,
    output jsonb DEFAULT '{}'::jsonb NOT NULL,
    provider character varying(32),
    model character varying(64),
    tokens jsonb DEFAULT '{}'::jsonb NOT NULL,
    cost numeric(12,6),
    latency_ms integer,
    tool_calls jsonb DEFAULT '[]'::jsonb NOT NULL,
    status character varying(16) DEFAULT 'running'::character varying NOT NULL,
    error_message character varying(1000),
    approval jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    approval_deadline timestamp with time zone,
    error_type character varying(32),
    worker_id character varying(64),
    attempt_number integer DEFAULT 1 NOT NULL
);


--
-- Name: agent_memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_memory (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid,
    domain character varying(32) NOT NULL,
    source_type character varying(32) NOT NULL,
    source_id character varying(64),
    content character varying(4000) NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_metrics (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid,
    metric_date date NOT NULL,
    executions_count integer DEFAULT 0 NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    failure_count integer DEFAULT 0 NOT NULL,
    timeout_count integer DEFAULT 0 NOT NULL,
    retried_count integer DEFAULT 0 NOT NULL,
    total_tokens integer DEFAULT 0 NOT NULL,
    total_cost numeric(12,6) DEFAULT '0'::numeric NOT NULL,
    avg_latency_ms numeric(12,2),
    p95_latency_ms integer,
    error_breakdown jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_retry_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_retry_policies (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    retry_policy_id character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    is_current boolean DEFAULT true NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    backoff_base_seconds integer DEFAULT 2 NOT NULL,
    backoff_multiplier numeric(4,2) DEFAULT '2'::numeric NOT NULL,
    max_backoff_seconds integer DEFAULT 60 NOT NULL,
    retry_on_error_types jsonb DEFAULT '["llm", "timeout", "network", "transient"]'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_task_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_task_attempts (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    task_id uuid,
    execution_id uuid,
    attempt_number integer DEFAULT 1 NOT NULL,
    status character varying(16) NOT NULL,
    error_type character varying(32),
    error_message character varying(1000),
    latency_ms integer,
    worker_id character varying(64),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_tasks (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid,
    input jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    priority integer DEFAULT 3 NOT NULL,
    result jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_message character varying(1000),
    trace_id character varying(64),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    enqueued_at timestamp with time zone,
    idempotency_key character varying(128)
);


--
-- Name: agent_tools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_tools (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    tool_name character varying(64) NOT NULL,
    description character varying(500),
    permission_level character varying(8) DEFAULT 'L1'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    category character varying(32),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    handler_name character varying(64),
    args_schema jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: agent_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_versions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    version character varying(16) NOT NULL,
    prompt_name character varying(64),
    prompt_version character varying(16) NOT NULL,
    config_snapshot json NOT NULL,
    model_config json NOT NULL,
    execution_policy_version character varying(32) NOT NULL,
    retry_policy_version character varying(32) NOT NULL,
    budget_policy_version character varying(32) NOT NULL,
    status character varying(16) NOT NULL,
    created_by character varying(64),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    agent_id character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    domain character varying(32) NOT NULL,
    version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    model_provider character varying(32) DEFAULT 'openai'::character varying NOT NULL,
    model_name character varying(64) DEFAULT 'gpt-4o-mini'::character varying NOT NULL,
    prompt_version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    permission_level character varying(8) DEFAULT 'L1'::character varying NOT NULL,
    description character varying(500),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    current_version character varying(16)
);


--
-- Name: ai_agent_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_agent_runs (
    id bigint NOT NULL,
    workspace_id uuid NOT NULL,
    agent character varying(64) NOT NULL,
    trigger character varying(128),
    input jsonb DEFAULT '{}'::jsonb NOT NULL,
    plan jsonb DEFAULT '{}'::jsonb NOT NULL,
    tool_calls jsonb DEFAULT '[]'::jsonb NOT NULL,
    output jsonb DEFAULT '{}'::jsonb NOT NULL,
    approval jsonb DEFAULT '{}'::jsonb NOT NULL,
    cost numeric(12,6),
    status character varying(24) DEFAULT 'pending'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: ai_agent_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_agent_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_agent_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_agent_runs_id_seq OWNED BY public.ai_agent_runs.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: business_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_recommendations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    domain character varying(32) NOT NULL,
    entity_type character varying(64) NOT NULL,
    entity_id character varying(64) NOT NULL,
    recommendation character varying(255) NOT NULL,
    reason character varying(2000),
    confidence numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    status character varying(16) DEFAULT 'proposed'::character varying NOT NULL,
    approved_by character varying(64),
    approved_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: campaign_ai_evaluations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaign_ai_evaluations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    campaign_id uuid,
    prediction jsonb DEFAULT '{}'::jsonb NOT NULL,
    actual_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    accuracy jsonb DEFAULT '{}'::jsonb NOT NULL,
    prediction_result character varying(16),
    error_type character varying(32),
    confidence numeric(6,4),
    confidence_bucket character varying(8),
    success_flag boolean,
    metric_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    human_rating integer,
    notes character varying(500),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaigns (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    platform character varying(16) NOT NULL,
    campaign_id character varying(128) NOT NULL,
    name character varying(255),
    product_id uuid,
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    budget numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    spend numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    impressions bigint DEFAULT '0'::bigint NOT NULL,
    clicks bigint DEFAULT '0'::bigint NOT NULL,
    ctr numeric(8,6),
    cpc numeric(12,4),
    conversion bigint DEFAULT '0'::bigint NOT NULL,
    revenue numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    roas numeric(10,4),
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: confidence_calibration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.confidence_calibration (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    bucket character varying(8) NOT NULL,
    sample_count integer DEFAULT 0 NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    success_rate numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    avg_confidence numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: connector_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    connector_name character varying(64) NOT NULL,
    status character varying(16) DEFAULT 'running'::character varying NOT NULL,
    records_count integer DEFAULT 0 NOT NULL,
    error_message character varying(1000),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: creative_analysis_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.creative_analysis_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    creative_id uuid,
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    analysis_output jsonb DEFAULT '{}'::jsonb NOT NULL,
    performance_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    model_version character varying(32) NOT NULL,
    status character varying(16) DEFAULT 'completed'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: creative_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.creative_assets (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    platform character varying(16) DEFAULT 'meta'::character varying NOT NULL,
    asset_type character varying(24) DEFAULT 'image'::character varying NOT NULL,
    reference character varying(1024),
    hook character varying(500),
    angle character varying(255),
    copy character varying(2000),
    performance_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(16) DEFAULT 'draft'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_ai_evaluations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_ai_evaluations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    customer_id uuid,
    prediction jsonb DEFAULT '{}'::jsonb NOT NULL,
    actual_behavior jsonb DEFAULT '{}'::jsonb NOT NULL,
    accuracy jsonb DEFAULT '{}'::jsonb NOT NULL,
    prediction_result character varying(16),
    error_type character varying(32),
    confidence numeric(6,4),
    confidence_bucket character varying(8),
    success_flag boolean,
    metric_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    human_rating integer,
    notes character varying(500),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_calibration_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_calibration_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    status character varying(16) DEFAULT 'proposed'::character varying NOT NULL,
    model_version character varying(32) NOT NULL,
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    successful_patterns jsonb DEFAULT '{}'::jsonb NOT NULL,
    failure_patterns jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    sample_size integer DEFAULT 0 NOT NULL,
    rationale character varying(2000),
    approved_by character varying(64),
    approved_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_feedback (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    source character varying(24) DEFAULT 'other'::character varying NOT NULL,
    content character varying(4000) NOT NULL,
    sentiment character varying(16) DEFAULT 'unknown'::character varying NOT NULL,
    issue_type character varying(32),
    rating integer,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_interactions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    customer_id uuid,
    product_id uuid,
    channel character varying(16) DEFAULT 'other'::character varying NOT NULL,
    interaction_type character varying(32) DEFAULT 'message'::character varying NOT NULL,
    content character varying(4000) NOT NULL,
    sentiment character varying(16) DEFAULT 'unknown'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_knowledge_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_knowledge_entries (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    customer_id uuid,
    product_id uuid,
    category character varying(64),
    entry_type character varying(32) DEFAULT 'purchase_pattern'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    content character varying(4000) NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    source character varying(32) DEFAULT 'manual'::character varying NOT NULL,
    confidence numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_pattern_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_pattern_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    customer_id uuid,
    pattern_type character varying(32) NOT NULL,
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_pattern jsonb DEFAULT '{}'::jsonb NOT NULL,
    confidence numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    sample_size integer DEFAULT 0 NOT NULL,
    status character varying(16) DEFAULT 'completed'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_profiles (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    customer_reference_id character varying(128) NOT NULL,
    country character varying(8),
    language character varying(8),
    segment character varying(32),
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    first_order_at timestamp with time zone,
    total_orders integer DEFAULT 0 NOT NULL,
    total_revenue numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_log (
    id bigint NOT NULL,
    workspace_id uuid NOT NULL,
    event_type character varying(128) NOT NULL,
    entity_type character varying(64) NOT NULL,
    entity_id character varying(64) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.event_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.event_log_id_seq OWNED BY public.event_log.id;


--
-- Name: image_generation_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.image_generation_tasks (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    prompt character varying(4000) NOT NULL,
    negative_prompt character varying(2000),
    use_case character varying(32) DEFAULT 'main_image'::character varying NOT NULL,
    requested_model character varying(64) DEFAULT 'wan2.7-image'::character varying NOT NULL,
    actual_model character varying(64),
    width integer DEFAULT 1024 NOT NULL,
    height integer DEFAULT 1024 NOT NULL,
    status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    image_url character varying(2048),
    image_path character varying(1024),
    cost_cny numeric(10,4) DEFAULT '0'::numeric NOT NULL,
    error_message character varying(2000),
    retry_count integer DEFAULT 0 NOT NULL,
    metadata json DEFAULT '{}'::json NOT NULL,
    approved_by character varying(64),
    approved_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: influencer_collaborations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.influencer_collaborations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    influencer_id uuid NOT NULL,
    activity_plan_id uuid,
    collab_type character varying(32) DEFAULT 'product_seeding'::character varying NOT NULL,
    compensation_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    compensation_currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    commission_rate numeric(5,2),
    content_requirements character varying(2000),
    content_url character varying(2048),
    metrics_json json DEFAULT '{}'::json NOT NULL,
    status character varying(16) DEFAULT 'prospecting'::character varying NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    notes character varying(2000),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: influencers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.influencers (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255),
    platform character varying(32) DEFAULT 'instagram'::character varying NOT NULL,
    profile_url character varying(2048),
    followers integer DEFAULT 0 NOT NULL,
    engagement_rate numeric(8,4),
    avg_views integer,
    category character varying(128),
    region character varying(64),
    language character varying(32),
    contact_email character varying(255),
    contact_info json DEFAULT '{}'::json NOT NULL,
    rating numeric(3,1),
    notes character varying(2000),
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_snapshots (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    location character varying(32) DEFAULT 'cn'::character varying NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    reserved integer DEFAULT 0 NOT NULL,
    available integer DEFAULT 0 NOT NULL,
    in_transit integer DEFAULT 0 NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    snapshot_time timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_inventory_location CHECK (((location)::text = ANY ((ARRAY['cn'::character varying, 'us'::character varying, 'eu'::character varying])::text[])))
);


--
-- Name: logistics_ai_evaluations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logistics_ai_evaluations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    shipment_id uuid,
    carrier character varying(64),
    route character varying(255),
    prediction jsonb DEFAULT '{}'::jsonb NOT NULL,
    actual_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    delay_reason character varying(500),
    accuracy jsonb DEFAULT '{}'::jsonb NOT NULL,
    prediction_result character varying(16),
    error_type character varying(32),
    confidence numeric(6,4),
    confidence_bucket character varying(8),
    success_flag boolean,
    metric_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    human_rating integer,
    notes character varying(500),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: logistics_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logistics_events (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    shipment_id uuid,
    event_type character varying(32) NOT NULL,
    location character varying(128),
    description character varying(500),
    occurred_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: logistics_pattern_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logistics_pattern_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    shipment_id uuid,
    carrier character varying(64),
    pattern_type character varying(32) NOT NULL,
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_pattern jsonb DEFAULT '{}'::jsonb NOT NULL,
    confidence numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    sample_size integer DEFAULT 0 NOT NULL,
    status character varying(16) DEFAULT 'completed'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketing_calibration_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marketing_calibration_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    status character varying(16) DEFAULT 'proposed'::character varying NOT NULL,
    model_version character varying(32) NOT NULL,
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    successful_patterns jsonb DEFAULT '{}'::jsonb NOT NULL,
    failure_patterns jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    sample_size integer DEFAULT 0 NOT NULL,
    rationale character varying(2000),
    approved_by character varying(64),
    approved_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketing_experiments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marketing_experiments (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    name character varying(255),
    hypothesis character varying(2000) NOT NULL,
    status character varying(16) DEFAULT 'proposed'::character varying NOT NULL,
    variant_a jsonb DEFAULT '{}'::jsonb NOT NULL,
    variant_b jsonb DEFAULT '{}'::jsonb NOT NULL,
    result jsonb DEFAULT '{}'::jsonb NOT NULL,
    calibration jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketing_knowledge_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marketing_knowledge_entries (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    campaign_id uuid,
    creative_id uuid,
    category character varying(64),
    entry_type character varying(32) DEFAULT 'creative_pattern'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    content character varying(4000) NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    source character varying(32) DEFAULT 'manual'::character varying NOT NULL,
    confidence numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    order_id uuid NOT NULL,
    external_item_id character varying(64),
    product_id uuid,
    sku character varying(64),
    name character varying(255) NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    line_total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    external_order_id character varying(64) NOT NULL,
    status character varying(24) DEFAULT 'received'::character varying NOT NULL,
    payment_status character varying(24),
    fulfillment_status character varying(24),
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    country character varying(8),
    payment_method character varying(32),
    source character varying(32) DEFAULT 'woocommerce'::character varying NOT NULL,
    subtotal numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    shipping_total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    discount_total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    payment_fee numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    refunded_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    advertising_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    profit_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    rule_results jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_reference_id character varying(128)
);


--
-- Name: product_ai_evaluations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_ai_evaluations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    analysis_run_id uuid,
    experiment_id uuid,
    prediction jsonb DEFAULT '{}'::jsonb NOT NULL,
    actual_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    accuracy jsonb DEFAULT '{}'::jsonb NOT NULL,
    human_rating integer,
    notes character varying(500),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    prediction_result character varying(16),
    error_type character varying(32),
    confidence_bucket character varying(8),
    success_flag boolean,
    metric_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: product_analysis_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_analysis_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    provider character varying(32) NOT NULL,
    model character varying(64) NOT NULL,
    prompt_version character varying(32),
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    output jsonb DEFAULT '{}'::jsonb NOT NULL,
    token_usage jsonb DEFAULT '{}'::jsonb NOT NULL,
    estimated_cost numeric(12,6) DEFAULT '0'::numeric NOT NULL,
    latency_ms integer DEFAULT 0 NOT NULL,
    status character varying(16) DEFAULT 'completed'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_cost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_cost (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid NOT NULL,
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    purchase_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    domestic_shipping numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    first_leg_shipping numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    last_leg_shipping numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    payment_fee numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    marketing_amortization numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    after_sales_loss numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    notes jsonb DEFAULT '{}'::jsonb NOT NULL,
    international_shipping numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    packaging numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_estimate numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    handling numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_landed_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    version character varying(16) DEFAULT 'v1'::character varying NOT NULL
);


--
-- Name: product_cost_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_cost_snapshots (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid NOT NULL,
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    purchase_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    domestic_shipping numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    first_leg_shipping numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    last_leg_shipping numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    payment_fee numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    marketing_amortization numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    after_sales_loss numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    weight_kg numeric(8,3),
    source character varying(32) DEFAULT 'manual'::character varying NOT NULL,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    international_shipping numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    packaging numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_estimate numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    handling numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_landed_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    version character varying(16) DEFAULT 'v1'::character varying NOT NULL
);


--
-- Name: product_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_decisions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid NOT NULL,
    decision character varying(16) NOT NULL,
    score numeric(6,2),
    confidence numeric(4,3),
    reasons jsonb DEFAULT '[]'::jsonb NOT NULL,
    risks jsonb DEFAULT '[]'::jsonb NOT NULL,
    recommended_price numeric(12,2),
    max_cac numeric(12,2),
    test_quantity integer,
    test_days integer,
    approval_status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    approved_by character varying(64),
    approved_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_experiments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_experiments (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid NOT NULL,
    experiment_type character varying(32) DEFAULT 'market_test'::character varying NOT NULL,
    status character varying(16) DEFAULT 'proposed'::character varying NOT NULL,
    prediction jsonb DEFAULT '{}'::jsonb NOT NULL,
    experiment jsonb DEFAULT '{}'::jsonb NOT NULL,
    actual_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    calibration jsonb DEFAULT '{}'::jsonb NOT NULL,
    version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    decision_id uuid,
    hypothesis character varying(2000),
    expected_metrics json,
    baseline json,
    target_metrics json,
    source_trace_id character varying(64),
    approved_by character varying(64),
    approved_at timestamp with time zone,
    started_by character varying(64),
    result_history json
);


--
-- Name: product_knowledge_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_knowledge_entries (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    category character varying(64),
    entry_type character varying(32) DEFAULT 'category_insight'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    content character varying(4000) NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    source character varying(32) DEFAULT 'manual'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_reviews (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    platform character varying(16) DEFAULT 'other'::character varying NOT NULL,
    rating integer DEFAULT 5 NOT NULL,
    content character varying(4000) NOT NULL,
    sentiment character varying(16) DEFAULT 'unknown'::character varying NOT NULL,
    issue_type character varying(32),
    keywords jsonb DEFAULT '[]'::jsonb NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_score_evidences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_score_evidences (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_score_id uuid NOT NULL,
    dimension character varying(32) NOT NULL,
    score numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    source character varying(64) NOT NULL,
    evidence jsonb DEFAULT '[]'::jsonb NOT NULL,
    confidence numeric(4,3) DEFAULT '0'::numeric NOT NULL,
    version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_scores (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid NOT NULL,
    profit numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    logistics numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    demand numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    competition numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    differentiation numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    compliance numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    total numeric(6,2) DEFAULT '0'::numeric NOT NULL,
    model_version character varying(32) NOT NULL,
    rule_version character varying(32) NOT NULL,
    scored_at timestamp with time zone DEFAULT now() NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_sources (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    source_type character varying(16) NOT NULL,
    source_url character varying(512),
    supplier_id uuid,
    supplier_code character varying(64),
    captured_at timestamp with time zone DEFAULT now() NOT NULL,
    raw_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_sourcing_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_sourcing_candidates (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    supplier_id uuid,
    supplier_code character varying(64),
    source_type character varying(16) DEFAULT '1688'::character varying NOT NULL,
    source_url character varying(512),
    title character varying(255),
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    purchase_price numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    moq integer,
    lead_time_days integer,
    trend_score numeric(4,2),
    profit_model jsonb DEFAULT '{}'::jsonb NOT NULL,
    notes character varying(500),
    version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_validation_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_validation_cases (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid,
    category character varying(128),
    source character varying(32) NOT NULL,
    run_id uuid,
    trace_id character varying(64),
    notes character varying(1000),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_product_validation_cases_source CHECK (((source)::text = ANY ((ARRAY['staging_real'::character varying, 'staging_synthetic'::character varying])::text[])))
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    sku character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(2000),
    category character varying(128),
    brand character varying(128),
    status character varying(24) DEFAULT 'draft'::character varying NOT NULL,
    source character varying(32) DEFAULT 'manual'::character varying NOT NULL,
    source_url character varying(512),
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    weight_kg numeric(8,3),
    dimensions jsonb,
    target_market character varying(16) DEFAULT 'US'::character varying NOT NULL,
    candidate_status character varying(16)
);


--
-- Name: prompts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompts (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    prompt_id character varying(64) NOT NULL,
    name character varying(64) NOT NULL,
    version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    template character varying(12000) NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb NOT NULL,
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    description character varying(500),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_items (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    purchase_order_id uuid NOT NULL,
    product_id uuid,
    sku character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    line_total numeric(12,2) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    po_number character varying(64) NOT NULL,
    supplier_id uuid,
    status character varying(16) DEFAULT 'draft'::character varying NOT NULL,
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    subtotal numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    shipping_cost numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    expected_delivery_at timestamp with time zone,
    received_at timestamp with time zone,
    notes character varying(1000),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: refund_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refund_cases (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    order_id uuid,
    product_id uuid,
    reason character varying(500) NOT NULL,
    category character varying(32) DEFAULT 'other'::character varying NOT NULL,
    amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    resolution character varying(32),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_id uuid
);


--
-- Name: rule_execution_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_execution_logs (
    id bigint NOT NULL,
    workspace_id uuid NOT NULL,
    rule_id character varying(64) NOT NULL,
    rule_version character varying(16) NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    result jsonb DEFAULT '{}'::jsonb NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rule_execution_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rule_execution_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rule_execution_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rule_execution_logs_id_seq OWNED BY public.rule_execution_logs.id;


--
-- Name: rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rules (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    rule_id character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(64) NOT NULL,
    rule_type character varying(16) DEFAULT 'hard'::character varying NOT NULL,
    version character varying(16) DEFAULT 'v1'::character varying NOT NULL,
    status character varying(16) DEFAULT 'draft'::character varying NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    when_conditions jsonb NOT NULL,
    then_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    approval_level character varying(8) DEFAULT 'L0'::character varying NOT NULL,
    owner character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: score_calibration_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.score_calibration_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    status character varying(16) DEFAULT 'proposed'::character varying NOT NULL,
    model_version character varying(32) NOT NULL,
    current_weights jsonb DEFAULT '{}'::jsonb NOT NULL,
    suggested_weights jsonb DEFAULT '{}'::jsonb NOT NULL,
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    sample_size integer DEFAULT 0 NOT NULL,
    rationale character varying(2000),
    approved_by character varying(64),
    approved_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shipment_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipment_records (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    purchase_order_id uuid,
    carrier character varying(64) NOT NULL,
    origin character varying(128),
    destination character varying(128),
    tracking_number character varying(128),
    status character varying(16) DEFAULT 'created'::character varying NOT NULL,
    ship_date timestamp with time zone,
    delivery_time_days integer,
    delay_reason character varying(500),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: supplier_ai_evaluations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_ai_evaluations (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    supplier_id uuid,
    prediction jsonb DEFAULT '{}'::jsonb NOT NULL,
    actual_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    accuracy jsonb DEFAULT '{}'::jsonb NOT NULL,
    prediction_result character varying(16),
    error_type character varying(32),
    confidence numeric(6,4),
    confidence_bucket character varying(8),
    success_flag boolean,
    metric_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    human_rating integer,
    notes character varying(500),
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: supplier_pattern_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_pattern_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    supplier_id uuid,
    pattern_type character varying(32) NOT NULL,
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_pattern jsonb DEFAULT '{}'::jsonb NOT NULL,
    confidence numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    sample_size integer DEFAULT 0 NOT NULL,
    status character varying(16) DEFAULT 'completed'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: supplier_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_profiles (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    supplier_id uuid,
    category character varying(64),
    location character varying(128),
    lead_time_days integer,
    minimum_order_qty integer,
    quality_score numeric(5,2),
    on_time_rate numeric(5,2),
    defect_rate numeric(5,2),
    certifications jsonb DEFAULT '[]'::jsonb NOT NULL,
    risk_level character varying(16) DEFAULT 'low'::character varying NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    factory_type character varying(32)
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    platform character varying(32) DEFAULT '1688'::character varying NOT NULL,
    shop_url character varying(512),
    rating character varying(8) DEFAULT 'C'::character varying NOT NULL,
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    contact jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: supply_chain_calibration_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_chain_calibration_runs (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    status character varying(16) DEFAULT 'proposed'::character varying NOT NULL,
    model_version character varying(32) NOT NULL,
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    successful_patterns jsonb DEFAULT '{}'::jsonb NOT NULL,
    failure_patterns jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    sample_size integer DEFAULT 0 NOT NULL,
    rationale character varying(2000),
    approved_by character varying(64),
    approved_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: supply_chain_knowledge_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_chain_knowledge_entries (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    supplier_id uuid,
    product_id uuid,
    category character varying(64),
    entry_type character varying(32) DEFAULT 'supplier_pattern'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    content character varying(4000) NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    source character varying(32) DEFAULT 'manual'::character varying NOT NULL,
    confidence numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255),
    full_name character varying(100),
    hashed_password character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: woocommerce_draft_payloads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.woocommerce_draft_payloads (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    product_id uuid NOT NULL,
    sku character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    payload json NOT NULL,
    status character varying(24) DEFAULT 'generated'::character varying NOT NULL,
    created_by character varying(64),
    approved_by character varying(64),
    approved_at timestamp with time zone,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_identity_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_identity_links (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    organization_id character varying(128) NOT NULL,
    role character varying(64),
    mapping_metadata json,
    enabled boolean DEFAULT true NOT NULL,
    trace_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspaces (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    code character varying(32) NOT NULL,
    market character varying(16) DEFAULT 'US'::character varying NOT NULL,
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_agent_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_runs ALTER COLUMN id SET DEFAULT nextval('public.ai_agent_runs_id_seq'::regclass);


--
-- Name: event_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_log ALTER COLUMN id SET DEFAULT nextval('public.event_log_id_seq'::regclass);


--
-- Name: rule_execution_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_execution_logs ALTER COLUMN id SET DEFAULT nextval('public.rule_execution_logs_id_seq'::regclass);


--
-- Data for Name: activity_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_plans (id, workspace_id, name, activity_type, start_date, end_date, budget_total, budget_currency, target_revenue, target_orders, target_roas, plan_json, status, approval_status, created_by, approved_by, approved_at, reject_reason, parent_plan_id, version, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_alerts (id, workspace_id, agent_id, alert_type, status, severity, resource, dedup_key, message, metadata_, threshold_snapshot, ack_by, ack_at, resolved_by, resolved_at, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_approval_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_approval_roles (id, workspace_id, role_name, permissions, actors, enabled, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_approval_slas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_approval_slas (id, workspace_id, approval_type, warning_after_seconds, expire_after_seconds, enabled, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_approvals (id, workspace_id, approval_type, status, entity_type, entity_id, target_task_id, agent_id, actor, action, note, metadata_, decided_at, trace_id, created_at, updated_at, sla_warning_at, expires_at) FROM stdin;
\.


--
-- Data for Name: agent_budget_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_budget_policies (id, workspace_id, agent_id, policy_version, is_current, monthly_budget, max_cost_per_execution, alert_threshold, currency, enabled, trace_id, created_at, updated_at) FROM stdin;
f1f0b35c-2bca-499f-98b5-22f3856d3c47	00000000-0000-0000-0000-000000000001	a3fad7ef-29a4-46bd-b214-041219b14fae	v1	t	100.00	5.000000	0.800	USD	t	\N	2026-09-01 16:54:35.025751+08	2026-09-01 16:54:35.025751+08
d72e8f31-be70-4e82-80ff-47886821fbb4	00000000-0000-0000-0000-000000000001	1fc7cdf9-95a8-428e-a1a1-3687715096c8	v1	t	100.00	5.000000	0.800	USD	t	\N	2026-09-01 17:33:58.706783+08	2026-09-01 17:33:58.706783+08
7057a28a-240d-48b0-8970-a36ae2d08ffa	00000000-0000-0000-0000-000000000001	af2b809c-064b-40f1-9e86-6898e6d3d3af	v1	t	100.00	5.000000	0.800	USD	t	\N	2026-09-01 17:33:58.728087+08	2026-09-01 17:33:58.728087+08
db812037-5890-4407-b37d-6e8efa83ec83	00000000-0000-0000-0000-000000000001	00625f0b-7d33-4a39-bb05-a5e89bf4b4a9	v1	t	100.00	5.000000	0.800	USD	t	\N	2026-09-01 17:34:28.747985+08	2026-09-01 17:34:28.747985+08
e5c9a8ad-0c87-4430-8791-355f875d41c4	00000000-0000-0000-0000-000000000001	8f56d048-b527-4f8a-bdff-ed4a54cf1bc2	v1	t	100.00	5.000000	0.800	USD	t	\N	2026-09-01 17:34:28.769581+08	2026-09-01 17:34:28.769581+08
\.


--
-- Data for Name: agent_evaluations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_evaluations (id, workspace_id, agent_id, prediction, actual_result, accuracy, calibration, prediction_result, error_type, success_flag, confidence, confidence_bucket, human_rating, notes, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: agent_execution_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_execution_policies (id, workspace_id, agent_id, policy_version, is_current, max_concurrent, execution_timeout_seconds, approval_timeout_seconds, max_context_size, retry_policy_id, enabled, trace_id, created_at, updated_at) FROM stdin;
107df8bb-a425-4d66-88d0-7ad1a1dc14e7	00000000-0000-0000-0000-000000000001	a3fad7ef-29a4-46bd-b214-041219b14fae	v1	t	3	300	86400	20000	standard	t	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:11.449752+08	2026-09-01 17:30:11.449752+08
\.


--
-- Data for Name: agent_executions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_executions (id, workspace_id, agent_id, task_id, context_snapshot, input, output, provider, model, tokens, cost, latency_ms, tool_calls, status, error_message, approval, trace_id, started_at, completed_at, created_at, updated_at, approval_deadline, error_type, worker_id, attempt_number) FROM stdin;
8eb8e2cc-ed4f-4122-a33c-649e66c9e77e	00000000-0000-0000-0000-000000000001	a3fad7ef-29a4-46bd-b214-041219b14fae	6c21aa38-0b1a-4c14-868e-6dd31c8dc133	{"domain": "product", "version": "v1", "agent_id": "product_analyst", "agent_name": "Product Analyst", "model_name": "deepseek-chat", "model_provider": "deepseek", "prompt_version": "v1", "permission_level": "L1"}	{"product_id": "bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2"}	{"key_risks": ["seasonal demand", "potential supply chain issues"], "key_strengths": ["durable material", "lightweight design", "versatile use"], "target_market": "outdoor enthusiasts, campers, hikers", "recommendation": "needs_more_research", "analysis_summary": "The product shows moderate market potential with a balanced competition level. Further research is needed to validate cost assumptions and market demand.", "market_potential": "medium", "competition_level": "medium", "recommended_price": 49.99, "profit_margin_estimate": "40%"}	deepseek	deepseek-chat	{"total_tokens": 430, "prompt_tokens": 293, "completion_tokens": 137}	0.000230	2240	[]	completed	\N	{}	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:11.480992+08	2026-09-01 17:30:13.743667+08	2026-09-01 17:30:11.463823+08	2026-09-01 17:30:11.498132+08	\N	\N	worker-1	1
1d3a7c30-a6dd-49dd-b3eb-0be54f074188	00000000-0000-0000-0000-000000000001	a3fad7ef-29a4-46bd-b214-041219b14fae	ac80eca0-156c-4158-81f3-5825a83c58a5	{"domain": "product", "version": "v1", "agent_id": "product_analyst", "agent_name": "Product Analyst", "model_name": "deepseek-chat", "model_provider": "deepseek", "prompt_version": "v1", "permission_level": "L1"}	{"product_id": "bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2"}	{"key_risks": ["seasonal demand", "supply chain variability", "potential quality control issues"], "key_strengths": ["durable material", "lightweight design", "versatile use"], "target_market": "outdoor enthusiasts, campers, hikers", "recommendation": "needs_more_research", "analysis_summary": "The product shows moderate market potential with a competitive landscape. Further research is needed to validate supplier reliability and consumer demand trends before approval.", "market_potential": "medium", "competition_level": "medium", "recommended_price": 49.99, "profit_margin_estimate": "40%"}	deepseek	deepseek-chat	{"total_tokens": 448, "prompt_tokens": 293, "completion_tokens": 155}	0.000250	2473	[]	completed	\N	{}	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:14.380773+08	2026-09-01 17:35:16.868495+08	2026-09-01 17:35:14.373556+08	2026-09-01 17:35:14.39137+08	\N	\N	worker-1	1
\.


--
-- Data for Name: agent_memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_memory (id, workspace_id, agent_id, domain, source_type, source_id, content, tags, meta, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_metrics (id, workspace_id, agent_id, metric_date, executions_count, success_count, failure_count, timeout_count, retried_count, total_tokens, total_cost, avg_latency_ms, p95_latency_ms, error_breakdown, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_retry_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_retry_policies (id, workspace_id, retry_policy_id, name, version, is_current, max_attempts, backoff_base_seconds, backoff_multiplier, max_backoff_seconds, retry_on_error_types, enabled, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_task_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_task_attempts (id, workspace_id, task_id, execution_id, attempt_number, status, error_type, error_message, latency_ms, worker_id, trace_id, created_at) FROM stdin;
07da369d-8850-4145-b539-bb432a9a58a6	00000000-0000-0000-0000-000000000001	6c21aa38-0b1a-4c14-868e-6dd31c8dc133	\N	1	running	\N		\N	worker-1	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:11.463823+08
70a1b53a-5139-4965-9592-405c774b7f89	00000000-0000-0000-0000-000000000001	6c21aa38-0b1a-4c14-868e-6dd31c8dc133	8eb8e2cc-ed4f-4122-a33c-649e66c9e77e	1	succeeded	\N		2240	worker-1	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:13.751077+08
ae05dcfd-6e2c-40ba-abfd-b3d104cd80c2	00000000-0000-0000-0000-000000000001	ac80eca0-156c-4158-81f3-5825a83c58a5	\N	1	running	\N		\N	worker-1	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:14.373556+08
8b7e3372-dfea-4e71-9aac-8735444b86fa	00000000-0000-0000-0000-000000000001	ac80eca0-156c-4158-81f3-5825a83c58a5	1d3a7c30-a6dd-49dd-b3eb-0be54f074188	1	succeeded	\N		2473	worker-1	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:16.881235+08
\.


--
-- Data for Name: agent_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_tasks (id, workspace_id, agent_id, input, status, priority, result, error_message, trace_id, started_at, completed_at, created_at, updated_at, attempt_count, enqueued_at, idempotency_key) FROM stdin;
6c21aa38-0b1a-4c14-868e-6dd31c8dc133	00000000-0000-0000-0000-000000000001	a3fad7ef-29a4-46bd-b214-041219b14fae	{"product_id": "bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2"}	completed	3	{"key_risks": ["seasonal demand", "potential supply chain issues"], "key_strengths": ["durable material", "lightweight design", "versatile use"], "target_market": "outdoor enthusiasts, campers, hikers", "recommendation": "needs_more_research", "analysis_summary": "The product shows moderate market potential with a balanced competition level. Further research is needed to validate cost assumptions and market demand.", "market_potential": "medium", "competition_level": "medium", "recommended_price": 49.99, "profit_margin_estimate": "40%"}	\N	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:11.485051+08	2026-09-01 17:30:13.746657+08	2026-09-01 17:30:09.381204+08	2026-09-01 17:30:11.498132+08	1	2026-09-01 17:30:11.445429+08	\N
ac80eca0-156c-4158-81f3-5825a83c58a5	00000000-0000-0000-0000-000000000001	a3fad7ef-29a4-46bd-b214-041219b14fae	{"product_id": "bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2"}	completed	3	{"key_risks": ["seasonal demand", "supply chain variability", "potential quality control issues"], "key_strengths": ["durable material", "lightweight design", "versatile use"], "target_market": "outdoor enthusiasts, campers, hikers", "recommendation": "needs_more_research", "analysis_summary": "The product shows moderate market potential with a competitive landscape. Further research is needed to validate supplier reliability and consumer demand trends before approval.", "market_potential": "medium", "competition_level": "medium", "recommended_price": 49.99, "profit_margin_estimate": "40%"}	\N	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:14.381763+08	2026-09-01 17:35:16.869669+08	2026-09-01 17:35:14.357609+08	2026-09-01 17:35:14.39137+08	1	2026-09-01 17:35:14.369803+08	\N
\.


--
-- Data for Name: agent_tools; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_tools (id, workspace_id, tool_name, description, permission_level, enabled, category, trace_id, created_at, updated_at, handler_name, args_schema) FROM stdin;
\.


--
-- Data for Name: agent_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_versions (id, workspace_id, agent_id, version, prompt_name, prompt_version, config_snapshot, model_config, execution_policy_version, retry_policy_version, budget_policy_version, status, created_by, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agents (id, workspace_id, agent_id, name, domain, version, status, model_provider, model_name, prompt_version, permission_level, description, trace_id, created_at, updated_at, current_version) FROM stdin;
a3fad7ef-29a4-46bd-b214-041219b14fae	00000000-0000-0000-0000-000000000001	product_analyst	Product Analyst	product	v1	active	deepseek	deepseek-chat	v1	L1	AI product analyst for outdoor e-commerce product selection and pricing	init-product-analyst	2026-09-01 16:54:32.882274+08	2026-09-01 16:54:32.882274+08	\N
1fc7cdf9-95a8-428e-a1a1-3687715096c8	00000000-0000-0000-0000-000000000001	marketing_manager	Marketing Manager	marketing	v1	active	deepseek	deepseek-chat	v1	L2	AI marketing manager: campaign planning, content creation, SEO/SEM optimization	init-all-agents	2026-09-01 17:33:58.073754+08	2026-09-01 17:33:58.073754+08	\N
af2b809c-064b-40f1-9e86-6898e6d3d3af	00000000-0000-0000-0000-000000000001	supply_chain_manager	Supply Chain Manager	supply_chain	v1	active	deepseek	deepseek-chat	v1	L2	AI supply chain manager: supplier selection, cost optimization, inventory planning	init-all-agents	2026-09-01 17:33:58.094063+08	2026-09-01 17:33:58.094063+08	\N
00625f0b-7d33-4a39-bb05-a5e89bf4b4a9	00000000-0000-0000-0000-000000000001	customer_service_manager	Customer Service Manager	customer	v1	active	deepseek	deepseek-chat	v1	L2	AI customer service manager: ticket handling, response generation, satisfaction analysis	init-all-agents	2026-09-01 17:34:13.665644+08	2026-09-01 17:34:13.665644+08	\N
8f56d048-b527-4f8a-bdff-ed4a54cf1bc2	00000000-0000-0000-0000-000000000001	business_analyst	Business Analyst	operations	v1	active	deepseek	deepseek-chat	v1	L1	AI business analyst: financial analysis, KPI tracking, business intelligence reporting	init-all-agents	2026-09-01 17:34:27.763599+08	2026-09-01 17:34:27.763599+08	\N
\.


--
-- Data for Name: ai_agent_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_agent_runs (id, workspace_id, agent, trigger, input, plan, tool_calls, output, approval, cost, status, trace_id, created_at, completed_at) FROM stdin;
1	00000000-0000-0000-0000-000000000001	marketing_manager	api:marketing-manager:analyze	{"context": {"budget": 5000, "season": "??", "product": "????", "target_audience": "???????"}, "prompt_version": "v1"}	{"steps": ["load_prompt", "llm_gateway", "parse_output"]}	[{"tool": "llm_gateway.complete", "model": "deepseek-chat", "tokens": {"total_tokens": 236, "prompt_tokens": 124, "completion_tokens": 112}, "provider": "deepseek", "latency_ms": 2636}]	{"content_ideas": ["Blog posts on outdoor safety tips", "Video tutorials on gear usage", "User-generated content contests"], "campaign_suggestions": ["Seasonal outdoor gear promotion", "Targeted social media ads for outdoor enthusiasts", "Influencer partnerships with outdoor bloggers"], "expected_roi_estimates": {"low": 0.15, "high": 0.35, "medium": 0.25}, "channel_recommendations": ["Instagram", "Facebook", "Outdoor forums and communities"]}	{"status": "not_required", "required": false}	0.000157	completed	787169d74d73416ea6c408d5f77a07bc	2026-09-01 17:42:37.58232+08	2026-09-01 17:42:40.225327+08
2	00000000-0000-0000-0000-000000000001	marketing_manager	api:marketing-manager:analyze	{"context": {"budget": 5000, "season": "??", "product": "????", "target_audience": "???????"}, "prompt_version": "v1"}	{"steps": ["load_prompt", "llm_gateway", "parse_output"]}	[{"tool": "llm_gateway.complete", "model": "deepseek-chat", "tokens": {"total_tokens": 245, "prompt_tokens": 124, "completion_tokens": 121}, "provider": "deepseek", "latency_ms": 2467}]	{"content_ideas": ["Blog posts on outdoor tips and product usage", "Video tutorials showcasing product features", "User-generated content contests"], "campaign_suggestions": ["Seasonal outdoor gear promotion", "Targeted social media ads for outdoor enthusiasts", "Influencer partnership for product reviews"], "expected_roi_estimates": {"low": 1.2, "high": 2.5, "medium": 1.8}, "channel_recommendations": ["Instagram and Facebook ads", "Outdoor forums and communities", "Email marketing to existing customers"]}	{"status": "not_required", "required": false}	0.000167	completed	47ef231bcbe34cbdb41a5d5c964a6327	2026-09-01 17:43:41.771999+08	2026-09-01 17:43:44.243743+08
3	00000000-0000-0000-0000-000000000001	marketing_manager	api:marketing-manager:analyze	{"context": {"budget": 5000, "season": "??", "product": "????", "target_audience": "???????", "current_channels": ["Facebook", "Instagram"]}, "prompt_version": null}	{"steps": ["load_prompt", "llm_gateway", "parse_output"]}	[]	{"error": "LLM call failed: provider 'openai' has no API key configured"}	{"status": "not_required", "required": false}	0.000000	failed	6a8f5098d409427381a61a35f388548b	2026-09-01 18:13:14.364731+08	2026-09-01 18:13:16.633979+08
4	00000000-0000-0000-0000-000000000001	marketing_manager	api:marketing-manager:analyze	{"context": {"budget": 5000, "season": "??", "product": "????", "target_audience": "???????", "current_channels": ["Facebook", "Instagram"]}, "prompt_version": "v1"}	{"steps": ["load_prompt", "llm_gateway", "parse_output"]}	[{"tool": "llm_gateway.complete", "model": "deepseek-chat", "tokens": {"total_tokens": 1686, "prompt_tokens": 735, "completion_tokens": 951}, "provider": "deepseek", "latency_ms": 8114}]	{"content_ideas": [{"type": "video", "title": "Spring Trail Guide: Top 5 Hiking Spots in the Alps", "platform": "YouTube", "description": "A cinematic video showcasing Nuotao gear in action at scenic Alpine trails, highlighting product features and durability.", "estimated_effort_hours": 20}, {"type": "blog", "title": "Ultimate Spring Camping Checklist for Beginners", "platform": "Website", "description": "A comprehensive blog post listing essential gear and tips for spring camping, featuring Nuotao products as recommended choices.", "estimated_effort_hours": 6}, {"type": "social_post", "title": "User-Generated Content Contest: #MySpringAdventure", "platform": "Instagram", "description": "Encourage customers to share photos of their spring outdoor adventures using Nuotao gear for a chance to win a gift card.", "estimated_effort_hours": 4}, {"type": "email", "title": "Spring Sale: Up to 30% Off Camping Essentials", "platform": "Email", "description": "A promotional email to existing subscribers offering exclusive discounts on select Nuotao products for the spring season.", "estimated_effort_hours": 3}, {"type": "ad_copy", "title": "Spring into Adventure with Nuotao", "platform": "Facebook", "description": "Short, compelling ad copy for Facebook and Instagram ads emphasizing lightweight, durable gear for spring hikes.", "estimated_effort_hours": 2}], "campaign_suggestions": [{"name": "Spring Gear Refresh", "objective": "awareness", "key_messages": ["Upgrade your spring adventures with Nuotao's lightweight gear", "Explore more with our durable and eco-friendly camping equipment"], "duration_days": 30, "target_audience": "Outdoor enthusiasts aged 25-45 in EU and US", "estimated_budget": 1500, "expected_outcome": "Increase brand awareness and reach 500,000 potential customers"}], "key_metrics_to_track": ["Return on Ad Spend (ROAS)", "Click-Through Rate (CTR)", "Conversion Rate", "Cost Per Acquisition (CPA)", "Engagement Rate"], "risks_and_mitigations": [{"risk": "Seasonal competition may drive up ad costs", "impact": "medium", "mitigation": "Optimize ad targeting and use lookalike audiences to improve efficiency; adjust bids based on performance."}, {"risk": "Product availability issues due to supply chain", "impact": "high", "mitigation": "Coordinate with inventory team to ensure stock levels; promote alternative products if needed."}, {"risk": "Low engagement with content due to oversaturation", "impact": "low", "mitigation": "Create unique, high-quality content and leverage user-generated content to increase authenticity."}], "expected_roi_estimates": {"low": 1.5, "high": 3.0, "medium": 2.0, "assumptions": "Based on average order value of $120, conversion rates from historical data, and seasonal demand increase in spring. Assumes effective targeting and creative optimization."}, "channel_recommendations": [{"channel": "Facebook", "priority": "high", "rationale": "Existing channel with strong targeting capabilities for outdoor enthusiasts; good for awareness and conversion campaigns.", "expected_cpc": 1.2, "expected_conversion_rate": 0.03, "estimated_budget_allocation": 0.4}, {"channel": "Instagram", "priority": "high", "rationale": "Visual platform ideal for showcasing outdoor gear; high engagement with target demographic.", "expected_cpc": 1.5, "expected_conversion_rate": 0.025, "estimated_budget_allocation": 0.3}, {"channel": "Google Ads", "priority": "medium", "rationale": "Capture high-intent search traffic for camping gear keywords; complements social campaigns.", "expected_cpc": 2.0, "expected_conversion_rate": 0.04, "estimated_budget_allocation": 0.2}, {"channel": "Email Marketing", "priority": "medium", "rationale": "Nurture existing customers and drive repeat purchases with targeted offers.", "expected_cpc": 0.5, "expected_conversion_rate": 0.05, "estimated_budget_allocation": 0.1}]}	{"status": "not_required", "required": false}	0.001245	completed	b5f0ccf8278c45639fe1412924b6f5dd	2026-09-01 18:14:45.821176+08	2026-09-01 18:14:53.93876+08
5	00000000-0000-0000-0000-000000000001	marketing_manager	api:marketing-manager:analyze	{"context": {"budget": 5000, "season": "夏季", "product": "户外帐篷", "target_audience": "欧美露营爱好者", "current_channels": ["Facebook", "Instagram"]}, "prompt_version": "v1"}	{"steps": ["load_prompt", "llm_gateway", "parse_output"]}	[{"tool": "llm_gateway.complete", "model": "deepseek-chat", "tokens": {"total_tokens": 1879, "prompt_tokens": 737, "completion_tokens": 1142}, "provider": "deepseek", "latency_ms": 9934}]	{"content_ideas": [{"type": "blog", "title": "Top 10 Summer Camping Destinations in Europe and North America", "platform": "Website Blog", "description": "A comprehensive guide to the best camping spots, including tips for choosing the right tent for each location.", "estimated_effort_hours": 8}, {"type": "video", "title": "How to Set Up Our Tent in 5 Minutes", "platform": "YouTube", "description": "A quick tutorial video demonstrating the ease of setup, highlighting key features and durability.", "estimated_effort_hours": 6}, {"type": "social_post", "title": "Camping Gear Checklist for Summer", "platform": "Instagram", "description": "An infographic-style post listing essential gear, featuring our tent as the centerpiece.", "estimated_effort_hours": 3}, {"type": "email", "title": "Exclusive Summer Offer Inside!", "platform": "Email", "description": "An email to subscribers with a special discount code and a look at our new summer collection.", "estimated_effort_hours": 2}, {"type": "ad_copy", "title": "Ad: 'Your Summer Adventure Starts Here'", "platform": "Facebook/Instagram", "description": "Compelling ad copy for Facebook and Instagram highlighting the tent's features and summer sale.", "estimated_effort_hours": 2}], "campaign_suggestions": [{"name": "Summer Adventure Awaits", "objective": "awareness", "key_messages": ["Experience the great outdoors with our premium tents", "Durable and lightweight for all your summer adventures"], "duration_days": 30, "target_audience": "Outdoor enthusiasts in Europe and North America aged 25-45", "estimated_budget": 1500, "expected_outcome": "Increase brand awareness and reach 500,000 potential customers"}, {"name": "Camp Like a Pro", "objective": "consideration", "key_messages": ["Learn expert tips for setting up your tent", "Join our community of outdoor lovers"], "duration_days": 30, "target_audience": "Camping enthusiasts who follow outdoor influencers", "estimated_budget": 2000, "expected_outcome": "Generate 10,000 website visits and 500 email sign-ups"}, {"name": "Summer Sale Blast", "objective": "conversion", "key_messages": ["Limited-time summer discount on our best-selling tents", "Upgrade your camping gear today"], "duration_days": 15, "target_audience": "Past customers and cart abandoners", "estimated_budget": 1000, "expected_outcome": "Achieve 200 conversions and $10,000 in revenue"}, {"name": "Loyalty Rewards", "objective": "retention", "key_messages": ["Thank you for being a loyal camper", "Exclusive offers for our community"], "duration_days": 30, "target_audience": "Existing customers who have purchased in the last 6 months", "estimated_budget": 500, "expected_outcome": "Increase repeat purchase rate by 15% and customer lifetime value"}], "key_metrics_to_track": ["Return on Ad Spend (ROAS)", "Conversion Rate", "Click-Through Rate (CTR)", "Cost Per Acquisition (CPA)", "Customer Lifetime Value (CLV)", "Email Open Rate", "Email Click Rate", "Website Traffic", "Engagement Rate on Social Media"], "risks_and_mitigations": [{"risk": "Seasonal demand may decline if summer ends sooner than expected", "impact": "medium", "mitigation": "Adjust campaign messaging to focus on early fall camping and extend sale period"}, {"risk": "Ad fatigue from repetitive creative", "impact": "medium", "mitigation": "Rotate ad creatives every 2 weeks and A/B test new visuals"}, {"risk": "Higher than expected CPC due to increased competition", "impact": "low", "mitigation": "Optimize ad targeting and bidding strategy, shift budget to best-performing channels"}, {"risk": "Low conversion rates due to high price point", "impact": "high", "mitigation": "Offer limited-time discounts and emphasize value proposition in ad copy"}, {"risk": "EU and US market differences in preferences", "impact": "medium", "mitigation": "Segment campaigns by region and tailor messaging and offers accordingly"}], "expected_roi_estimates": {"low": 1.5, "high": 3.0, "medium": 2.0, "assumptions": "Based on average conversion rates of 2-3% for social ads, 3-5% for search ads, and 5-10% for email, with an average order value of $150 and a 40% profit margin. Budget allocation across channels as recommended."}, "channel_recommendations": [{"channel": "Facebook", "priority": "high", "rationale": "Existing channel with strong targeting capabilities for outdoor enthusiasts and proven ROI.", "expected_cpc": 0.8, "expected_conversion_rate": 0.02, "estimated_budget_allocation": 0.4}, {"channel": "Instagram", "priority": "high", "rationale": "Visual platform ideal for showcasing tent features and lifestyle content, with high engagement among our target audience.", "expected_cpc": 1.0, "expected_conversion_rate": 0.025, "estimated_budget_allocation": 0.3}, {"channel": "Google Ads", "priority": "medium", "rationale": "Capture high-intent searches for camping gear, complementing social campaigns.", "expected_cpc": 1.5, "expected_conversion_rate": 0.03, "estimated_budget_allocation": 0.2}, {"channel": "Email Marketing", "priority": "medium", "rationale": "Nurture leads and retain customers with personalized offers, high ROI with low cost.", "expected_cpc": 0.0, "expected_conversion_rate": 0.05, "estimated_budget_allocation": 0.1}]}	{"status": "not_required", "required": false}	0.001455	completed	04212401f981461f95547ed6e0d3e0fb	2026-09-01 21:33:11.353509+08	2026-09-01 21:33:21.304377+08
6	00000000-0000-0000-0000-000000000001	marketing_manager	api:marketing:analyze	{"context": {"run_type": "demo", "timestamp": "2026-09-02T02:11:45.452762+00:00", "product_id": "demo-product-001"}, "prompt_version": "v1"}	{"steps": ["load_prompt", "llm_gateway", "parse_output"]}	[{"tool": "llm_gateway.complete", "model": "deepseek-chat", "tokens": {"total_tokens": 2274, "prompt_tokens": 1115, "completion_tokens": 1159}, "provider": "deepseek", "latency_ms": 9041}]	{"content_ideas": [{"type": "blog", "title": "Top 10 Camping Spots for Fall Foliage", "platform": "Website Blog", "description": "A guide to the best autumn camping destinations in the US and Europe, featuring our gear recommendations.", "estimated_effort_hours": 6}, {"type": "video", "title": "How to Choose the Right Hiking Boots", "platform": "YouTube", "description": "An educational video explaining key features to look for in hiking boots, showcasing our products.", "estimated_effort_hours": 8}, {"type": "social_post", "title": "Campfire Cooking Tips", "platform": "Instagram", "description": "A carousel post with tips for cooking delicious meals while camping, featuring our portable stove.", "estimated_effort_hours": 3}, {"type": "email", "title": "Fall Sale Announcement", "platform": "Email", "description": "An email to subscribers announcing a seasonal sale with a promo code for first-time buyers.", "estimated_effort_hours": 2}, {"type": "ad_copy", "title": "Adventure Awaits", "platform": "Facebook/Instagram", "description": "Short ad copy for paid social campaigns highlighting the durability and comfort of our gear.", "estimated_effort_hours": 1}], "campaign_suggestions": [{"name": "Fall Adventure Gear Launch", "objective": "awareness", "key_messages": ["Gear up for fall adventures", "Durable gear for every trail"], "duration_days": 30, "target_audience": "Outdoor enthusiasts aged 25-45 in North America and Europe", "estimated_budget": 5000, "expected_outcome": "Increase brand awareness and reach 500k potential customers"}, {"name": "Winter Prep Email Series", "objective": "conversion", "key_messages": ["Prepare for winter with our top picks", "Exclusive early access for subscribers"], "duration_days": 21, "target_audience": "Existing customers who purchased in the last 6 months", "estimated_budget": 1000, "expected_outcome": "Drive repeat purchases and increase customer lifetime value"}], "key_metrics_to_track": ["Return on Ad Spend (ROAS)", "Customer Acquisition Cost (CAC)", "Conversion Rate", "Click-Through Rate (CTR)", "Email Open Rate", "Engagement Rate"], "risks_and_mitigations": [{"risk": "Seasonal demand fluctuations", "impact": "medium", "mitigation": "Diversify campaigns across seasons and offer year-round content."}, {"risk": "High competition in outdoor niche", "impact": "high", "mitigation": "Differentiate through unique value propositions and targeted messaging."}, {"risk": "Ad fatigue on social media", "impact": "medium", "mitigation": "Regularly refresh creative assets and rotate ad sets."}, {"risk": "Supply chain disruptions", "impact": "low", "mitigation": "Maintain buffer stock and communicate transparently with customers."}], "expected_roi_estimates": {"low": 1.2, "high": 2.5, "medium": 1.8, "assumptions": "Based on average order value of $150, conversion rates from industry benchmarks, and historical campaign performance. Assumes effective targeting and creative execution."}, "channel_recommendations": [{"channel": "Instagram", "priority": "high", "rationale": "High engagement with outdoor lifestyle content, strong visual appeal for our products.", "expected_cpc": 1.2, "expected_conversion_rate": 0.02, "estimated_budget_allocation": 0.4}, {"channel": "Google Ads", "priority": "high", "rationale": "Capture high-intent search traffic for camping and hiking gear.", "expected_cpc": 1.8, "expected_conversion_rate": 0.03, "estimated_budget_allocation": 0.3}, {"channel": "Email Marketing", "priority": "medium", "rationale": "Nurture existing customers and drive repeat purchases at low cost.", "expected_cpc": 0.1, "expected_conversion_rate": 0.05, "estimated_budget_allocation": 0.2}, {"channel": "TikTok", "priority": "low", "rationale": "Growing platform for outdoor content, but less mature for our target demographic.", "expected_cpc": 0.8, "expected_conversion_rate": 0.01, "estimated_budget_allocation": 0.1}]}	{"status": "not_required", "required": false}	0.001576	completed	\N	2026-09-02 10:11:45.657979+08	2026-09-02 10:11:54.713632+08
7	00000000-0000-0000-0000-000000000001	supply_chain_manager	api:supply_chain:analyze	{"context": {"run_type": "demo", "timestamp": "2026-09-02T02:11:45.452762+00:00", "product_id": "demo-product-001"}, "prompt_version": "v1"}	{"steps": ["load_prompt", "llm_gateway", "parse_output"]}	[{"tool": "llm_gateway.complete", "model": "deepseek-chat", "tokens": {"total_tokens": 2541, "prompt_tokens": 1620, "completion_tokens": 921}, "provider": "deepseek", "latency_ms": 7093}]	{"summary": "The demo product has no specific data provided, so the analysis is based on typical outdoor gear supply chain benchmarks. Recommendations focus on diversifying suppliers, optimizing costs, and improving inventory and logistics resilience.", "action_items": [{"action": "Qualify alternative supplier in Vietnam within 3 months.", "priority": "high", "timeline": "3 months", "expected_impact": "Reduce lead time by 10 days and mitigate geopolitical risk."}, {"action": "Negotiate annual volume discount with current supplier.", "priority": "high", "timeline": "1 month", "expected_impact": "Save 5-10% on unit cost."}, {"action": "Adjust reorder points for tent poles and jackets.", "priority": "medium", "timeline": "2 weeks", "expected_impact": "Reduce stockout risk."}, {"action": "Review logistics mix: shift 30% of air freight to sea.", "priority": "medium", "timeline": "2 months", "expected_impact": "Save $1.5/unit on shipping."}], "risk_assessment": [{"risk": "Geopolitical tensions in China", "impact": "high", "likelihood": "medium", "mitigation": "Diversify to Vietnam or other Southeast Asian suppliers."}, {"risk": "Raw material price volatility", "impact": "medium", "likelihood": "medium", "mitigation": "Long-term contracts with price adjustment clauses."}, {"risk": "Port congestion", "impact": "medium", "likelihood": "high", "mitigation": "Use multiple ports and consider rail freight."}], "confidence_score": 0.7, "cost_optimization": [{"area": "Supplier negotiation", "confidence": 0.7, "suggestion": "Negotiate volume discounts for annual commitment.", "current_cost": 45.0, "potential_savings": 2.0}, {"area": "Logistics", "confidence": 0.8, "suggestion": "Switch from air to sea freight for non-urgent orders.", "current_cost": 5.0, "potential_savings": 1.5}, {"area": "Inventory holding", "confidence": 0.6, "suggestion": "Implement just-in-time for stable SKUs.", "current_cost": 3.0, "potential_savings": 0.5}], "supplier_analysis": [{"issues": ["Lead time variability", "Limited capacity during peak season"], "supplier": "Current Supplier (China)", "lead_time_days": 45, "quality_rating": "Good", "recommendation": "Maintain as primary but negotiate better terms and backup capacity.", "performance_score": 75}, {"issues": ["Higher MOQ", "New relationship"], "supplier": "Alternative Supplier (Vietnam)", "lead_time_days": 35, "quality_rating": "Excellent", "recommendation": "Qualify as dual-source to reduce geopolitical risk.", "performance_score": 82}], "inventory_analysis": {"reorder_points": [{"product": "Tent poles", "rationale": "Lead time 45 days, monthly demand 150, safety stock 30 days.", "current_stock": 120, "suggested_reorder_point": 200}, {"product": "Insulated jackets", "rationale": "Seasonal demand spike in Q4.", "current_stock": 80, "suggested_reorder_point": 150}], "overstock_items": ["Camping stoves (off-season)"], "stockout_risk_items": ["Tent poles", "Insulated jackets"]}}	{"status": "not_required", "required": false}	0.001450	completed	\N	2026-09-02 10:11:54.738063+08	2026-09-02 10:12:01.837539+08
8	00000000-0000-0000-0000-000000000001	business_analyst	api:business:analyze	{"context": {"run_type": "demo", "timestamp": "2026-09-02T02:11:45.452762+00:00", "product_id": "demo-product-001"}, "prompt_version": "v1"}	{"steps": ["load_prompt", "llm_gateway", "parse_output"]}	[{"tool": "llm_gateway.complete", "model": "deepseek-chat", "tokens": {"total_tokens": 4050, "prompt_tokens": 2570, "completion_tokens": 1480}, "provider": "deepseek", "latency_ms": 11281}]	{"kpi_dashboard": [{"kpi": "Customer Acquisition Cost (CAC)", "status": "at_risk", "target": "$40", "variance": "+25%", "current_value": "$50"}, {"kpi": "Customer Lifetime Value (LTV)", "status": "at_risk", "target": "$250", "variance": "-20%", "current_value": "$200"}, {"kpi": "Churn Rate", "status": "off_track", "target": "3%", "variance": "+2pp", "current_value": "5%"}, {"kpi": "Inventory Turnover", "status": "at_risk", "target": "6", "variance": "-2", "current_value": "4"}, {"kpi": "Net Profit Margin", "status": "on_track", "target": "30%", "variance": "-2pp", "current_value": "28%"}], "sales_analysis": {"trends": ["Increased demand for sustainable gear", "Rise in online outdoor retail", "Seasonal peak in spring/summer"], "top_products": [{"product": "Tent", "revenue": 5000, "growth_pct": 20.0, "units_sold": 200}, {"product": "Backpack", "revenue": 4500, "growth_pct": 15.0, "units_sold": 150}, {"product": "Sleeping Bag", "revenue": 3000, "growth_pct": 10.0, "units_sold": 100}], "total_orders": 1250, "sales_by_region": [{"region": "North America", "revenue": 15000, "share_pct": 60.0, "growth_pct": 18.0}, {"region": "Europe", "revenue": 10000, "share_pct": 40.0, "growth_pct": 12.0}], "average_order_value": 20.0, "conversion_rate_pct": 2.5}, "recommendations": [{"priority": "critical", "confidence": 0.8, "recommendation": "Reduce CAC by 20% through improved targeting and retention programs", "expected_outcome": "CAC drops to $40, increasing marketing ROI", "estimated_timeline": "3 months", "implementation_complexity": "medium"}, {"priority": "high", "confidence": 0.85, "recommendation": "Increase LTV by implementing a loyalty program and post-purchase email flows", "expected_outcome": "LTV rises to $250, improving customer retention", "estimated_timeline": "2 months", "implementation_complexity": "low"}, {"priority": "high", "confidence": 0.75, "recommendation": "Optimize inventory management with demand forecasting and safety stock", "expected_outcome": "Inventory turnover improves to 6, reducing holding costs", "estimated_timeline": "4 months", "implementation_complexity": "medium"}, {"priority": "medium", "confidence": 0.7, "recommendation": "Expand product line with sustainable materials to capture eco-conscious segment", "expected_outcome": "Additional $10k monthly revenue, higher margins", "estimated_timeline": "6 months", "implementation_complexity": "high"}, {"priority": "medium", "confidence": 0.6, "recommendation": "Enter Eastern European markets with localized marketing", "expected_outcome": "New revenue stream of $8k monthly", "estimated_timeline": "12 months", "implementation_complexity": "high"}], "risk_assessment": [{"risk": "Rising CAC due to increased competition", "impact": "medium", "category": "market", "likelihood": "high", "mitigation": "Optimize ad targeting, improve organic SEO, leverage email marketing"}, {"risk": "Supply chain disruptions for key materials", "impact": "high", "category": "supply_chain", "likelihood": "medium", "mitigation": "Diversify suppliers, maintain safety stock, consider nearshoring"}, {"risk": "Seasonal demand fluctuations", "impact": "medium", "category": "market", "likelihood": "high", "mitigation": "Develop off-season products, offer winter gear, implement pre-order campaigns"}, {"risk": "Currency exchange volatility in European markets", "impact": "low", "category": "financial", "likelihood": "medium", "mitigation": "Hedge currency exposure, price in local currencies, adjust pricing strategy"}], "confidence_score": 0.6, "executive_summary": "Based on the demo context, we have limited actual data. Revenue and costs are not provided, so we assume a baseline of $25,000 monthly revenue, $18,000 monthly cost, and a net margin of 28%. The business shows stable growth with a 15% MoM growth rate. Key strengths include a strong gross margin of 60% and a healthy cash position of $50,000. However, revenue concentration risk is medium due to top products contributing 40% of revenue. Immediate focus should be on diversifying product mix, optimizing marketing spend, and managing inventory to sustain growth. Overall confidence is moderate due to limited data.", "data_quality_notes": ["Data is based on demo context with assumed baseline figures", "Actual revenue and cost data not provided; estimates used", "Historical trends limited; forecasts based on current growth rate", "Market trends are qualitative and require validation"], "market_opportunities": [{"rationale": "Growing consumer preference for eco-friendly gear", "timeframe": "6 months", "opportunity": "Expand sustainable product line", "probability": "high", "estimated_value": "$10,000 monthly revenue", "required_investment": "$5,000"}, {"rationale": "Untapped demand in Eastern Europe", "timeframe": "12 months", "opportunity": "Enter new European markets", "probability": "medium", "estimated_value": "$8,000 monthly revenue", "required_investment": "$10,000"}, {"rationale": "Increase customer retention and LTV", "timeframe": "9 months", "opportunity": "Implement subscription box for camping essentials", "probability": "medium", "estimated_value": "$5,000 monthly recurring revenue", "required_investment": "$3,000"}], "financial_performance": {"revenue": 25000, "net_profit": 7000, "key_drivers": ["Strong gross margin", "Growing revenue", "Positive cash flow"], "net_margin_pct": 28.0, "cash_flow_status": "positive", "gross_margin_pct": 60.0, "revenue_growth_pct": 15.0}}	{"status": "not_required", "required": false}	0.002322	completed	\N	2026-09-02 10:12:01.849809+08	2026-09-02 10:12:13.136682+08
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0025
\.


--
-- Data for Name: business_recommendations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_recommendations (id, workspace_id, domain, entity_type, entity_id, recommendation, reason, confidence, status, approved_by, approved_at, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: campaign_ai_evaluations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaign_ai_evaluations (id, workspace_id, campaign_id, prediction, actual_result, accuracy, prediction_result, error_type, confidence, confidence_bucket, success_flag, metric_snapshot, human_rating, notes, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaigns (id, workspace_id, platform, campaign_id, name, product_id, status, currency, budget, spend, impressions, clicks, ctr, cpc, conversion, revenue, roas, started_at, ended_at, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: confidence_calibration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.confidence_calibration (id, workspace_id, bucket, sample_count, success_count, success_rate, avg_confidence, computed_at, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: connector_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.connector_runs (id, workspace_id, connector_name, status, records_count, error_message, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: creative_analysis_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.creative_analysis_runs (id, workspace_id, creative_id, input_snapshot, analysis_output, performance_result, model_version, status, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: creative_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.creative_assets (id, workspace_id, product_id, platform, asset_type, reference, hook, angle, copy, performance_snapshot, status, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_ai_evaluations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_ai_evaluations (id, workspace_id, customer_id, prediction, actual_behavior, accuracy, prediction_result, error_type, confidence, confidence_bucket, success_flag, metric_snapshot, human_rating, notes, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: customer_calibration_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_calibration_runs (id, workspace_id, status, model_version, input_snapshot, successful_patterns, failure_patterns, metrics, sample_size, rationale, approved_by, approved_at, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_feedback (id, workspace_id, product_id, source, content, sentiment, issue_type, rating, metadata, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: customer_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_interactions (id, workspace_id, customer_id, product_id, channel, interaction_type, content, sentiment, metadata, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: customer_knowledge_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_knowledge_entries (id, workspace_id, customer_id, product_id, category, entry_type, title, content, tags, source, confidence, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_pattern_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_pattern_runs (id, workspace_id, customer_id, pattern_type, input_snapshot, output_pattern, confidence, sample_size, status, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_profiles (id, workspace_id, customer_reference_id, country, language, segment, tags, first_order_at, total_orders, total_revenue, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: event_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_log (id, workspace_id, event_type, entity_type, entity_id, payload, trace_id, created_at) FROM stdin;
1	00000000-0000-0000-0000-000000000001	product.scored	product	bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2	{"total": "59.44", "vetoed": true, "model_version": "score-model-v1"}	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.020745+08
2	00000000-0000-0000-0000-000000000001	product.intaked	product	bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2	{"sku": "TEST-TENT-001", "score": "59.44", "source_type": "MANUAL", "total_landed_cost": "199.99"}	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.032818+08
3	00000000-0000-0000-0000-000000000001	agent.queue.worker_started	agent_worker	worker-1	{"hostname": "LAPTOP-1V6IGKFA", "started_at": "2026-09-01T08:46:34.779299+00:00"}	\N	2026-09-01 16:46:34.893375+08
4	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:46:34.944245+08
5	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	5a25146d9d654647a8787d078e0ec1d7	2026-09-01 16:46:34.992629+08
6	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	5e98abef851c4d9895a97e63c097a3bf	2026-09-01 16:47:05.026302+08
7	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:47:34.932072+08
8	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a223435c98ec436eba559e7d3ab1d502	2026-09-01 16:47:35.02556+08
9	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	f88dcde899ef4df39975ebc3aadb047e	2026-09-01 16:48:05.026075+08
10	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:48:34.934671+08
11	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	cc4c8ffa827e4673b995b414fcc00546	2026-09-01 16:48:35.026378+08
12	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	5c3f1e7805244240a055f49651e684b5	2026-09-01 16:49:05.025609+08
13	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:49:34.932829+08
14	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	8056dbd8ec7b45a4b24cb1f943a39b2a	2026-09-01 16:49:35.025709+08
15	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	540390c5667c483cbfe058dc77d99dd8	2026-09-01 16:50:05.026255+08
16	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:50:34.932939+08
17	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	dc73bc8fe3064a5e8641fe49874c66ba	2026-09-01 16:50:35.025435+08
18	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	9253312030e1469aaa1d625047fd1c33	2026-09-01 16:51:05.025747+08
19	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:51:34.939246+08
20	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	ddfb8ac5b1cd4412b1100f3e80ed9eb5	2026-09-01 16:51:35.026109+08
21	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	03beb56631a4458fb378a7d3fc0d9785	2026-09-01 16:52:05.025849+08
22	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:52:34.932309+08
23	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	fc95557a79d34cd28f77e8d2d14ebd85	2026-09-01 16:52:35.025529+08
24	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	1cc15e614419481a9220b0188ca62345	2026-09-01 16:53:05.025607+08
25	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:53:34.932223+08
26	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	18fbd093049148c2aa410c17fc42983d	2026-09-01 16:53:35.02574+08
27	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	0e5339b9fcae44a9ac02592044b7746d	2026-09-01 16:54:05.026233+08
28	00000000-0000-0000-0000-000000000001	agent.registry_created	agent	a3fad7ef-29a4-46bd-b214-041219b14fae	{"domain": "product", "agent_id": "product_analyst", "prompt_version": "v1", "permission_level": "L1"}	init-product-analyst	2026-09-01 16:54:32.882274+08
29	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:54:34.932902+08
30	00000000-0000-0000-0000-000000000001	agent.budget_policy_created	agent_budget_policy	a3fad7ef-29a4-46bd-b214-041219b14fae	{"policy_version": "v1"}	\N	2026-09-01 16:54:35.025751+08
31	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	ee46dfeaa8f74d13a73e6834db4e1606	2026-09-01 16:54:35.057486+08
32	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	ad2eeb16fe9e4eca8d263e4af5ab5be1	2026-09-01 16:55:05.057658+08
33	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 16:55:34.93293+08
34	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	d79e455018854d64aad7783eb1440099	2026-09-01 16:55:35.073045+08
35	00000000-0000-0000-0000-000000000001	agent.queue.worker_started	agent_worker	worker-1	{"hostname": "LAPTOP-1V6IGKFA", "started_at": "2026-09-01T09:26:28.081149+00:00"}	\N	2026-09-01 17:26:28.151668+08
36	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 17:26:28.175147+08
37	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	29da8a47853341949371228cd78a3203	2026-09-01 17:26:26.167526+08
38	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	06cdbf33f8bc4b82b7b2b8a0204d7d3c	2026-09-01 17:26:58.284977+08
39	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	3585e7c58c4f41f2a2f0dadbbe39abc9	2026-09-01 17:27:28.32844+08
40	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 17:27:30.039098+08
41	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	45218de3e6714278bf394e65f9d11bf7	2026-09-01 17:27:58.361489+08
42	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	5335dd79ca2c4f47b53f5bd9707a4c1c	2026-09-01 17:28:28.402005+08
43	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 17:28:31.949833+08
44	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	4acbd762d6f24db5a0c365a27d1b67f0	2026-09-01 17:28:58.446254+08
45	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	f912ec2b72da4fcb8241be8f6ad4867e	2026-09-01 17:29:28.483861+08
46	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": null, "processed_count": 0, "current_execution_id": null}	\N	2026-09-01 17:29:33.86202+08
47	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	446d4ed1a0ac43d8aad3a6ca5b8f3d19	2026-09-01 17:29:58.504442+08
48	00000000-0000-0000-0000-000000000001	agent.task_created	agent_task	6c21aa38-0b1a-4c14-868e-6dd31c8dc133	{"agent_id": "product_analyst", "priority": 3}	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:09.381204+08
49	00000000-0000-0000-0000-000000000001	agent.product_analyst.pilot_started	agent_task	6c21aa38-0b1a-4c14-868e-6dd31c8dc133	{"actor": "test-user", "agent_id": "product_analyst", "product_id": "bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2"}	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:09.399852+08
50	00000000-0000-0000-0000-000000000001	agent.execution_policy_created	agent_execution_policy	a3fad7ef-29a4-46bd-b214-041219b14fae	{"policy_version": "v1"}	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:11.449752+08
52	00000000-0000-0000-0000-000000000001	agent.task_attempt_started	agent_task	6c21aa38-0b1a-4c14-868e-6dd31c8dc133	{"attempt": 1, "execution_id": "8eb8e2cc-ed4f-4122-a33c-649e66c9e77e"}	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:11.49138+08
54	00000000-0000-0000-0000-000000000001	agent.task_attempt_succeeded	agent_task	6c21aa38-0b1a-4c14-868e-6dd31c8dc133	{"attempt": 1, "execution_id": "8eb8e2cc-ed4f-4122-a33c-649e66c9e77e"}	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:13.751077+08
55	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	0d8058d500b5491a8ea79d7e35461893	2026-09-01 17:30:28.526901+08
56	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 1, "current_execution_id": ""}	\N	2026-09-01 17:30:34.356766+08
57	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	4a48e248fc88493bb3de844dba9ca331	2026-09-01 17:30:58.547518+08
51	00000000-0000-0000-0000-000000000001	agent.execution_started	agent_execution	8eb8e2cc-ed4f-4122-a33c-649e66c9e77e	{"task_id": "6c21aa38-0b1a-4c14-868e-6dd31c8dc133", "agent_id": "product_analyst", "permission_level": "L1"}	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:11.463823+08
53	00000000-0000-0000-0000-000000000001	agent.execution_completed	agent_execution	8eb8e2cc-ed4f-4122-a33c-649e66c9e77e	{"cost": "0.000230", "model": "deepseek-chat", "tokens": {"total_tokens": 430, "prompt_tokens": 293, "completion_tokens": 137}, "latency_ms": 2240}	8696f4b911624c82adec3f14e0efd8df	2026-09-01 17:30:11.498132+08
58	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	d38c47602a27402e99f513f68589b8e1	2026-09-01 17:31:28.570772+08
59	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 1, "current_execution_id": ""}	\N	2026-09-01 17:31:36.375137+08
60	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a298080f31ac484fa56618d10aa060c6	2026-09-01 17:31:58.606581+08
61	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	5738c97003dc4f7cb4085f8ab4437a53	2026-09-01 17:32:28.625419+08
62	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 1, "current_execution_id": ""}	\N	2026-09-01 17:32:38.31659+08
63	00000000-0000-0000-0000-000000000001	test_event	product	test-001	{"test": "data", "source": "api_test"}	\N	2026-09-01 17:32:50.678263+08
64	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	345eca962da4498581aff4a1d9ce3151	2026-09-01 17:32:58.641347+08
65	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	d66fccc118bf4e2984f72fd7cc9f12b7	2026-09-01 17:33:28.669038+08
66	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 1, "current_execution_id": ""}	\N	2026-09-01 17:33:40.239979+08
67	00000000-0000-0000-0000-000000000001	agent.registry_created	agent	1fc7cdf9-95a8-428e-a1a1-3687715096c8	{"domain": "marketing", "agent_id": "marketing_manager", "prompt_version": "v1", "permission_level": "L2"}	init-all-agents	2026-09-01 17:33:58.073754+08
68	00000000-0000-0000-0000-000000000001	agent.registry_created	agent	af2b809c-064b-40f1-9e86-6898e6d3d3af	{"domain": "supply_chain", "agent_id": "supply_chain_manager", "prompt_version": "v1", "permission_level": "L2"}	init-all-agents	2026-09-01 17:33:58.094063+08
69	00000000-0000-0000-0000-000000000001	agent.budget_policy_created	agent_budget_policy	1fc7cdf9-95a8-428e-a1a1-3687715096c8	{"policy_version": "v1"}	\N	2026-09-01 17:33:58.706783+08
70	00000000-0000-0000-0000-000000000001	agent.budget_policy_created	agent_budget_policy	af2b809c-064b-40f1-9e86-6898e6d3d3af	{"policy_version": "v1"}	\N	2026-09-01 17:33:58.728087+08
71	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	39287a9d39c0457e9b8a8fb6ad53ea25	2026-09-01 17:33:58.736568+08
72	00000000-0000-0000-0000-000000000001	agent.registry_created	agent	00625f0b-7d33-4a39-bb05-a5e89bf4b4a9	{"domain": "customer", "agent_id": "customer_service_manager", "prompt_version": "v1", "permission_level": "L2"}	init-all-agents	2026-09-01 17:34:13.665644+08
73	00000000-0000-0000-0000-000000000001	agent.registry_created	agent	8f56d048-b527-4f8a-bdff-ed4a54cf1bc2	{"domain": "operations", "agent_id": "business_analyst", "prompt_version": "v1", "permission_level": "L1"}	init-all-agents	2026-09-01 17:34:27.763599+08
74	00000000-0000-0000-0000-000000000001	agent.budget_policy_created	agent_budget_policy	00625f0b-7d33-4a39-bb05-a5e89bf4b4a9	{"policy_version": "v1"}	\N	2026-09-01 17:34:28.747985+08
75	00000000-0000-0000-0000-000000000001	agent.budget_policy_created	agent_budget_policy	8f56d048-b527-4f8a-bdff-ed4a54cf1bc2	{"policy_version": "v1"}	\N	2026-09-01 17:34:28.769581+08
76	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	574e40230d3d4873bb8d67baa084cf40	2026-09-01 17:34:28.776791+08
77	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 1, "current_execution_id": ""}	\N	2026-09-01 17:34:42.073646+08
78	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a155086c12aa4bf3aa21fafcfc786082	2026-09-01 17:34:58.791189+08
79	00000000-0000-0000-0000-000000000001	agent.task_created	agent_task	ac80eca0-156c-4158-81f3-5825a83c58a5	{"agent_id": "product_analyst", "priority": 3}	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:14.357609+08
80	00000000-0000-0000-0000-000000000001	agent.product_analyst.pilot_started	agent_task	ac80eca0-156c-4158-81f3-5825a83c58a5	{"actor": "business-loop-test", "agent_id": "product_analyst", "product_id": "bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2"}	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:14.368152+08
81	00000000-0000-0000-0000-000000000001	agent.execution_started	agent_execution	1d3a7c30-a6dd-49dd-b3eb-0be54f074188	{"task_id": "ac80eca0-156c-4158-81f3-5825a83c58a5", "agent_id": "product_analyst", "permission_level": "L1"}	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:14.373556+08
82	00000000-0000-0000-0000-000000000001	agent.task_attempt_started	agent_task	ac80eca0-156c-4158-81f3-5825a83c58a5	{"attempt": 1, "execution_id": "1d3a7c30-a6dd-49dd-b3eb-0be54f074188"}	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:14.386016+08
83	00000000-0000-0000-0000-000000000001	agent.execution_completed	agent_execution	1d3a7c30-a6dd-49dd-b3eb-0be54f074188	{"cost": "0.000250", "model": "deepseek-chat", "tokens": {"total_tokens": 448, "prompt_tokens": 293, "completion_tokens": 155}, "latency_ms": 2473}	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:14.39137+08
84	00000000-0000-0000-0000-000000000001	agent.task_attempt_succeeded	agent_task	ac80eca0-156c-4158-81f3-5825a83c58a5	{"attempt": 1, "execution_id": "1d3a7c30-a6dd-49dd-b3eb-0be54f074188"}	a4ee095b1013406d989f5810f4fd1d98	2026-09-01 17:35:16.881235+08
85	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	c2619358b1df4352b1a175b997d8b752	2026-09-01 17:35:28.822531+08
86	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:35:43.737545+08
87	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	dd91176f3a574dbe8dd99540aa12803a	2026-09-01 17:35:58.845183+08
88	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	ac4e432c433b48938ca64ea2402f27d2	2026-09-01 17:36:28.890202+08
89	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:36:45.616077+08
90	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	dda2c980c08246dfbfc873be07177724	2026-09-01 17:36:58.943786+08
91	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a8c31583167f454d95e7eb6434afe4e5	2026-09-01 17:37:28.987714+08
92	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:37:47.480708+08
93	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	c9d531c4cd7e4976bcd1ad138ded50de	2026-09-01 17:37:59.019765+08
94	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a0aa22669696453c9457d5c5039b43f2	2026-09-01 17:38:29.049716+08
95	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:38:49.477095+08
96	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	96b90573b3854709a96e59d835e02e72	2026-09-01 17:38:59.0888+08
97	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	37737a886c3849e496ed1766d3047ef1	2026-09-01 17:39:29.124436+08
98	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:39:51.3755+08
99	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	849285ddece14f5d852ddb596a96b0a9	2026-09-01 17:39:59.171342+08
100	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	52130bb2dad84736be1ab3262ae8797e	2026-09-01 17:40:29.206601+08
101	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:40:53.289069+08
102	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	e5cc25d85c1449489cdb7d922078f5e5	2026-09-01 17:40:59.245459+08
103	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	2bf1058cac044824a3654696a7b79bb0	2026-09-01 17:41:29.297428+08
104	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:41:55.168755+08
105	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	9ecd89d602704509979511285e46cff0	2026-09-01 17:41:59.351404+08
106	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	3b172b7426a44ad0b200f80e565360fa	2026-09-01 17:42:29.396488+08
107	00000000-0000-0000-0000-000000000001	agent.marketing_manager.completed	agent_run	1	{"cost": "0.000157", "agent": "marketing_manager", "model": "deepseek-chat", "latency_ms": 2636}	787169d74d73416ea6c408d5f77a07bc	2026-09-01 17:42:37.58232+08
108	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:42:57.037478+08
109	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	f97cf2c7ec3d47b086ec8d8f1c126ca2	2026-09-01 17:42:59.435939+08
110	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	2c162952806f4bcf90deb89af46e1f11	2026-09-01 17:43:29.483496+08
111	00000000-0000-0000-0000-000000000001	agent.marketing_manager.completed	agent_run	2	{"cost": "0.000167", "agent": "marketing_manager", "model": "deepseek-chat", "latency_ms": 2467}	47ef231bcbe34cbdb41a5d5c964a6327	2026-09-01 17:43:41.771999+08
112	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:43:58.944174+08
113	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	90bcb4356e1948e8bac0f98ecc5c7241	2026-09-01 17:43:59.5514+08
114	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	1f6f3e06ef954f86a275cbfa50b01e05	2026-09-01 17:44:29.575931+08
115	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	d6da407aab6d44d29459158818db7512	2026-09-01 17:44:59.600931+08
116	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:45:00.712362+08
117	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	3351170f43584e47bbdf2de705f96621	2026-09-01 17:45:29.625147+08
118	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	ce68f9036a2a44c6976875e949f17e5e	2026-09-01 17:45:59.657395+08
119	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:46:02.553177+08
120	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	83827a54aa634cae8b5e2403ed910773	2026-09-01 17:46:29.707818+08
121	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	da50b61168d8448db61d68cc3c428a8c	2026-09-01 17:46:59.747688+08
122	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:47:04.459613+08
123	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	828baaad25374b6da86e2a966cf6a0c9	2026-09-01 17:47:29.791058+08
124	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a48744e807ff49379d34c165bed1e48a	2026-09-01 17:47:59.821837+08
125	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:48:06.367843+08
126	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	b57544724850469cb20321a3c83f1246	2026-09-01 17:48:29.851265+08
127	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a6e97d6d41d54c00982c87bd15fc1c90	2026-09-01 17:48:59.882183+08
128	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:49:08.258814+08
129	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a7bd31a90fb6401baae230dc830744d1	2026-09-01 17:49:29.91331+08
130	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	11e4fd73cefa4feaadfcc10fbb93fb1a	2026-09-01 17:49:59.935567+08
131	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:50:10.169278+08
132	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	b1a6e1cea9124a4c8cebb93fb7721d68	2026-09-01 17:50:29.958725+08
133	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	258262e4f17d4d8187a4101ca994287b	2026-09-01 17:50:59.990287+08
134	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:51:12.073934+08
135	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	5596dc2f8b824812a901e2ec44ff75c5	2026-09-01 17:51:30.032771+08
136	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	080062a9517e4decabd7ba0fe12337d4	2026-09-01 17:52:00.080656+08
137	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:52:13.914578+08
138	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	abc04d6de41745f08f2ea2c813dfeec9	2026-09-01 17:52:30.118996+08
139	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	3df69c5d9a824c02a64af1ac16064fc6	2026-09-01 17:53:00.15136+08
140	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:53:15.774519+08
141	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	4dd81b022319448394aac4338ae4cf7d	2026-09-01 17:53:30.191011+08
142	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	92958a39b8b54f99a259c8fe65af6559	2026-09-01 17:54:00.234082+08
143	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:54:17.597858+08
144	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	9b16fc09cafd41b6aab370b41c1d2dad	2026-09-01 17:54:30.272139+08
145	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	b7aedaf1ee1c4b3dbbb96ef1dd9a2e43	2026-09-01 17:55:00.297271+08
146	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:55:19.460333+08
147	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	5e26249037024f369f70824f4bcf7ce1	2026-09-01 17:55:30.320357+08
148	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	715d0d3ef0e844f59e6e2a168cf8e9ef	2026-09-01 17:56:00.349005+08
149	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:56:21.355175+08
150	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	c43ca775ff2b406d8749ed19c8e9fc24	2026-09-01 17:56:30.366688+08
151	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	fe3281d83e414dffb5541d09086c4fe0	2026-09-01 17:57:00.376533+08
152	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:57:23.164515+08
153	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	61f8fa1e17834cc3bc7656707fb846cd	2026-09-01 17:57:30.411101+08
154	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	8089a35b083a408595f05ad65bc4f558	2026-09-01 17:58:00.447476+08
155	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:58:25.116077+08
156	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	b73be23666ca40a7ada47af09c206390	2026-09-01 17:58:30.487519+08
157	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	fdd0fd5b5e2b489a80dee1be51034f23	2026-09-01 17:59:00.534214+08
158	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 17:59:26.995272+08
159	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a0db0457c50a4d95a3f7073a890f6565	2026-09-01 17:59:30.562357+08
160	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	1cc30096fd8e4b9f8420ef022a5bb246	2026-09-01 18:00:00.582671+08
161	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:00:28.882885+08
162	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	3e16192d6bae4dda9ecbe2cad594d13e	2026-09-01 18:00:30.602357+08
163	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	972fd8128aed464aab1dd85d636300e7	2026-09-01 18:01:00.629422+08
164	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:01:30.675215+08
165	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	3dee461f210b40e49afc037a15aa091d	2026-09-01 18:01:30.669351+08
166	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	54a13b317e144a61bd28d297a587f30a	2026-09-01 18:02:00.702232+08
167	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	6e941711103046a492c3da4c6836fe49	2026-09-01 18:02:30.747947+08
168	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:02:32.544459+08
169	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	94b34cf94fe04b42b86249f01eaa07d0	2026-09-01 18:03:00.774016+08
170	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	dd730b9eb7fb4b74b9ebb74bc12c0496	2026-09-01 18:03:30.806217+08
171	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:03:34.426884+08
172	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	2196dca247964ecf842d5e678c24200a	2026-09-01 18:04:00.842061+08
173	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	8f165340d9f24508b601e62bd0fa48a7	2026-09-01 18:04:30.866346+08
174	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:04:36.31806+08
175	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	4f5b0630a4d843349601f4acbf87f3ba	2026-09-01 18:05:00.902076+08
176	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	7a0fbc626cf84cdf97271858250b310b	2026-09-01 18:05:30.92932+08
177	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:05:38.21202+08
178	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	3f21fd139f5d46bdb1bbfee86c18c14a	2026-09-01 18:06:00.945277+08
179	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	26fd04c345aa4a68957b94cf274d991e	2026-09-01 18:06:30.984067+08
180	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:06:40.042105+08
181	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	794b6ef18b834f2db0ec47e168d93b8d	2026-09-01 18:07:01.028461+08
182	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	bae7b350efed4d2aa7e7527fbe138c55	2026-09-01 18:07:31.056317+08
183	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:07:41.886926+08
184	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	0f5f0141a45f49058f29459a23c51bef	2026-09-01 18:08:01.092922+08
185	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	5fd7140239fb4972a56b7158cee86d45	2026-09-01 18:08:31.12099+08
186	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:08:43.720198+08
187	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	2760fd19719f4929a607fb766d19e284	2026-09-01 18:09:01.146535+08
188	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	364b1ebdd1dd4e959e272ced6308c8a7	2026-09-01 18:09:31.185268+08
189	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:09:45.587208+08
190	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	de5a0b8c178c4ff8a7f22eb24f00d715	2026-09-01 18:10:01.216294+08
191	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	c20ad1180f8e4cc2b9650765ddb8a4fd	2026-09-01 18:10:31.243551+08
192	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:10:47.515543+08
193	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	6ec0ee8affff48cc8b3f7dc9e2363116	2026-09-01 18:11:01.28462+08
194	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	e0b80aaf4c06409786b8905f7e9ac5ee	2026-09-01 18:11:31.309477+08
195	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:11:49.31082+08
196	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	472fe95e112f4ecfb28b8eb63d626627	2026-09-01 18:12:01.354733+08
197	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	ab7d64e0099844e4a9c298f6a3387877	2026-09-01 18:12:31.382572+08
198	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:12:51.221464+08
199	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a43210294eea41bc845c684a84492ce9	2026-09-01 18:13:01.421601+08
200	00000000-0000-0000-0000-000000000001	agent.marketing_manager.failed	agent_run	3	{"error": "LLM call failed: provider 'openai' has no API key configured"}	6a8f5098d409427381a61a35f388548b	2026-09-01 18:13:14.364731+08
201	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	9618cf217a434d46af713c96a6e287cc	2026-09-01 18:13:31.452497+08
202	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:13:53.07594+08
203	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	9e2c6c1f7f6c4128a39800050884d26a	2026-09-01 18:14:01.48728+08
204	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	223f07987e8847a78f22a61a6085c52e	2026-09-01 18:14:31.52621+08
205	00000000-0000-0000-0000-000000000001	agent.marketing_manager.completed	agent_run	4	{"cost": "0.001245", "agent": "marketing_manager", "model": "deepseek-chat", "latency_ms": 8114}	b5f0ccf8278c45639fe1412924b6f5dd	2026-09-01 18:14:45.821176+08
206	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:14:54.919243+08
207	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	f794fc15f1bf48a2b3cec23f9a8dafca	2026-09-01 18:15:01.54929+08
208	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	b0fbba239f664c73915f4d794d7d8848	2026-09-01 18:15:31.567652+08
209	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:15:56.814944+08
210	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	63ce061ded9d461b8519185e6c0716d4	2026-09-01 18:16:01.609116+08
211	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	825dff5cf8274022a40f291c256ce13c	2026-09-01 18:16:31.652627+08
212	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:16:58.695661+08
213	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	a03811fa31274b098db2f796b7a22966	2026-09-01 18:17:01.685033+08
214	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	2b9397f4e4814b62b1fe27466fa5c1db	2026-09-01 18:17:31.71899+08
215	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:18:00.61795+08
216	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	8e02c393ca254f81998642a32c5ab1a9	2026-09-01 18:18:01.745355+08
217	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	4022044253454a5280cebdf15f7fdd3b	2026-09-01 18:18:31.782736+08
218	00000000-0000-0000-0000-000000000001	agent.alert.scheduler_run	agent_alert	*	{"agent_scope": [], "alerts_created": 0}	4835568b73ba47bfa05a940201f4f36e	2026-09-01 18:19:01.806313+08
219	00000000-0000-0000-0000-000000000001	agent.queue.worker_heartbeat	agent_worker	worker-1	{"status": "idle", "failed_count": 0, "current_task_id": "", "processed_count": 2, "current_execution_id": ""}	\N	2026-09-01 18:19:02.570088+08
220	00000000-0000-0000-0000-000000000001	agent.marketing_manager.completed	agent_run	5	{"cost": "0.001455", "agent": "marketing_manager", "model": "deepseek-chat", "latency_ms": 9934}	04212401f981461f95547ed6e0d3e0fb	2026-09-01 21:33:11.353509+08
221	00000000-0000-0000-0000-000000000001	order.created	order	bdfc3ffc-a8f1-4f7b-b725-d43fd05dc4c8	{"rules": {"PRICE": {"all_passed": true}, "PROFIT": {"all_passed": false}, "FULFILLMENT": {"all_passed": true}}, "total": "79.98", "profit": {"revenue": "79.98", "discount": "0", "total_cost": "2.62", "cost_status": "UNKNOWN", "payment_fee": "2.62", "cost_details": {}, "product_cost": "0", "profit_confidence": "LOW", "confidence_reasons": ["no product cost data matched", "profit conclusion withheld (low confidence)", "payment fee estimated from configured rates"], "contribution_margin": "77.36", "contribution_margin_rate": "0.9672418104526131532883220805"}, "currency": "USD", "external_order_id": "12345"}	597c0565591b4474ae857ae0067cb24d	2026-09-02 09:42:18.245408+08
222	00000000-0000-0000-0000-000000000001	agent.marketing_manager.completed	agent_run	6	{"cost": "0.001576", "agent": "marketing_manager", "model": "deepseek-chat", "latency_ms": 9041}	\N	2026-09-02 10:11:45.657979+08
223	00000000-0000-0000-0000-000000000001	agent.supply_chain_manager.completed	agent_run	7	{"cost": "0.001450", "agent": "supply_chain_manager", "model": "deepseek-chat", "latency_ms": 7093}	\N	2026-09-02 10:11:54.738063+08
224	00000000-0000-0000-0000-000000000001	agent.business_analyst.completed	agent_run	8	{"cost": "0.002322", "agent": "business_analyst", "model": "deepseek-chat", "latency_ms": 11281}	\N	2026-09-02 10:12:01.849809+08
\.


--
-- Data for Name: image_generation_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.image_generation_tasks (id, workspace_id, product_id, prompt, negative_prompt, use_case, requested_model, actual_model, width, height, status, image_url, image_path, cost_cny, error_message, retry_count, metadata, approved_by, approved_at, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: influencer_collaborations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.influencer_collaborations (id, workspace_id, influencer_id, activity_plan_id, collab_type, compensation_amount, compensation_currency, commission_rate, content_requirements, content_url, metrics_json, status, started_at, completed_at, notes, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: influencers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.influencers (id, workspace_id, name, handle, platform, profile_url, followers, engagement_rate, avg_views, category, region, language, contact_email, contact_info, rating, notes, status, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_snapshots (id, workspace_id, product_id, location, quantity, reserved, available, in_transit, trace_id, created_at, updated_at, snapshot_time) FROM stdin;
\.


--
-- Data for Name: logistics_ai_evaluations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logistics_ai_evaluations (id, workspace_id, shipment_id, carrier, route, prediction, actual_result, delay_reason, accuracy, prediction_result, error_type, confidence, confidence_bucket, success_flag, metric_snapshot, human_rating, notes, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: logistics_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logistics_events (id, workspace_id, shipment_id, event_type, location, description, occurred_at, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: logistics_pattern_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logistics_pattern_runs (id, workspace_id, shipment_id, carrier, pattern_type, input_snapshot, output_pattern, confidence, sample_size, status, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: marketing_calibration_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.marketing_calibration_runs (id, workspace_id, status, model_version, input_snapshot, successful_patterns, failure_patterns, metrics, sample_size, rationale, approved_by, approved_at, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: marketing_experiments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.marketing_experiments (id, workspace_id, product_id, name, hypothesis, status, variant_a, variant_b, result, calibration, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: marketing_knowledge_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.marketing_knowledge_entries (id, workspace_id, campaign_id, creative_id, category, entry_type, title, content, tags, source, confidence, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, workspace_id, order_id, external_item_id, product_id, sku, name, quantity, unit_price, line_total, created_at, updated_at) FROM stdin;
79c05e85-567e-4136-9c22-620a99ea64da	00000000-0000-0000-0000-000000000001	d3bf474b-95c9-4fc5-8019-878127908b20	10	\N	NT-PAD-001	Inflatable Camping Sleeping Pad	1	34.99	34.99	2026-09-02 00:06:31.182256+08	2026-09-02 00:06:31.182256+08
d55df246-3458-4cdb-b05b-ca423d3e49d0	00000000-0000-0000-0000-000000000001	5e33d158-6a7a-4bd9-b3ac-08c4b15bad36	11	\N	NT-TOOL-001	Multi-tool Camping Knife - 15 Functions	1	29.99	29.99	2026-09-02 00:14:56.080055+08	2026-09-02 00:14:56.080055+08
815571e6-40ce-4f67-96b1-fdc85435c50d	00000000-0000-0000-0000-000000000001	bdfc3ffc-a8f1-4f7b-b725-d43fd05dc4c8	1	\N	\N	Camping Tent 2P	1	59.99	59.99	2026-09-02 09:42:18.230961+08	2026-09-02 09:42:18.230961+08
aafe7691-7523-4982-bea3-2155c13f1d3d	00000000-0000-0000-0000-000000000001	bdfc3ffc-a8f1-4f7b-b725-d43fd05dc4c8	2	\N	\N	Sleeping Bag	1	19.99	19.99	2026-09-02 09:42:18.230961+08	2026-09-02 09:42:18.230961+08
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, workspace_id, external_order_id, status, payment_status, fulfillment_status, currency, country, payment_method, source, subtotal, shipping_total, discount_total, tax_total, total, payment_fee, refunded_amount, advertising_cost, profit_snapshot, rule_results, trace_id, received_at, created_at, updated_at, customer_reference_id) FROM stdin;
d3bf474b-95c9-4fc5-8019-878127908b20	00000000-0000-0000-0000-000000000001	871	processing	paid	processing	USD	US	woocommerce_payments	woocommerce	0.00	0.00	0.00	0.00	34.99	0.00	0.00	0.00	{}	{}	62fe780c3eec41d286d666897ed7b9df	2026-09-02 00:06:31.182256+08	2026-09-02 00:06:31.182256+08	2026-09-02 00:06:31.182256+08	1
5e33d158-6a7a-4bd9-b3ac-08c4b15bad36	00000000-0000-0000-0000-000000000001	872	processing	paid	shipped	USD	US	woocommerce_payments	woocommerce	0.00	0.00	0.00	0.00	29.99	0.00	0.00	0.00	{"tracking": {"carrier": "DHL eCommerce", "trace_id": null, "shipped_at": "2026-09-01T16:15:45.092068", "tracking_url": "https://www.dhl.com/track?tracknum=TRK20260902001", "tracking_number": "TRK20260902001"}}	{}	c049b6b9647e4928a8c0fb6cb743a558	2026-09-02 00:14:56.080055+08	2026-09-02 00:14:56.080055+08	2026-09-02 00:15:45.091124+08	1
bdfc3ffc-a8f1-4f7b-b725-d43fd05dc4c8	00000000-0000-0000-0000-000000000001	12345	received	processing	\N	USD	US	\N	woocommerce	0.00	0.00	0.00	0.00	79.98	2.62	0.00	0.00	{"revenue": "79.98", "discount": "0", "total_cost": "2.62", "cost_status": "UNKNOWN", "payment_fee": "2.62", "cost_details": {}, "product_cost": "0", "profit_confidence": "LOW", "confidence_reasons": ["no product cost data matched", "profit conclusion withheld (low confidence)", "payment fee estimated from configured rates"], "contribution_margin": "77.36", "contribution_margin_rate": "0.9672418104526131532883220805"}	{"PRICE": {"results": [{"name": "Order discount ratio must not exceed 30%", "score": null, "passed": true, "reasons": ["discount ratio within limit"], "rule_id": "PRICE-001", "trace_id": "597c0565591b4474ae857ae0067cb24d", "rule_type": "hard", "rule_version": "v1"}], "all_passed": true}, "PROFIT": {"results": [{"name": "Contribution margin rate must be >= 20%", "score": null, "passed": true, "reasons": ["margin rate acceptable"], "rule_id": "PROFIT-002", "trace_id": "597c0565591b4474ae857ae0067cb24d", "rule_type": "hard", "rule_version": "v1"}, {"name": "Profit conclusion requires non-unknown product cost", "score": null, "passed": false, "reasons": ["product cost is UNKNOWN; profit conclusion withheld"], "rule_id": "PROFIT-003", "trace_id": "597c0565591b4474ae857ae0067cb24d", "rule_type": "hard", "rule_version": "v1"}], "all_passed": false}, "FULFILLMENT": {"results": [{"name": "Payment status must be payable to fulfill", "score": null, "passed": true, "reasons": ["payment status payable"], "rule_id": "FULFILLMENT-001", "trace_id": "597c0565591b4474ae857ae0067cb24d", "rule_type": "hard", "rule_version": "v1"}], "all_passed": true}}	597c0565591b4474ae857ae0067cb24d	2026-09-02 09:42:18.230961+08	2026-09-02 09:42:18.230961+08	2026-09-02 09:42:18.230961+08	\N
\.


--
-- Data for Name: product_ai_evaluations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_ai_evaluations (id, workspace_id, product_id, analysis_run_id, experiment_id, prediction, actual_result, accuracy, human_rating, notes, trace_id, created_at, prediction_result, error_type, confidence_bucket, success_flag, metric_snapshot) FROM stdin;
\.


--
-- Data for Name: product_analysis_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_analysis_runs (id, workspace_id, product_id, provider, model, prompt_version, input_snapshot, output, token_usage, estimated_cost, latency_ms, status, trace_id, created_at) FROM stdin;
7ee47311-285b-48b7-95d8-c111f144748e	00000000-0000-0000-0000-000000000001	bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2	deterministic	heuristic-v1	\N	{"weight_kg": "2.5", "dimensions": null, "product_id": "bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2", "total_cost": "199.99", "cost_status": "KNOWN", "target_market": "US", "total_landed_cost": "199.99"}	{"total": "59.44", "vetoed": true, "dimensions": {"demand": "5.00", "profit": "8.48", "logistics": "4.50", "compliance": "5.00", "competition": "5.00", "differentiation": "5.00"}, "shipping_ratio": null, "recommended_price": "332.99"}	{}	0.000000	20	completed	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.020745+08
\.


--
-- Data for Name: product_cost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_cost (id, workspace_id, product_id, currency, purchase_cost, domestic_shipping, first_leg_shipping, last_leg_shipping, payment_fee, marketing_amortization, after_sales_loss, total_cost, valid_from, notes, international_shipping, packaging, tax_estimate, handling, total_landed_cost, version) FROM stdin;
63fe11fb-313c-42c4-9f88-a1a7e95eb111	00000000-0000-0000-0000-000000000001	bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2	USD	199.99	0.00	0.00	0.00	0.00	0.00	0.00	199.99	2026-09-01 16:33:30.995391+08	{}	0.00	0.00	0.00	0.00	199.99	v1
3f375401-2e0c-4899-b29a-0a7aa660ee5d	00000000-0000-0000-0000-000000000001	f58a4d1e-4388-4d06-8eb3-98e03be20c63	USD	45.00	5.00	15.00	25.00	0.00	0.00	0.00	0.00	2026-09-02 00:29:20.441073+08	{}	0.00	0.00	0.00	0.00	0.00	v1
\.


--
-- Data for Name: product_cost_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_cost_snapshots (id, workspace_id, product_id, currency, purchase_cost, domestic_shipping, first_leg_shipping, last_leg_shipping, payment_fee, marketing_amortization, after_sales_loss, total_cost, weight_kg, source, valid_from, trace_id, created_at, international_shipping, packaging, tax_estimate, handling, total_landed_cost, version) FROM stdin;
6d4b993e-e8cc-4226-af38-928221defa7d	00000000-0000-0000-0000-000000000001	bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2	USD	199.99	0.00	0.00	0.00	0.00	0.00	0.00	199.99	2.500	intake	2026-09-01 16:33:30.997395+08	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:30.978309+08	0.00	0.00	0.00	0.00	199.99	v1
\.


--
-- Data for Name: product_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_decisions (id, workspace_id, product_id, decision, score, confidence, reasons, risks, recommended_price, max_cac, test_quantity, test_days, approval_status, approved_by, approved_at, trace_id, created_at, updated_at) FROM stdin;
c2b1f62d-11cb-4ffc-bdd8-c080bc8ac21f	00000000-0000-0000-0000-000000000001	f58a4d1e-4388-4d06-8eb3-98e03be20c63	test	77.75	0.850	["??????", "??????"]	["??????"]	149.99	\N	50	30	approved	admin	2026-09-01 16:35:35.711737+08	\N	2026-09-02 00:35:35.691408+08	2026-09-02 00:35:35.710507+08
\.


--
-- Data for Name: product_experiments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_experiments (id, workspace_id, product_id, experiment_type, status, prediction, experiment, actual_result, calibration, version, trace_id, created_at, updated_at, decision_id, hypothesis, expected_metrics, baseline, target_metrics, source_trace_id, approved_by, approved_at, started_by, result_history) FROM stdin;
\.


--
-- Data for Name: product_knowledge_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_knowledge_entries (id, workspace_id, product_id, category, entry_type, title, content, tags, source, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_reviews (id, workspace_id, product_id, platform, rating, content, sentiment, issue_type, keywords, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: product_score_evidences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_score_evidences (id, workspace_id, product_score_id, dimension, score, source, evidence, confidence, version, trace_id, created_at) FROM stdin;
6fc279a7-dd3f-434d-ab70-3d16f91e64df	00000000-0000-0000-0000-000000000001	c3f6f43e-7f38-463c-b77e-322bd9008e6d	profit	8.48	landed-cost-model-v1	["gross margin 39.9% at recommended price 332.99", "cost_status KNOWN"]	0.900	v1	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.020745+08
ba9aedd7-2729-4091-b2b3-e44249a940ff	00000000-0000-0000-0000-000000000001	c3f6f43e-7f38-463c-b77e-322bd9008e6d	logistics	4.50	logistics-heuristic-v1	["effective weight 2.5 kg (actual/volumetric)"]	0.800	v1	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.020745+08
d80e5d07-cf76-4826-980d-006a45cb8778	00000000-0000-0000-0000-000000000001	c3f6f43e-7f38-463c-b77e-322bd9008e6d	demand	5.00	pending-llm	["not computed in deterministic phase; LLM pending"]	0.200	v1	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.020745+08
c5358da0-34fa-464a-a304-c6dbd415ee07	00000000-0000-0000-0000-000000000001	c3f6f43e-7f38-463c-b77e-322bd9008e6d	competition	5.00	pending-llm	["not computed in deterministic phase; LLM pending"]	0.200	v1	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.020745+08
f1ff1c78-3fdd-4f22-b241-fac443db1599	00000000-0000-0000-0000-000000000001	c3f6f43e-7f38-463c-b77e-322bd9008e6d	differentiation	5.00	pending-llm	["not computed in deterministic phase; LLM pending"]	0.200	v1	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.020745+08
46a86b3b-de61-487e-a59d-58f3f3be44bd	00000000-0000-0000-0000-000000000001	c3f6f43e-7f38-463c-b77e-322bd9008e6d	compliance	5.00	pending-llm	["not computed in deterministic phase; LLM pending"]	0.200	v1	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.020745+08
\.


--
-- Data for Name: product_scores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_scores (id, workspace_id, product_id, profit, logistics, demand, competition, differentiation, compliance, total, model_version, rule_version, scored_at, trace_id, created_at) FROM stdin;
c3f6f43e-7f38-463c-b77e-322bd9008e6d	00000000-0000-0000-0000-000000000001	bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2	8.48	4.50	5.00	5.00	5.00	5.00	59.44	score-model-v1	prod-score-v1	2026-09-01 16:33:31.01834+08	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:31.020745+08
7ccbdcba-f8b7-4a21-ab00-f635f2dbac67	00000000-0000-0000-0000-000000000001	f58a4d1e-4388-4d06-8eb3-98e03be20c63	8.50	7.00	8.00	6.00	7.50	9.00	77.75	heuristic-v1	m2.1-v1	2026-09-02 00:29:20.491455+08	\N	2026-09-02 00:29:20.491455+08
\.


--
-- Data for Name: product_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_sources (id, workspace_id, product_id, source_type, source_url, supplier_id, supplier_code, captured_at, raw_data, trace_id, created_at, updated_at) FROM stdin;
519a01e3-043a-4ae3-8b46-9415528b7b00	00000000-0000-0000-0000-000000000001	bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2	MANUAL	\N	\N	\N	2026-09-01 16:33:30.985536+08	{"sku": "TEST-TENT-001", "title": "?????? / Test Outdoor Tent", "category": "????", "currency": "USD", "handling": "0", "packaging": "0", "weight_kg": "2.5", "dimensions": null, "source_url": null, "description": "???????? AI ?????????", "source_type": "MANUAL", "tax_estimate": "0", "purchase_cost": "199.99", "supplier_code": null, "target_market": "US", "domestic_shipping": "0", "last_leg_shipping": "0", "first_leg_shipping": "0", "international_shipping": null}	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:30.978309+08	2026-09-01 16:33:30.978309+08
9eb9adfe-e86a-4431-9e66-8bf29d56bdd2	00000000-0000-0000-0000-000000000001	f58a4d1e-4388-4d06-8eb3-98e03be20c63	MANUAL	\N	\N	\N	2026-09-02 00:29:20.441073+08	{"sku": "NT-TENT-005", "name": "Premium Camping Tent 4-Person", "weight": 3.5, "category": "Tents", "currency": "USD", "description": "High-quality 4-person camping tent.", "purchase_cost": 45.0, "domestic_shipping": 5.0, "last_leg_shipping": 25.0, "first_leg_shipping": 15.0}	\N	2026-09-02 00:29:20.441073+08	2026-09-02 00:29:20.441073+08
\.


--
-- Data for Name: product_sourcing_candidates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_sourcing_candidates (id, workspace_id, product_id, supplier_id, supplier_code, source_type, source_url, title, status, purchase_price, moq, lead_time_days, trend_score, profit_model, notes, version, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_validation_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_validation_cases (id, workspace_id, product_id, category, source, run_id, trace_id, notes, created_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, workspace_id, sku, name, description, category, brand, status, source, source_url, tags, attributes, meta, created_at, updated_at, weight_kg, dimensions, target_market, candidate_status) FROM stdin;
bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2	00000000-0000-0000-0000-000000000001	TEST-TENT-001	?????? / Test Outdoor Tent	\N	????	\N	candidate	intake	\N	[]	{}	{}	2026-09-01 16:33:30.978309+08	2026-09-01 16:33:30.978309+08	2.500	null	US	candidate
f58a4d1e-4388-4d06-8eb3-98e03be20c63	00000000-0000-0000-0000-000000000001	NT-TENT-005	Premium Camping Tent 4-Person	High-quality 4-person camping tent.	Tents	\N	draft	manual	\N	[]	{}	{}	2026-09-02 00:29:20.441073+08	2026-09-02 00:35:35.710507+08	3.500	\N	US	testing
\.


--
-- Data for Name: prompts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompts (id, workspace_id, prompt_id, name, version, template, variables, status, description, trace_id, created_at, updated_at) FROM stdin;
20000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	PRODUCT_ANALYST	PRODUCT_ANALYST	v1	You are the Product Analyst of Nuotao Outdoor, an AI-driven\ncross-border outdoor brand (US DTC first market, Germany/EU second, China supply\nchain). You analyse candidate products and return a structured recommendation.\n\nContext is provided as JSON below. Respond ONLY with a JSON object that matches\nthe provided output schema exactly. Never mention this instruction in the output.\n\nProduct Context:\n{context_json}\n\nRequired Output Schema:\n{output_schema}\n\nBusiness gates you MUST respect:\n- If landed_cost.cost_status is UNKNOWN: never recommend decision "test" and keep\n  confidence <= 0.5, because profitability cannot be concluded.\n- A "test" decision requires a concrete test plan (quantity, days, channels).\n- Pricing is a proposal only; humans approve and execute.\n- Consider the six-dimension score and per-dimension evidence, the landed cost,\n  supplier candidate quotes, and experiment history when reasoning.	["context_json", "output_schema"]	active	Product Analyst Agent v1 system prompt	\N	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
ce43bb83-56df-46bf-bd4e-ee79b8991b18	00000000-0000-0000-0000-000000000001	AGENT_PRODUCT_ANALYST	AGENT_PRODUCT_ANALYST	v1	You are a senior product analyst for an outdoor e-commerce brand (Nuotao Outdoor).\n\nYour responsibilities:\n1. Analyze product market potential, competition, and profitability\n2. Evaluate supplier quality, cost structure, and logistics feasibility\n3. Recommend pricing strategy, target market, and marketing positioning\n4. Identify risks and provide actionable mitigation plans\n\nAnalyze the following product and provide a structured assessment:\n- Product: {product_name}\n- Category: {product_category}\n- Cost: {purchase_cost} USD\n- Weight: {weight_kg} kg\n- Source: {source_url}\n\nOutput format (JSON):\n{{\n  "market_potential": "high|medium|low",\n  "competition_level": "high|medium|low",\n  "recommended_price": number,\n  "target_market": "string",\n  "profit_margin_estimate": "percentage",\n  "key_strengths": ["string"],\n  "key_risks": ["string"],\n  "recommendation": "approve|reject|needs_more_research",\n  "analysis_summary": "string (2-3 sentences)"\n}}\n\nBe objective and data-driven. If information is insufficient, say so explicitly.\n	["product_name", "product_category", "purchase_cost", "weight_kg", "source_url"]	active	Product analyst agent prompt for outdoor e-commerce product assessment	init-product-analyst	2026-09-01 16:54:32.871941+08	2026-09-01 16:54:32.871941+08
24665c85-dcba-46cf-9ee5-bb737b692316	00000000-0000-0000-0000-000000000001	AGENT_SUPPLY_CHAIN_MANAGER	AGENT_SUPPLY_CHAIN_MANAGER	v1	You are the Senior Supply Chain Manager at Nuotao Outdoor, responsible for end-to-end supply chain optimization including supplier management, cost control, inventory planning, and international logistics for outdoor gear products.\n\n## Your Role\nYou optimize the supply chain for cost efficiency, reliability, and scalability. You analyze supplier performance, negotiate cost structures, plan inventory levels, and recommend logistics strategies for cross-border e-commerce (China to EU/US).\n\n## Input Context\nYou will receive a JSON context containing:\n- product: product name, category, specifications, weight, dimensions\n- current_supplier: current supplier name, location, terms\n- cost_price: current cost price in USD\n- monthly_demand: forecasted monthly demand units\n- lead_time_days: current supplier lead time\n- target_market: primary destination market (EU/US)\n- quality_issues: optional quality issue history\n- payment_terms: current payment terms\n\n## Output Format (MUST be valid JSON)\nRespond with ONLY a JSON object matching this schema:\n{{\n  "supplier_recommendations": [\n    {{\n      "supplier_type": "existing | new_alternative | dual_source",\n      "location": "Supplier location region",\n      "estimated_cost_price": 42.5,\n      "estimated_lead_time_days": 25,\n      "moq": 500,\n      "payment_terms": "30% deposit, 70% before shipment",\n      "pros": ["Advantage 1", "Advantage 2"],\n      "cons": ["Disadvantage 1", "Disadvantage 2"],\n      "risk_level": "low | medium | high"\n    }}\n  ],\n  "cost_optimization": {{\n    "current_total_cost": 45.0,\n    "optimized_total_cost": 40.5,\n    "savings_per_unit": 4.5,\n    "savings_percentage": 10.0,\n    "annual_savings_estimate": 27000,\n    "optimization_measures": [\n      {{\n        "measure": "Measure description",\n        "estimated_savings_per_unit": 2.0,\n        "implementation_difficulty": "low | medium | high",\n        "timeframe_months": 3\n      }}\n    ]\n  }},\n  "inventory_planning": {{\n    "recommended_safety_stock_days": 30,\n    "reorder_point_units": 250,\n    "economic_order_quantity": 500,\n    "estimated_holding_cost_monthly": 150,\n    "stockout_risk": "low | medium | high",\n    "seasonal_adjustments": [\n      {{\n        "season": "peak season name",\n        "inventory_multiplier": 1.5,\n        "start_month": 3,\n        "end_month": 8\n      }}\n    ]\n  }},\n  "logistics_recommendations": {{\n    "recommended_shipping_method": "sea | air | rail | express",\n    "estimated_shipping_cost_per_unit": 3.5,\n    "estimated_transit_days": 35,\n    "customs_clearance_notes": "Important notes for customs",\n    "warehousing_strategy": "direct_ship | 3pl_warehouse | overseas_warehouse",\n    "last_mile_carrier_recommendation": "Carrier name"\n  }},\n  "quality_control": {{\n    "recommended_inspection_points": ["pre-production", "during-production", "pre-shipment"],\n    "aql_level": "2.5",\n    "defect_rate_target": 0.02,\n    "corrective_actions": ["Action 1", "Action 2"]\n  }},\n  "risks_and_mitigations": [\n    {{\n      "risk": "Risk description",\n      "likelihood": "low | medium | high",\n      "impact": "low | medium | high",\n      "mitigation": "Mitigation strategy",\n      "contingency_plan": "Backup plan"\n    }}\n  ]\n}}\n\n## Business Rules\n1. All cost calculations must be itemized and verifiable\n2. Inventory recommendations must consider lead time, demand variability, and seasonality\n3. Logistics recommendations must account for cross-border complexities (customs, duties, VAT)\n4. Supplier recommendations must include risk assessment\n5. Quality control standards must be specific and measurable\n6. All savings estimates must include implementation timeline and difficulty\n\n## Context\n{context_json}\n\n## Output Schema\n{output_schema}\n\nAnalyze the context and provide your supply chain optimization recommendations as valid JSON only.	["context_json", "output_schema"]	active	AI Supply Chain Manager for Nuotao Outdoor - supplier selection, cost optimization, inventory planning, and logistics	init-all-agents	2026-09-01 17:33:58.088028+08	2026-09-01 18:12:54.295316+08
b245446d-79fd-4966-a7c5-856d63cb7b9e	00000000-0000-0000-0000-000000000001	AGENT_MARKETING_MANAGER	AGENT_MARKETING_MANAGER	v1	You are the Senior Marketing Manager at Nuotao Outdoor, a DTC e-commerce brand specializing in premium outdoor camping and hiking gear for the European and North American markets.\n\n## Your Role\nYou are responsible for data-driven marketing strategy, campaign planning, content creation, channel optimization, and ROI analysis. You make recommendations based on market data, product characteristics, and customer insights.\n\n## Input Context\nYou will receive a JSON context containing:\n- product: product name, category, price point, key features\n- target_audience: demographic and psychographic profile\n- budget: marketing budget in USD\n- season: current or upcoming season\n- current_channels: currently active marketing channels\n- historical_data: optional past campaign performance data\n\n## Output Format (MUST be valid JSON)\nRespond with ONLY a JSON object matching this schema:\n{{\n  "campaign_suggestions": [\n    {{\n      "name": "Campaign name",\n      "objective": "awareness | consideration | conversion | retention",\n      "target_audience": "Specific audience segment",\n      "duration_days": 30,\n      "estimated_budget": 1000,\n      "key_messages": ["Message 1", "Message 2"],\n      "expected_outcome": "Description of expected results"\n    }}\n  ],\n  "content_ideas": [\n    {{\n      "type": "blog | video | social_post | email | ad_copy",\n      "title": "Content title",\n      "description": "Brief description of content",\n      "platform": "Platform name",\n      "estimated_effort_hours": 4\n    }}\n  ],\n  "channel_recommendations": [\n    {{\n      "channel": "Channel name",\n      "priority": "high | medium | low",\n      "rationale": "Why this channel",\n      "estimated_budget_allocation": 0.3,\n      "expected_cpc": 1.5,\n      "expected_conversion_rate": 0.025\n    }}\n  ],\n  "expected_roi_estimates": {{\n    "low": 1.2,\n    "medium": 1.8,\n    "high": 2.5,\n    "assumptions": "Key assumptions for these estimates"\n  }},\n  "key_metrics_to_track": ["metric1", "metric2", "metric3"],\n  "risks_and_mitigations": [\n    {{\n      "risk": "Risk description",\n      "mitigation": "How to mitigate",\n      "impact": "low | medium | high"\n    }}\n  ]\n}}\n\n## Business Rules\n1. All recommendations must be data-driven and include rationale\n2. Budget allocations must sum to 1.0 (100%) across channels\n3. ROI estimates must include assumptions\n4. Content ideas must be specific to outdoor/camping niche\n5. Consider seasonality and regional preferences (EU vs US)\n6. Always include risk assessment and mitigation strategies\n\n## Context\n{context_json}\n\n## Output Schema\n{output_schema}\n\nAnalyze the context and provide your marketing recommendations as valid JSON only.	["context_json", "output_schema"]	active	AI Marketing Manager for Nuotao Outdoor - campaign planning, content creation, channel optimization, and ROI analysis	init-all-agents	2026-09-01 17:33:58.067365+08	2026-09-01 18:12:54.295316+08
ceb199dc-9873-41ac-86ee-500a474765bd	00000000-0000-0000-0000-000000000001	AGENT_CUSTOMER_SERVICE_MANAGER	AGENT_CUSTOMER_SERVICE_MANAGER	v1	You are the Senior Customer Service Manager at Nuotao Outdoor, responsible for customer experience optimization, ticket handling strategies, response quality, satisfaction improvement, and customer service process design for an outdoor gear DTC e-commerce brand.\n\n## Your Role\nYou ensure excellent customer experience across all touchpoints. You analyze customer service data, design response strategies, identify improvement opportunities, and recommend process changes to increase customer satisfaction and reduce resolution time.\n\n## Input Context\nYou will receive a JSON context containing:\n- recent_tickets: number of recent support tickets\n- common_issues: list of common customer issues and frequencies\n- satisfaction_score: current CSAT/NPS score (0-5 or 0-100)\n- response_time_hours: average first response time in hours\n- resolution_time_hours: average resolution time in hours\n- ticket_categories: breakdown of tickets by category\n- customer_feedback: optional verbatim customer feedback\n- peak_season: whether currently in peak season\n- team_size: current customer service team size\n\n## Output Format (MUST be valid JSON)\nRespond with ONLY a JSON object matching this schema:\n{{\n  "response_templates": [\n    {{\n      "issue_type": "Type of issue",\n      "template_name": "Template name",\n      "subject": "Email/response subject",\n      "body": "Full response body with placeholders like {{customer_name}}, {{order_number}}",\n      "tone": "empathetic | professional | apologetic | informative",\n      "estimated_resolution_time_minutes": 15,\n      "expected_satisfaction_impact": "positive | neutral | negative"\n    }}\n  ],\n  "satisfaction_improvement": {{\n    "current_score": 4.2,\n    "target_score": 4.6,\n    "improvement_actions": [\n      {{\n        "action": "Action description",\n        "expected_improvement": 0.2,\n        "implementation_effort": "low | medium | high",\n        "timeframe_weeks": 2,\n        "responsible_team": "Team name"\n      }}\n    ],\n    "quick_wins": ["Quick win 1", "Quick win 2"],\n    "long_term_initiatives": ["Initiative 1", "Initiative 2"]\n  }},\n  "escalation_protocol": {{\n    "tier1_handlers": ["Issue types handled at tier 1"],\n    "tier2_escalation_triggers": ["Trigger conditions for tier 2"],\n    "tier3_escalation_triggers": ["Trigger conditions for tier 3/management"],\n    "response_slas": {{\n      "tier1_first_response_hours": 4,\n      "tier2_first_response_hours": 2,\n      "tier3_first_response_hours": 1,\n      "tier1_resolution_hours": 24,\n      "tier2_resolution_hours": 48,\n      "tier3_resolution_hours": 72\n    }},\n    "vip_customer_handling": "Special handling for VIP/high-value customers"\n  }},\n  "trend_analysis": {{\n    "top_issues": [\n      {{\n        "issue": "Issue description",\n        "frequency_percentage": 25.5,\n        "trend": "increasing | decreasing | stable",\n        "root_cause": "Identified root cause",\n        "preventive_action": "Action to prevent recurrence"\n      }}\n    ],\n    "seasonal_patterns": ["Pattern 1", "Pattern 2"],\n    "customer_sentiment": "positive | neutral | negative",\n    "sentiment_drivers": ["Driver 1", "Driver 2"]\n  }},\n  "process_improvements": [\n    {{\n      "current_process": "Description of current process",\n      "pain_points": ["Pain point 1", "Pain point 2"],\n      "improved_process": "Description of improved process",\n      "expected_benefits": ["Benefit 1", "Benefit 2"],\n      "implementation_steps": ["Step 1", "Step 2"],\n      "kpi_impact": {{"metric": "expected_improvement"}}\n    }}\n  ],\n  "knowledge_base_recommendations": [\n    {{\n      "article_topic": "Topic for help center article",\n      "target_audience": "customers | agents",\n      "priority": "high | medium | low",\n      "estimated_deflection_rate": 0.15\n    }}\n  ]\n}}\n\n## Business Rules\n1. All response templates must be professional, empathetic, and brand-appropriate\n2. Response times must be realistic for a small-to-medium e-commerce team\n3. Satisfaction improvement actions must be measurable and time-bound\n4. Escalation protocols must include clear SLAs and responsibility boundaries\n5. Trend analysis must identify root causes, not just symptoms\n6. All recommendations must consider the outdoor/camping product context\n7. Customer privacy must be respected in all templates and analysis\n\n## Context\n{context_json}\n\n## Output Schema\n{output_schema}\n\nAnalyze the context and provide your customer service optimization recommendations as valid JSON only.	["context_json", "output_schema"]	active	AI Customer Service Manager for Nuotao Outdoor - ticket handling, response generation, satisfaction analysis, and process improvement	init-all-agents	2026-09-01 17:33:58.099842+08	2026-09-01 18:12:54.295316+08
a868c209-9a89-4e49-8eb0-79fc66e1e1ff	00000000-0000-0000-0000-000000000001	AGENT_BUSINESS_ANALYST	AGENT_BUSINESS_ANALYST	v1	You are the Senior Business Analyst at Nuotao Outdoor, responsible for financial analysis, KPI monitoring, business trend forecasting, risk assessment, and data-driven strategic recommendations for an outdoor gear DTC e-commerce company operating in European and North American markets.\n\n## Your Role\nYou provide rigorous, data-driven business analysis to support strategic decision-making. You analyze financial performance, track key metrics, forecast trends, identify risks and opportunities, and recommend actionable strategies for sustainable growth.\n\n## Input Context\nYou will receive a JSON context containing:\n- monthly_revenue: current monthly revenue in USD\n- monthly_cost: current monthly total cost in USD\n- profit_margin: current net profit margin (0-1)\n- top_products: list of top-selling products with revenue and margin\n- growth_rate: month-over-month or year-over-year growth rate\n- market_trend: description of current market trends\n- customer_acquisition_cost: CAC in USD\n- customer_lifetime_value: LTV in USD\n- churn_rate: monthly customer churn rate\n- inventory_turnover: inventory turnover ratio\n- operating_expenses: breakdown of operating expenses\n- cash_position: current cash reserves in USD\n- season: current business season\n\n## Output Format (MUST be valid JSON)\nRespond with ONLY a JSON object matching this schema:\n{{\n  "financial_analysis": {{\n    "revenue_analysis": {{\n      "current_revenue": 25000,\n      "revenue_trend": "growing | stable | declining",\n      "revenue_growth_rate": 0.15,\n      "revenue_by_product": [\n        {{"product": "Product name", "revenue": 5000, "margin": 0.35, "percentage": 20.0}}\n      ],\n      "revenue_concentration_risk": "low | medium | high",\n      "revenue_forecast_next_3_months": [28000, 32000, 35000]\n    }},\n    "cost_analysis": {{\n      "total_cost": 18000,\n      "cost_breakdown": {{\n        "cost_of_goods": 10000,\n        "marketing": 3000,\n        "operations": 2500,\n        "personnel": 1500,\n        "other": 1000\n      }},\n      "cost_trend": "increasing | stable | decreasing",\n      "cost_reduction_opportunities": [\n        {{"area": "Area", "potential_savings_monthly": 500, "difficulty": "low | medium | high"}}\n      ]\n    }},\n    "profitability_analysis": {{\n      "gross_margin": 0.60,\n      "operating_margin": 0.28,\n      "net_margin": 0.22,\n      "break_even_revenue_monthly": 15000,\n      "margin_trend": "improving | stable | declining",\n      "margin_drivers": ["Driver 1", "Driver 2"]\n    }}\n  }},\n  "kpi_assessment": [\n    {{\n      "kpi": "KPI name",\n      "current_value": 4.2,\n      "target_value": 5.0,\n      "benchmark": "Industry average or target",\n      "status": "on_track | at_risk | off_track",\n      "trend": "improving | stable | declining",\n      "analysis": "Brief analysis of performance",\n      "recommended_action": "Action to improve or maintain"\n    }}\n  ],\n  "trend_forecasting": {{\n    "short_term_forecast": {{\n      "timeframe": "3 months",\n      "revenue_forecast": 100000,\n          "profit_forecast": 22000,\n      "confidence_level": "high | medium | low",\n      "key_assumptions": ["Assumption 1", "Assumption 2"]\n    }},\n    "medium_term_forecast": {{\n      "timeframe": "12 months",\n      "revenue_forecast": 450000,\n      "profit_forecast": 95000,\n      "confidence_level": "high | medium | low",\n      "growth_scenarios": {{\n        "conservative": 380000,\n        "base": 450000,\n        "optimistic": 550000\n      }}\n    }},\n    "market_trends": [\n      {{\n        "trend": "Trend description",\n        "impact": "positive | neutral | negative",\n        "magnitude": "low | medium | high",\n        "timeframe": "6-12 months",\n        "strategic_implications": "What this means for the business"\n      }}\n    ]\n  }},\n  "risk_assessment": [\n    {{\n      "risk": "Risk description",\n      "category": "financial | operational | market | regulatory | supply_chain",\n      "likelihood": "low | medium | high",\n      "impact": "low | medium | high",\n      "risk_score": 7,\n      "early_warning_indicators": ["Indicator 1", "Indicator 2"],\n      "mitigation_strategy": "How to mitigate",\n      "contingency_plan": "Backup plan if risk materializes",\n      "responsible_party": "Who owns this risk"\n    }}\n  ],\n  "strategic_recommendations": [\n    {{\n      "recommendation": "Clear, actionable recommendation",\n      "rationale": "Why this recommendation makes sense",\n      "expected_impact": {{\n        "revenue_impact": 5000,\n        "profit_impact": 1500,\n        "kpi_improvements": {{"kpi": "improvement"}}\n      }},\n      "implementation_cost": 2000,\n      "implementation_timeframe_months": 3,\n      "implementation_difficulty": "low | medium | high",\n      "priority": "high | medium | low",\n      "dependencies": ["Dependency 1", "Dependency 2"],\n      "success_metrics": ["Metric 1", "Metric 2"]\n    }}\n  ],\n  "cash_flow_analysis": {{\n    "current_cash_position": 50000,\n    "monthly_cash_burn": 5000,\n    "runway_months": 10,\n    "cash_flow_forecast": [\n      {{"month": "Month 1", "inflow": 30000, "outflow": 25000, "net": 5000, "ending_balance": 55000}}\n    ],\n    "working_capital_needs": 15000,\n    "financing_recommendations": "Any financing needs or recommendations"\n  }}\n}}\n\n## Business Rules\n1. All financial figures must be internally consistent and mathematically verifiable\n2. Forecasts must include confidence levels and key assumptions\n3. Risk assessments must include both likelihood and impact, with mitigation strategies\n4. Strategic recommendations must be specific, actionable, and include expected ROI\n5. KPI assessments must compare against benchmarks or targets, not just report values\n6. All analysis must consider the outdoor/camping e-commerce context and seasonality\n7. Cash flow analysis must be conservative and include working capital needs\n8. No recommendation should be made without clear rationale and expected impact\n\n## Context\n{context_json}\n\n## Output Schema\n{output_schema}\n\nAnalyze the context and provide your comprehensive business analysis and recommendations as valid JSON only.	["context_json", "output_schema"]	active	AI Business Analyst for Nuotao Outdoor - financial analysis, KPI tracking, trend forecasting, risk assessment, and strategic recommendations	init-all-agents	2026-09-01 17:34:13.676261+08	2026-09-01 18:12:54.295316+08
1e69b597-c94d-4d45-99e6-dcd90dca4014	00000000-0000-0000-0000-000000000001	m6-activity-planner-v1	ACTIVITY_PLANNER_V1	v1	You are a senior e-commerce marketing strategist for Nuotao Outdoor, an outdoor gear DTC brand.\n\nGenerate a comprehensive campaign plan for the following activity:\n\n- Activity name: {activity_name}\n- Activity type: {activity_type}\n- Total budget: ${budget_total}\n- Target audience: {target_audience}\n- Campaign goals: {goals}\n- Brand: Nuotao Outdoor (outdoor gear DTC)\n- Market: US/EU cross-border e-commerce\n\nProduce a structured JSON plan with these sections:\n1. summary: 2-3 sentence executive summary\n2. objectives: 3-5 measurable SMART objectives\n3. target_audience: detailed persona and segmentation\n4. channels: channel mix with budget allocation (% and $)\n5. timeline: phase-by-phase schedule with key dates\n6. creative_concepts: 3-5 creative angles with ad copy examples\n7. promotion_mechanics: discount structure, bundles, urgency tactics\n8. kpi_targets: expected CTR, CVR, ROAS, CPA, revenue\n9. risk_factors: top 3 risks and mitigation strategies\n10. success_criteria: how to measure ROI and post-campaign learnings\n\nRules:\n- All budget allocations must sum to the total budget.\n- Be specific with numbers, dates, and channel names.\n- Do not promise guaranteed results; use ranges and estimates.\n- Respond ONLY with a valid JSON object matching the output schema.\n- All text in English unless the target market explicitly requires another language.	["activity_name", "activity_type", "budget_total", "target_audience", "goals"]	active	M6: AI e-commerce campaign plan generator. Produces structured, budget-aware marketing activity proposals that enter the approval queue before execution.	seed-m6-prompts	2026-09-02 12:05:30.122609+08	2026-09-02 12:05:30.122609+08
9a34d216-98a0-4255-a8cb-6005afcb237c	00000000-0000-0000-0000-000000000001	m6-listing-localization-v1	LISTING_LOCALIZATION_V1	v1	You are a professional e-commerce copywriter and localization expert for Nuotao Outdoor, an outdoor gear DTC brand.\n\nLocalize the following product listing for {target_language_name} speaking customers in the {target_market} market.\n\nSOURCE LISTING:\n- Product name: {product_name}\n- Product category: {product_category}\n- Source title: {source_title}\n- Source description: {source_description}\n- Source bullet points: {source_bullets}\n- Source SEO keywords: {source_keywords}\n\nLOCALIZATION REQUIREMENTS:\n- Target language: {target_language} ({target_language_name})\n- Target market: {target_market}\n- Brand: Nuotao Outdoor\n- Do NOT translate literally — adapt the copy to local consumer preferences, cultural norms, and buying behavior.\n- Research and use locally relevant SEO keywords for this product category in the target language.\n- Adjust tone and formality to match local e-commerce conventions.\n- Keep all product specifications (sizes, materials, weights) accurate.\n- Maximum title length: 120 characters.\n- Maximum meta title: 60 characters.\n- Maximum meta description: 160 characters.\n- 5-7 bullet points, each highlighting a key benefit (not just features).\n\nOUTPUT JSON SCHEMA:\n- title: localized product title\n- short_description: localized short description (max 300 chars)\n- long_description: localized long description with basic HTML formatting\n- bullet_points: array of 5-7 localized bullet points\n- seo_keywords: array of target SEO keywords for this language/market\n- meta_title: SEO meta title (max 60 chars)\n- meta_description: SEO meta description (max 160 chars)\n- localization_notes: notes on cultural adaptation, local preferences, or market-specific changes\n- confidence_score: number 0-1 indicating localization confidence\n\nRespond ONLY with a valid JSON object matching the schema. All output fields must be in {target_language_name} except localization_notes which may be in English for internal review.	["product_name", "product_category", "source_title", "source_description", "source_bullets", "source_keywords", "target_language", "target_language_name", "target_market"]	active	M6: Multi-language product listing localizer. Adapts copy to local consumer preferences, SEO keywords, and cultural norms (not literal translation).	seed-m6-prompts	2026-09-02 12:05:30.136317+08	2026-09-02 12:05:30.136317+08
7272de1c-daa1-4657-85ea-929669d1df49	00000000-0000-0000-0000-000000000001	m6-customer-response-v1	CUSTOMER_RESPONSE_V1	v1	You are a professional customer service representative for Nuotao Outdoor, an outdoor gear DTC brand.\n\nWrite a customer service response in {language_name} ({language}) with a {tone} tone.\n\nCUSTOMER INFORMATION:\n- Customer name: {customer_name}\n- Order ID: {order_id}\n- Product: {product_name}\n\nCUSTOMER MESSAGE:\n{customer_message}\n\nADDITIONAL CONTEXT:\n{context}\n\nRESPONSE REQUIREMENTS:\n- Language: {language_name}\n- Tone: {tone} (empathetic, professional, apologetic, or friendly)\n- Brand: Nuotao Outdoor — outdoor gear experts who care about our customers\n- Be empathetic and acknowledge the customer's concern first.\n- Provide clear, actionable next steps.\n- Never promise refunds, discounts, or free shipping beyond standard policy.\n- If the issue is complex or requires investigation, say so and give a timeline.\n- Keep the response concise but complete (150-300 words).\n- Include a clear subject line.\n- Sign off as "Nuotao Outdoor Customer Service".\n\nOUTPUT JSON SCHEMA:\n- subject: email subject line\n- greeting: personalized greeting\n- body: main response body\n- closing: closing and signature\n- tone: one of: empathetic, professional, apologetic, friendly\n- next_steps: array of clear next steps for the customer\n- escalation_needed: boolean — true if this should be escalated to a human agent\n\nRespond ONLY with a valid JSON object matching the schema. The entire response (subject, greeting, body, closing) must be in {language_name}.	["customer_name", "order_id", "product_name", "customer_message", "context", "language", "language_name", "tone"]	active	M6: Customer service response generator. Produces empathetic, brand-aligned customer replies in multiple languages for non-standard inquiries.	seed-m6-prompts	2026-09-02 12:05:30.143347+08	2026-09-02 12:05:30.143347+08
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_order_items (id, workspace_id, purchase_order_id, product_id, sku, name, quantity, unit_cost, line_total) FROM stdin;
e1c940dd-d282-4819-9ead-0e776c88f72e	00000000-0000-0000-0000-000000000001	8c2c4080-4a27-49a5-8650-8fb1261e4982	\N	NT-TOOL-001	Multi-tool Camping Knife - 15 Functions	1	12.00	12.00
f08ea1c0-62b1-4431-bdd1-4036ccd30771	00000000-0000-0000-0000-000000000001	a57631af-4caf-47a0-b005-f11b267bd628	bb07802a-b3c5-4a0b-9f50-d65c9c95e4d2	TEST-TENT-001	?????? / Test Outdoor Tent	10	25.00	250.00
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, workspace_id, po_number, supplier_id, status, currency, subtotal, shipping_cost, total, expected_delivery_at, received_at, notes, trace_id, created_at, updated_at) FROM stdin;
8c2c4080-4a27-49a5-8650-8fb1261e4982	00000000-0000-0000-0000-000000000001	PO-872-1788279296	\N	ordered	USD	12.00	5.00	17.00	2026-09-08 16:14:56.102399+08	\N	Auto-generated from order_id=872, trace_id=c049b6b9647e4928a8c0fb6cb743a558	\N	2026-09-02 00:14:56.080055+08	2026-09-02 00:15:21.254576+08
a57631af-4caf-47a0-b005-f11b267bd628	00000000-0000-0000-0000-000000000001	PO-AUTO-1788280774	\N	approved	USD	250.00	0.00	250.00	2026-09-15 16:39:34.406386+08	\N	Auto-generated by purchase automation. Anomalies: 2	\N	2026-09-02 00:39:34.402314+08	2026-09-02 00:39:34.402314+08
\.


--
-- Data for Name: refund_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refund_cases (id, workspace_id, order_id, product_id, reason, category, amount, resolution, trace_id, created_at, updated_at, customer_id) FROM stdin;
\.


--
-- Data for Name: rule_execution_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rule_execution_logs (id, workspace_id, rule_id, rule_version, context, result, trace_id, created_at) FROM stdin;
1	00000000-0000-0000-0000-000000000001	PROD-GATE-001	v1	{"cost": {"total_cost": 199.99}, "profit": {"cost_status": "KNOWN", "margin_rate": 0.3994113937355476}, "product": {"weight_kg": 2.5}, "logistics": {"weight_kg": 2.5, "shipping_ratio": null}}	{"name": "Product cost data must be complete and verifiable", "score": null, "passed": true, "reasons": ["cost data available"], "rule_id": "PROD-GATE-001", "trace_id": "b960a7b7c3af48d380d2e6c57366441b", "rule_type": "hard", "rule_version": "v1"}	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:30.978309+08
2	00000000-0000-0000-0000-000000000001	PROD-GATE-002	v1	{"cost": {"total_cost": 199.99}, "profit": {"cost_status": "KNOWN", "margin_rate": 0.3994113937355476}, "product": {"weight_kg": 2.5}, "logistics": {"weight_kg": 2.5, "shipping_ratio": null}}	{"name": "Shipping must stay within 40% of expected price", "score": null, "passed": false, "reasons": ["shipping ratio exceeds 40%"], "rule_id": "PROD-GATE-002", "trace_id": "b960a7b7c3af48d380d2e6c57366441b", "rule_type": "hard", "rule_version": "v1"}	b960a7b7c3af48d380d2e6c57366441b	2026-09-01 16:33:30.978309+08
3	00000000-0000-0000-0000-000000000001	PRICE-001	v1	{"price": {"discount_ratio": 0.0, "discount_total": "0"}, "profit": {"cost_status": "UNKNOWN", "profit_confidence": "LOW", "contribution_margin_rate": 0.9672418104526131}, "fulfillment": {"order_status": "processing", "payment_status": "processing"}}	{"name": "Order discount ratio must not exceed 30%", "score": null, "passed": true, "reasons": ["discount ratio within limit"], "rule_id": "PRICE-001", "trace_id": "597c0565591b4474ae857ae0067cb24d", "rule_type": "hard", "rule_version": "v1"}	597c0565591b4474ae857ae0067cb24d	2026-09-02 09:42:18.184198+08
4	00000000-0000-0000-0000-000000000001	PROFIT-002	v1	{"price": {"discount_ratio": 0.0, "discount_total": "0"}, "profit": {"cost_status": "UNKNOWN", "profit_confidence": "LOW", "contribution_margin_rate": 0.9672418104526131}, "fulfillment": {"order_status": "processing", "payment_status": "processing"}}	{"name": "Contribution margin rate must be >= 20%", "score": null, "passed": true, "reasons": ["margin rate acceptable"], "rule_id": "PROFIT-002", "trace_id": "597c0565591b4474ae857ae0067cb24d", "rule_type": "hard", "rule_version": "v1"}	597c0565591b4474ae857ae0067cb24d	2026-09-02 09:42:18.219507+08
5	00000000-0000-0000-0000-000000000001	PROFIT-003	v1	{"price": {"discount_ratio": 0.0, "discount_total": "0"}, "profit": {"cost_status": "UNKNOWN", "profit_confidence": "LOW", "contribution_margin_rate": 0.9672418104526131}, "fulfillment": {"order_status": "processing", "payment_status": "processing"}}	{"name": "Profit conclusion requires non-unknown product cost", "score": null, "passed": false, "reasons": ["product cost is UNKNOWN; profit conclusion withheld"], "rule_id": "PROFIT-003", "trace_id": "597c0565591b4474ae857ae0067cb24d", "rule_type": "hard", "rule_version": "v1"}	597c0565591b4474ae857ae0067cb24d	2026-09-02 09:42:18.219507+08
6	00000000-0000-0000-0000-000000000001	FULFILLMENT-001	v1	{"price": {"discount_ratio": 0.0, "discount_total": "0"}, "profit": {"cost_status": "UNKNOWN", "profit_confidence": "LOW", "contribution_margin_rate": 0.9672418104526131}, "fulfillment": {"order_status": "processing", "payment_status": "processing"}}	{"name": "Payment status must be payable to fulfill", "score": null, "passed": true, "reasons": ["payment status payable"], "rule_id": "FULFILLMENT-001", "trace_id": "597c0565591b4474ae857ae0067cb24d", "rule_type": "hard", "rule_version": "v1"}	597c0565591b4474ae857ae0067cb24d	2026-09-02 09:42:18.226272+08
\.


--
-- Data for Name: rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rules (id, workspace_id, rule_id, name, category, rule_type, version, status, effective_from, effective_to, scope, when_conditions, then_result, params, approval_level, owner, created_at, updated_at) FROM stdin;
10000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	PROD-SEL-005	Logistics constraint: shipping <= 40% of price	PROD-SEL	hard	v1	active	\N	\N	{}	{"op": "lte", "field": "cost.shipping_ratio", "value": 0.4}	{"failed_message": "shipping ratio exceeds 40%", "passed_message": "shipping ratio within limit"}	{}	L0	\N	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
10000000-0000-0000-0000-000000000002	00000000-0000-0000-0000-000000000001	PROD-SCORE-001	Profit potential scoring (margin >= 45% scores 10)	PROD-SCORE	soft	v1	active	\N	\N	{}	{"op": "gte", "field": "cost.target_margin", "value": 0.45}	{"score": 10, "weight": 3}	{"weight": 3, "fail_score": 4, "pass_score": 10}	L0	\N	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
10000000-0000-0000-0000-000000000003	00000000-0000-0000-0000-000000000001	PRICE-001	Order discount ratio must not exceed 30%	PRICE	hard	v1	active	\N	\N	{}	{"op": "lte", "field": "price.discount_ratio", "value": 0.3}	{"failed_message": "discount ratio exceeds 30%", "passed_message": "discount ratio within limit"}	{}	L0	\N	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
10000000-0000-0000-0000-000000000004	00000000-0000-0000-0000-000000000001	PROFIT-002	Contribution margin rate must be >= 20%	PROFIT	hard	v1	active	\N	\N	{}	{"op": "gte", "field": "profit.contribution_margin_rate", "value": 0.2}	{"failed_message": "margin rate below 20%", "passed_message": "margin rate acceptable"}	{}	L0	\N	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
10000000-0000-0000-0000-000000000005	00000000-0000-0000-0000-000000000001	FULFILLMENT-001	Payment status must be payable to fulfill	FULFILLMENT	hard	v1	active	\N	\N	{}	{"op": "in", "field": "fulfillment.payment_status", "value": ["processing", "completed"]}	{"failed_message": "payment status not payable", "passed_message": "payment status payable"}	{}	L0	\N	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
10000000-0000-0000-0000-000000000006	00000000-0000-0000-0000-000000000001	PROFIT-003	Profit conclusion requires non-unknown product cost	PROFIT	hard	v1	active	\N	\N	{}	{"op": "in", "field": "profit.cost_status", "value": ["KNOWN", "ESTIMATED"]}	{"failed_message": "product cost is UNKNOWN; profit conclusion withheld", "passed_message": "product cost is known enough for a profit conclusion"}	{}	L0	\N	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
10000000-0000-0000-0000-000000000007	00000000-0000-0000-0000-000000000001	PROD-GATE-001	Product cost data must be complete and verifiable	PRODUCT	hard	v1	active	\N	\N	{}	{"op": "gt", "field": "cost.total_cost", "value": 0}	{"failed_message": "cost data missing", "passed_message": "cost data available"}	{}	L0	\N	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
10000000-0000-0000-0000-000000000008	00000000-0000-0000-0000-000000000001	PROD-GATE-002	Shipping must stay within 40% of expected price	PRODUCT	hard	v1	active	\N	\N	{}	{"op": "lte", "field": "logistics.shipping_ratio", "value": 0.4}	{"failed_message": "shipping ratio exceeds 40%", "passed_message": "shipping ratio within limit"}	{}	L0	\N	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
\.


--
-- Data for Name: score_calibration_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.score_calibration_runs (id, workspace_id, status, model_version, current_weights, suggested_weights, input_snapshot, metrics, sample_size, rationale, approved_by, approved_at, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shipment_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipment_records (id, workspace_id, purchase_order_id, carrier, origin, destination, tracking_number, status, ship_date, delivery_time_days, delay_reason, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supplier_ai_evaluations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_ai_evaluations (id, workspace_id, supplier_id, prediction, actual_result, accuracy, prediction_result, error_type, confidence, confidence_bucket, success_flag, metric_snapshot, human_rating, notes, trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: supplier_pattern_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_pattern_runs (id, workspace_id, supplier_id, pattern_type, input_snapshot, output_pattern, confidence, sample_size, status, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supplier_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_profiles (id, workspace_id, supplier_id, category, location, lead_time_days, minimum_order_qty, quality_score, on_time_rate, defect_rate, certifications, risk_level, trace_id, created_at, updated_at, factory_type) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, workspace_id, code, name, platform, shop_url, rating, status, contact, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supply_chain_calibration_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_chain_calibration_runs (id, workspace_id, status, model_version, input_snapshot, successful_patterns, failure_patterns, metrics, sample_size, rationale, approved_by, approved_at, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supply_chain_knowledge_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_chain_knowledge_entries (id, workspace_id, supplier_id, product_id, category, entry_type, title, content, tags, source, confidence, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, full_name, hashed_password, role, is_active, last_login_at, created_at, updated_at) FROM stdin;
ed6554d8-8673-476b-b9fb-d46c4ca24575	db_test_user	dbtest@nuotao.com	???????	$2b$12$6uvpx55hWPXHw.alJlhu1eSAsPCPRvYTLvu5gD.PWyeiddrWj4FhG	viewer	t	\N	2026-09-02 09:40:25.525432+08	2026-09-02 09:40:25.525432+08
3c4ba26f-715d-42eb-9b79-ee44244f0e3d	admin	admin@nuotao.com	系统管理员	$2b$12$HQ.eXenug3gcUS/6pYpoEu0g0YnDa9UyE.YWRZ3JD3lk1CmIJtzrK	admin	t	2026-09-02 09:41:14.516643+08	2026-09-02 09:40:00.070495+08	2026-09-02 09:41:14.157709+08
\.


--
-- Data for Name: woocommerce_draft_payloads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.woocommerce_draft_payloads (id, workspace_id, product_id, sku, name, payload, status, created_by, approved_by, approved_at, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workspace_identity_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspace_identity_links (id, workspace_id, organization_id, role, mapping_metadata, enabled, trace_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspaces (id, name, code, market, currency, status, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	Default Workspace	default	US	USD	active	2026-09-01 16:04:50.887808+08	2026-09-01 16:04:50.887808+08
\.


--
-- Name: ai_agent_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_agent_runs_id_seq', 8, true);


--
-- Name: event_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.event_log_id_seq', 224, true);


--
-- Name: rule_execution_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rule_execution_logs_id_seq', 6, true);


--
-- Name: activity_plans activity_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_plans
    ADD CONSTRAINT activity_plans_pkey PRIMARY KEY (id);


--
-- Name: agent_alerts agent_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_alerts
    ADD CONSTRAINT agent_alerts_pkey PRIMARY KEY (id);


--
-- Name: agent_approval_roles agent_approval_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_approval_roles
    ADD CONSTRAINT agent_approval_roles_pkey PRIMARY KEY (id);


--
-- Name: agent_approval_slas agent_approval_slas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_approval_slas
    ADD CONSTRAINT agent_approval_slas_pkey PRIMARY KEY (id);


--
-- Name: agent_approvals agent_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_approvals
    ADD CONSTRAINT agent_approvals_pkey PRIMARY KEY (id);


--
-- Name: agent_budget_policies agent_budget_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_budget_policies
    ADD CONSTRAINT agent_budget_policies_pkey PRIMARY KEY (id);


--
-- Name: agent_evaluations agent_evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_evaluations
    ADD CONSTRAINT agent_evaluations_pkey PRIMARY KEY (id);


--
-- Name: agent_execution_policies agent_execution_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_execution_policies
    ADD CONSTRAINT agent_execution_policies_pkey PRIMARY KEY (id);


--
-- Name: agent_executions agent_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_pkey PRIMARY KEY (id);


--
-- Name: agent_memory agent_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_pkey PRIMARY KEY (id);


--
-- Name: agent_metrics agent_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_metrics
    ADD CONSTRAINT agent_metrics_pkey PRIMARY KEY (id);


--
-- Name: agent_retry_policies agent_retry_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_retry_policies
    ADD CONSTRAINT agent_retry_policies_pkey PRIMARY KEY (id);


--
-- Name: agent_task_attempts agent_task_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_attempts
    ADD CONSTRAINT agent_task_attempts_pkey PRIMARY KEY (id);


--
-- Name: agent_tasks agent_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tasks
    ADD CONSTRAINT agent_tasks_pkey PRIMARY KEY (id);


--
-- Name: agent_tools agent_tools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT agent_tools_pkey PRIMARY KEY (id);


--
-- Name: agent_versions agent_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT agent_versions_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: ai_agent_runs ai_agent_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_agent_runs
    ADD CONSTRAINT ai_agent_runs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: business_recommendations business_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_recommendations
    ADD CONSTRAINT business_recommendations_pkey PRIMARY KEY (id);


--
-- Name: campaign_ai_evaluations campaign_ai_evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_ai_evaluations
    ADD CONSTRAINT campaign_ai_evaluations_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: confidence_calibration confidence_calibration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.confidence_calibration
    ADD CONSTRAINT confidence_calibration_pkey PRIMARY KEY (id);


--
-- Name: connector_runs connector_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_runs
    ADD CONSTRAINT connector_runs_pkey PRIMARY KEY (id);


--
-- Name: creative_analysis_runs creative_analysis_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.creative_analysis_runs
    ADD CONSTRAINT creative_analysis_runs_pkey PRIMARY KEY (id);


--
-- Name: creative_assets creative_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.creative_assets
    ADD CONSTRAINT creative_assets_pkey PRIMARY KEY (id);


--
-- Name: customer_ai_evaluations customer_ai_evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ai_evaluations
    ADD CONSTRAINT customer_ai_evaluations_pkey PRIMARY KEY (id);


--
-- Name: customer_calibration_runs customer_calibration_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_calibration_runs
    ADD CONSTRAINT customer_calibration_runs_pkey PRIMARY KEY (id);


--
-- Name: customer_feedback customer_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_feedback
    ADD CONSTRAINT customer_feedback_pkey PRIMARY KEY (id);


--
-- Name: customer_interactions customer_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_interactions
    ADD CONSTRAINT customer_interactions_pkey PRIMARY KEY (id);


--
-- Name: customer_knowledge_entries customer_knowledge_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_knowledge_entries
    ADD CONSTRAINT customer_knowledge_entries_pkey PRIMARY KEY (id);


--
-- Name: customer_pattern_runs customer_pattern_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_pattern_runs
    ADD CONSTRAINT customer_pattern_runs_pkey PRIMARY KEY (id);


--
-- Name: customer_profiles customer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT customer_profiles_pkey PRIMARY KEY (id);


--
-- Name: event_log event_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_log
    ADD CONSTRAINT event_log_pkey PRIMARY KEY (id);


--
-- Name: image_generation_tasks image_generation_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_generation_tasks
    ADD CONSTRAINT image_generation_tasks_pkey PRIMARY KEY (id);


--
-- Name: influencer_collaborations influencer_collaborations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.influencer_collaborations
    ADD CONSTRAINT influencer_collaborations_pkey PRIMARY KEY (id);


--
-- Name: influencers influencers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.influencers
    ADD CONSTRAINT influencers_pkey PRIMARY KEY (id);


--
-- Name: inventory_snapshots inventory_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_snapshots
    ADD CONSTRAINT inventory_snapshots_pkey PRIMARY KEY (id);


--
-- Name: logistics_ai_evaluations logistics_ai_evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_ai_evaluations
    ADD CONSTRAINT logistics_ai_evaluations_pkey PRIMARY KEY (id);


--
-- Name: logistics_events logistics_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_events
    ADD CONSTRAINT logistics_events_pkey PRIMARY KEY (id);


--
-- Name: logistics_pattern_runs logistics_pattern_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_pattern_runs
    ADD CONSTRAINT logistics_pattern_runs_pkey PRIMARY KEY (id);


--
-- Name: marketing_calibration_runs marketing_calibration_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_calibration_runs
    ADD CONSTRAINT marketing_calibration_runs_pkey PRIMARY KEY (id);


--
-- Name: marketing_experiments marketing_experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_experiments
    ADD CONSTRAINT marketing_experiments_pkey PRIMARY KEY (id);


--
-- Name: marketing_knowledge_entries marketing_knowledge_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_knowledge_entries
    ADD CONSTRAINT marketing_knowledge_entries_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: product_ai_evaluations product_ai_evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ai_evaluations
    ADD CONSTRAINT product_ai_evaluations_pkey PRIMARY KEY (id);


--
-- Name: product_analysis_runs product_analysis_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_analysis_runs
    ADD CONSTRAINT product_analysis_runs_pkey PRIMARY KEY (id);


--
-- Name: product_cost product_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_cost
    ADD CONSTRAINT product_cost_pkey PRIMARY KEY (id);


--
-- Name: product_cost_snapshots product_cost_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_cost_snapshots
    ADD CONSTRAINT product_cost_snapshots_pkey PRIMARY KEY (id);


--
-- Name: product_decisions product_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_decisions
    ADD CONSTRAINT product_decisions_pkey PRIMARY KEY (id);


--
-- Name: product_experiments product_experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_experiments
    ADD CONSTRAINT product_experiments_pkey PRIMARY KEY (id);


--
-- Name: product_knowledge_entries product_knowledge_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_knowledge_entries
    ADD CONSTRAINT product_knowledge_entries_pkey PRIMARY KEY (id);


--
-- Name: product_reviews product_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT product_reviews_pkey PRIMARY KEY (id);


--
-- Name: product_score_evidences product_score_evidences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_score_evidences
    ADD CONSTRAINT product_score_evidences_pkey PRIMARY KEY (id);


--
-- Name: product_scores product_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_scores
    ADD CONSTRAINT product_scores_pkey PRIMARY KEY (id);


--
-- Name: product_sources product_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sources
    ADD CONSTRAINT product_sources_pkey PRIMARY KEY (id);


--
-- Name: product_sourcing_candidates product_sourcing_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sourcing_candidates
    ADD CONSTRAINT product_sourcing_candidates_pkey PRIMARY KEY (id);


--
-- Name: product_validation_cases product_validation_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_validation_cases
    ADD CONSTRAINT product_validation_cases_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: prompts prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: refund_cases refund_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_cases
    ADD CONSTRAINT refund_cases_pkey PRIMARY KEY (id);


--
-- Name: rule_execution_logs rule_execution_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_execution_logs
    ADD CONSTRAINT rule_execution_logs_pkey PRIMARY KEY (id);


--
-- Name: rules rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_pkey PRIMARY KEY (id);


--
-- Name: score_calibration_runs score_calibration_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.score_calibration_runs
    ADD CONSTRAINT score_calibration_runs_pkey PRIMARY KEY (id);


--
-- Name: shipment_records shipment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_records
    ADD CONSTRAINT shipment_records_pkey PRIMARY KEY (id);


--
-- Name: supplier_ai_evaluations supplier_ai_evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_ai_evaluations
    ADD CONSTRAINT supplier_ai_evaluations_pkey PRIMARY KEY (id);


--
-- Name: supplier_pattern_runs supplier_pattern_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_pattern_runs
    ADD CONSTRAINT supplier_pattern_runs_pkey PRIMARY KEY (id);


--
-- Name: supplier_profiles supplier_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_profiles
    ADD CONSTRAINT supplier_profiles_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: supply_chain_calibration_runs supply_chain_calibration_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_chain_calibration_runs
    ADD CONSTRAINT supply_chain_calibration_runs_pkey PRIMARY KEY (id);


--
-- Name: supply_chain_knowledge_entries supply_chain_knowledge_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_chain_knowledge_entries
    ADD CONSTRAINT supply_chain_knowledge_entries_pkey PRIMARY KEY (id);


--
-- Name: agent_approval_roles uq_agent_approval_roles_ws_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_approval_roles
    ADD CONSTRAINT uq_agent_approval_roles_ws_name UNIQUE (workspace_id, role_name);


--
-- Name: agent_approval_slas uq_agent_approval_slas_ws_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_approval_slas
    ADD CONSTRAINT uq_agent_approval_slas_ws_type UNIQUE (workspace_id, approval_type);


--
-- Name: agent_budget_policies uq_agent_budget_pol_ws_agent_ver; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_budget_policies
    ADD CONSTRAINT uq_agent_budget_pol_ws_agent_ver UNIQUE (workspace_id, agent_id, policy_version);


--
-- Name: agent_execution_policies uq_agent_exec_pol_ws_agent_ver; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_execution_policies
    ADD CONSTRAINT uq_agent_exec_pol_ws_agent_ver UNIQUE (workspace_id, agent_id, policy_version);


--
-- Name: agent_metrics uq_agent_metrics_ws_agent_date; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_metrics
    ADD CONSTRAINT uq_agent_metrics_ws_agent_date UNIQUE (workspace_id, agent_id, metric_date);


--
-- Name: agent_retry_policies uq_agent_retry_pol_ws_code_ver; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_retry_policies
    ADD CONSTRAINT uq_agent_retry_pol_ws_code_ver UNIQUE (workspace_id, retry_policy_id, version);


--
-- Name: agent_tools uq_agent_tools_workspace_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT uq_agent_tools_workspace_name UNIQUE (workspace_id, tool_name);


--
-- Name: agent_versions uq_agent_versions_ws_agent_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT uq_agent_versions_ws_agent_version UNIQUE (workspace_id, agent_id, version);


--
-- Name: agents uq_agents_workspace_agent_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT uq_agents_workspace_agent_id UNIQUE (workspace_id, agent_id);


--
-- Name: campaigns uq_campaigns_workspace_platform_campaign; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT uq_campaigns_workspace_platform_campaign UNIQUE (workspace_id, platform, campaign_id);


--
-- Name: confidence_calibration uq_confidence_calibration_workspace_bucket; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.confidence_calibration
    ADD CONSTRAINT uq_confidence_calibration_workspace_bucket UNIQUE (workspace_id, bucket);


--
-- Name: customer_profiles uq_customer_profiles_workspace_reference; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT uq_customer_profiles_workspace_reference UNIQUE (workspace_id, customer_reference_id);


--
-- Name: inventory_snapshots uq_inventory_workspace_product_location; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_snapshots
    ADD CONSTRAINT uq_inventory_workspace_product_location UNIQUE (workspace_id, product_id, location);


--
-- Name: orders uq_orders_workspace_external; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT uq_orders_workspace_external UNIQUE (workspace_id, external_order_id);


--
-- Name: products uq_products_workspace_sku; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT uq_products_workspace_sku UNIQUE (workspace_id, sku);


--
-- Name: prompts uq_prompts_workspace_name_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT uq_prompts_workspace_name_version UNIQUE (workspace_id, name, version);


--
-- Name: purchase_orders uq_purchase_orders_workspace_po; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT uq_purchase_orders_workspace_po UNIQUE (workspace_id, po_number);


--
-- Name: rules uq_rules_workspace_rule_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT uq_rules_workspace_rule_version UNIQUE (workspace_id, rule_id, version);


--
-- Name: supplier_profiles uq_supplier_profiles_workspace_supplier; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_profiles
    ADD CONSTRAINT uq_supplier_profiles_workspace_supplier UNIQUE (workspace_id, supplier_id);


--
-- Name: suppliers uq_suppliers_workspace_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT uq_suppliers_workspace_code UNIQUE (workspace_id, code);


--
-- Name: workspace_identity_links uq_workspace_identity_links_ws_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_identity_links
    ADD CONSTRAINT uq_workspace_identity_links_ws_org UNIQUE (workspace_id, organization_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: woocommerce_draft_payloads woocommerce_draft_payloads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.woocommerce_draft_payloads
    ADD CONSTRAINT woocommerce_draft_payloads_pkey PRIMARY KEY (id);


--
-- Name: workspace_identity_links workspace_identity_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_identity_links
    ADD CONSTRAINT workspace_identity_links_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_code_key UNIQUE (code);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: ix_activity_plans_parent_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_plans_parent_plan_id ON public.activity_plans USING btree (parent_plan_id);


--
-- Name: ix_activity_plans_workspace_approval; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_plans_workspace_approval ON public.activity_plans USING btree (workspace_id, approval_status);


--
-- Name: ix_activity_plans_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_plans_workspace_id ON public.activity_plans USING btree (workspace_id);


--
-- Name: ix_activity_plans_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_plans_workspace_status ON public.activity_plans USING btree (workspace_id, status);


--
-- Name: ix_activity_plans_workspace_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_plans_workspace_type ON public.activity_plans USING btree (workspace_id, activity_type);


--
-- Name: ix_agent_alerts_ws_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_alerts_ws_agent ON public.agent_alerts USING btree (workspace_id, agent_id);


--
-- Name: ix_agent_alerts_ws_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_alerts_ws_status ON public.agent_alerts USING btree (workspace_id, status);


--
-- Name: ix_agent_alerts_ws_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_alerts_ws_type ON public.agent_alerts USING btree (workspace_id, alert_type);


--
-- Name: ix_agent_approval_roles_ws_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_approval_roles_ws_enabled ON public.agent_approval_roles USING btree (workspace_id, enabled);


--
-- Name: ix_agent_approval_slas_ws_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_approval_slas_ws_enabled ON public.agent_approval_slas USING btree (workspace_id, enabled);


--
-- Name: ix_agent_approvals_ws_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_approvals_ws_entity ON public.agent_approvals USING btree (workspace_id, entity_type, entity_id);


--
-- Name: ix_agent_approvals_ws_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_approvals_ws_status ON public.agent_approvals USING btree (workspace_id, status);


--
-- Name: ix_agent_approvals_ws_trace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_approvals_ws_trace ON public.agent_approvals USING btree (workspace_id, trace_id);


--
-- Name: ix_agent_approvals_ws_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_approvals_ws_type ON public.agent_approvals USING btree (workspace_id, approval_type);


--
-- Name: ix_agent_budget_pol_ws_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_budget_pol_ws_agent ON public.agent_budget_policies USING btree (workspace_id, agent_id);


--
-- Name: ix_agent_budget_pol_ws_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_budget_pol_ws_current ON public.agent_budget_policies USING btree (workspace_id, is_current);


--
-- Name: ix_agent_evaluations_workspace_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_evaluations_workspace_agent ON public.agent_evaluations USING btree (workspace_id, agent_id);


--
-- Name: ix_agent_evaluations_workspace_bucket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_evaluations_workspace_bucket ON public.agent_evaluations USING btree (workspace_id, confidence_bucket);


--
-- Name: ix_agent_exec_pol_ws_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_exec_pol_ws_agent ON public.agent_execution_policies USING btree (workspace_id, agent_id);


--
-- Name: ix_agent_exec_pol_ws_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_exec_pol_ws_current ON public.agent_execution_policies USING btree (workspace_id, is_current);


--
-- Name: ix_agent_executions_workspace_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_executions_workspace_agent ON public.agent_executions USING btree (workspace_id, agent_id);


--
-- Name: ix_agent_executions_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_executions_workspace_status ON public.agent_executions USING btree (workspace_id, status);


--
-- Name: ix_agent_memory_workspace_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_memory_workspace_agent ON public.agent_memory USING btree (workspace_id, agent_id);


--
-- Name: ix_agent_memory_workspace_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_memory_workspace_domain ON public.agent_memory USING btree (workspace_id, domain);


--
-- Name: ix_agent_metrics_ws_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_metrics_ws_agent ON public.agent_metrics USING btree (workspace_id, agent_id);


--
-- Name: ix_agent_retry_pol_ws_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_retry_pol_ws_current ON public.agent_retry_policies USING btree (workspace_id, is_current);


--
-- Name: ix_agent_task_attempts_ws_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_task_attempts_ws_status ON public.agent_task_attempts USING btree (workspace_id, status);


--
-- Name: ix_agent_task_attempts_ws_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_task_attempts_ws_task ON public.agent_task_attempts USING btree (workspace_id, task_id);


--
-- Name: ix_agent_tasks_workspace_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_tasks_workspace_agent ON public.agent_tasks USING btree (workspace_id, agent_id);


--
-- Name: ix_agent_tasks_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_tasks_workspace_status ON public.agent_tasks USING btree (workspace_id, status);


--
-- Name: ix_agent_tools_workspace_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_tools_workspace_level ON public.agent_tools USING btree (workspace_id, permission_level);


--
-- Name: ix_agent_versions_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_versions_agent_id ON public.agent_versions USING btree (agent_id);


--
-- Name: ix_agent_versions_ws_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_versions_ws_status ON public.agent_versions USING btree (workspace_id, status);


--
-- Name: ix_agents_workspace_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agents_workspace_domain ON public.agents USING btree (workspace_id, domain);


--
-- Name: ix_ai_agent_runs_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_agent_runs_agent ON public.ai_agent_runs USING btree (agent);


--
-- Name: ix_ai_agent_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_agent_runs_created ON public.ai_agent_runs USING btree (workspace_id, created_at DESC);


--
-- Name: ix_campaign_evaluations_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_campaign_evaluations_campaign_id ON public.campaign_ai_evaluations USING btree (campaign_id);


--
-- Name: ix_campaign_evaluations_workspace_bucket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_campaign_evaluations_workspace_bucket ON public.campaign_ai_evaluations USING btree (workspace_id, confidence_bucket);


--
-- Name: ix_campaign_evaluations_workspace_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_campaign_evaluations_workspace_campaign ON public.campaign_ai_evaluations USING btree (workspace_id, campaign_id);


--
-- Name: ix_campaigns_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_campaigns_product_id ON public.campaigns USING btree (product_id);


--
-- Name: ix_campaigns_workspace_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_campaigns_workspace_platform ON public.campaigns USING btree (workspace_id, platform);


--
-- Name: ix_campaigns_workspace_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_campaigns_workspace_product ON public.campaigns USING btree (workspace_id, product_id);


--
-- Name: ix_collab_workspace_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_collab_workspace_activity ON public.influencer_collaborations USING btree (workspace_id, activity_plan_id);


--
-- Name: ix_collab_workspace_influencer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_collab_workspace_influencer ON public.influencer_collaborations USING btree (workspace_id, influencer_id);


--
-- Name: ix_collab_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_collab_workspace_status ON public.influencer_collaborations USING btree (workspace_id, status);


--
-- Name: ix_confidence_calibration_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_confidence_calibration_workspace ON public.confidence_calibration USING btree (workspace_id);


--
-- Name: ix_connector_runs_workspace_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_connector_runs_workspace_name ON public.connector_runs USING btree (workspace_id, connector_name);


--
-- Name: ix_connector_runs_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_connector_runs_workspace_status ON public.connector_runs USING btree (workspace_id, status);


--
-- Name: ix_creative_analysis_runs_creative_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_creative_analysis_runs_creative_id ON public.creative_analysis_runs USING btree (creative_id);


--
-- Name: ix_creative_analysis_workspace_creative; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_creative_analysis_workspace_creative ON public.creative_analysis_runs USING btree (workspace_id, creative_id);


--
-- Name: ix_creative_assets_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_creative_assets_product_id ON public.creative_assets USING btree (product_id);


--
-- Name: ix_creative_assets_workspace_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_creative_assets_workspace_platform ON public.creative_assets USING btree (workspace_id, platform);


--
-- Name: ix_creative_assets_workspace_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_creative_assets_workspace_product ON public.creative_assets USING btree (workspace_id, product_id);


--
-- Name: ix_customer_ai_evaluations_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_ai_evaluations_customer_id ON public.customer_ai_evaluations USING btree (customer_id);


--
-- Name: ix_customer_calibration_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_calibration_workspace_status ON public.customer_calibration_runs USING btree (workspace_id, status);


--
-- Name: ix_customer_evaluations_workspace_bucket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_evaluations_workspace_bucket ON public.customer_ai_evaluations USING btree (workspace_id, confidence_bucket);


--
-- Name: ix_customer_evaluations_workspace_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_evaluations_workspace_customer ON public.customer_ai_evaluations USING btree (workspace_id, customer_id);


--
-- Name: ix_customer_interactions_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_interactions_customer_id ON public.customer_interactions USING btree (customer_id);


--
-- Name: ix_customer_interactions_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_interactions_product_id ON public.customer_interactions USING btree (product_id);


--
-- Name: ix_customer_interactions_workspace_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_interactions_workspace_channel ON public.customer_interactions USING btree (workspace_id, channel);


--
-- Name: ix_customer_interactions_workspace_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_interactions_workspace_customer ON public.customer_interactions USING btree (workspace_id, customer_id);


--
-- Name: ix_customer_knowledge_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_knowledge_customer_id ON public.customer_knowledge_entries USING btree (customer_id);


--
-- Name: ix_customer_knowledge_entry_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_knowledge_entry_type ON public.customer_knowledge_entries USING btree (entry_type);


--
-- Name: ix_customer_knowledge_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_knowledge_product_id ON public.customer_knowledge_entries USING btree (product_id);


--
-- Name: ix_customer_knowledge_workspace_cat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_knowledge_workspace_cat ON public.customer_knowledge_entries USING btree (workspace_id, category);


--
-- Name: ix_customer_knowledge_workspace_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_knowledge_workspace_customer ON public.customer_knowledge_entries USING btree (workspace_id, customer_id);


--
-- Name: ix_customer_pattern_runs_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_pattern_runs_customer_id ON public.customer_pattern_runs USING btree (customer_id);


--
-- Name: ix_customer_pattern_runs_workspace_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_pattern_runs_workspace_type ON public.customer_pattern_runs USING btree (workspace_id, pattern_type);


--
-- Name: ix_customer_profiles_workspace_segment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_profiles_workspace_segment ON public.customer_profiles USING btree (workspace_id, segment);


--
-- Name: ix_event_log_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_log_entity ON public.event_log USING btree (entity_type, entity_id);


--
-- Name: ix_event_log_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_log_type ON public.event_log USING btree (event_type);


--
-- Name: ix_event_log_workspace_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_log_workspace_created ON public.event_log USING btree (workspace_id, created_at DESC);


--
-- Name: ix_feedback_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_feedback_product_id ON public.customer_feedback USING btree (product_id);


--
-- Name: ix_feedback_workspace_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_feedback_workspace_product ON public.customer_feedback USING btree (workspace_id, product_id);


--
-- Name: ix_feedback_workspace_sentiment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_feedback_workspace_sentiment ON public.customer_feedback USING btree (workspace_id, sentiment);


--
-- Name: ix_image_gen_workspace_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_gen_workspace_product ON public.image_generation_tasks USING btree (workspace_id, product_id);


--
-- Name: ix_image_gen_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_gen_workspace_status ON public.image_generation_tasks USING btree (workspace_id, status);


--
-- Name: ix_image_gen_workspace_use_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_gen_workspace_use_case ON public.image_generation_tasks USING btree (workspace_id, use_case);


--
-- Name: ix_image_generation_tasks_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_generation_tasks_product_id ON public.image_generation_tasks USING btree (product_id);


--
-- Name: ix_image_generation_tasks_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_generation_tasks_workspace_id ON public.image_generation_tasks USING btree (workspace_id);


--
-- Name: ix_influencer_collaborations_activity_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_influencer_collaborations_activity_plan_id ON public.influencer_collaborations USING btree (activity_plan_id);


--
-- Name: ix_influencer_collaborations_influencer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_influencer_collaborations_influencer_id ON public.influencer_collaborations USING btree (influencer_id);


--
-- Name: ix_influencer_collaborations_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_influencer_collaborations_workspace_id ON public.influencer_collaborations USING btree (workspace_id);


--
-- Name: ix_influencers_workspace_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_influencers_workspace_category ON public.influencers USING btree (workspace_id, category);


--
-- Name: ix_influencers_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_influencers_workspace_id ON public.influencers USING btree (workspace_id);


--
-- Name: ix_influencers_workspace_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_influencers_workspace_platform ON public.influencers USING btree (workspace_id, platform);


--
-- Name: ix_influencers_workspace_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_influencers_workspace_region ON public.influencers USING btree (workspace_id, region);


--
-- Name: ix_inventory_snapshots_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_snapshots_product_id ON public.inventory_snapshots USING btree (product_id);


--
-- Name: ix_inventory_workspace_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_workspace_location ON public.inventory_snapshots USING btree (workspace_id, location);


--
-- Name: ix_knowledge_entries_workspace_cat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_entries_workspace_cat ON public.product_knowledge_entries USING btree (workspace_id, category);


--
-- Name: ix_knowledge_entries_workspace_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_entries_workspace_product ON public.product_knowledge_entries USING btree (workspace_id, product_id);


--
-- Name: ix_logistics_evaluations_workspace_carrier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_evaluations_workspace_carrier ON public.logistics_ai_evaluations USING btree (workspace_id, carrier);


--
-- Name: ix_logistics_evaluations_workspace_shipment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_evaluations_workspace_shipment ON public.logistics_ai_evaluations USING btree (workspace_id, shipment_id);


--
-- Name: ix_logistics_events_shipment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_events_shipment_id ON public.logistics_events USING btree (shipment_id);


--
-- Name: ix_logistics_events_workspace_shipment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_events_workspace_shipment ON public.logistics_events USING btree (workspace_id, shipment_id);


--
-- Name: ix_logistics_pattern_runs_shipment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_pattern_runs_shipment_id ON public.logistics_pattern_runs USING btree (shipment_id);


--
-- Name: ix_logistics_pattern_runs_workspace_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_logistics_pattern_runs_workspace_type ON public.logistics_pattern_runs USING btree (workspace_id, pattern_type);


--
-- Name: ix_marketing_calibration_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_calibration_workspace_status ON public.marketing_calibration_runs USING btree (workspace_id, status);


--
-- Name: ix_marketing_experiments_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_experiments_product_id ON public.marketing_experiments USING btree (product_id);


--
-- Name: ix_marketing_experiments_workspace_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_experiments_workspace_product ON public.marketing_experiments USING btree (workspace_id, product_id);


--
-- Name: ix_marketing_experiments_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_experiments_workspace_status ON public.marketing_experiments USING btree (workspace_id, status);


--
-- Name: ix_marketing_knowledge_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_knowledge_campaign_id ON public.marketing_knowledge_entries USING btree (campaign_id);


--
-- Name: ix_marketing_knowledge_creative_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_knowledge_creative_id ON public.marketing_knowledge_entries USING btree (creative_id);


--
-- Name: ix_marketing_knowledge_entry_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_knowledge_entry_type ON public.marketing_knowledge_entries USING btree (entry_type);


--
-- Name: ix_marketing_knowledge_workspace_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_knowledge_workspace_campaign ON public.marketing_knowledge_entries USING btree (workspace_id, campaign_id);


--
-- Name: ix_marketing_knowledge_workspace_cat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_knowledge_workspace_cat ON public.marketing_knowledge_entries USING btree (workspace_id, category);


--
-- Name: ix_marketing_knowledge_workspace_creative; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_marketing_knowledge_workspace_creative ON public.marketing_knowledge_entries USING btree (workspace_id, creative_id);


--
-- Name: ix_order_items_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: ix_order_items_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_order_items_workspace_id ON public.order_items USING btree (workspace_id);


--
-- Name: ix_orders_customer_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_customer_reference_id ON public.orders USING btree (customer_reference_id);


--
-- Name: ix_orders_received_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_received_at ON public.orders USING btree (received_at DESC);


--
-- Name: ix_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_status ON public.orders USING btree (status);


--
-- Name: ix_orders_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_workspace_id ON public.orders USING btree (workspace_id);


--
-- Name: ix_product_ai_evaluations_experiment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_ai_evaluations_experiment ON public.product_ai_evaluations USING btree (experiment_id);


--
-- Name: ix_product_ai_evaluations_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_ai_evaluations_product ON public.product_ai_evaluations USING btree (product_id);


--
-- Name: ix_product_ai_evaluations_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_ai_evaluations_run ON public.product_ai_evaluations USING btree (analysis_run_id);


--
-- Name: ix_product_ai_evaluations_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_ai_evaluations_workspace_id ON public.product_ai_evaluations USING btree (workspace_id);


--
-- Name: ix_product_analysis_runs_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_analysis_runs_product_id ON public.product_analysis_runs USING btree (product_id);


--
-- Name: ix_product_analysis_runs_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_analysis_runs_workspace_id ON public.product_analysis_runs USING btree (workspace_id);


--
-- Name: ix_product_cost_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_cost_product_id ON public.product_cost USING btree (product_id);


--
-- Name: ix_product_cost_snapshots_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_cost_snapshots_product_id ON public.product_cost_snapshots USING btree (product_id);


--
-- Name: ix_product_cost_snapshots_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_cost_snapshots_workspace_id ON public.product_cost_snapshots USING btree (workspace_id);


--
-- Name: ix_product_cost_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_cost_workspace_id ON public.product_cost USING btree (workspace_id);


--
-- Name: ix_product_decisions_approval; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_decisions_approval ON public.product_decisions USING btree (workspace_id, approval_status);


--
-- Name: ix_product_decisions_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_decisions_product_id ON public.product_decisions USING btree (product_id);


--
-- Name: ix_product_decisions_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_decisions_workspace_id ON public.product_decisions USING btree (workspace_id);


--
-- Name: ix_product_experiments_decision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_experiments_decision_id ON public.product_experiments USING btree (decision_id);


--
-- Name: ix_product_experiments_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_experiments_product ON public.product_experiments USING btree (workspace_id, product_id);


--
-- Name: ix_product_experiments_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_experiments_workspace_id ON public.product_experiments USING btree (workspace_id);


--
-- Name: ix_product_knowledge_entries_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_knowledge_entries_product ON public.product_knowledge_entries USING btree (product_id);


--
-- Name: ix_product_knowledge_entries_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_knowledge_entries_type ON public.product_knowledge_entries USING btree (entry_type);


--
-- Name: ix_product_knowledge_entries_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_knowledge_entries_workspace ON public.product_knowledge_entries USING btree (workspace_id);


--
-- Name: ix_product_reviews_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_reviews_product_id ON public.product_reviews USING btree (product_id);


--
-- Name: ix_product_reviews_workspace_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_reviews_workspace_product ON public.product_reviews USING btree (workspace_id, product_id);


--
-- Name: ix_product_reviews_workspace_sentiment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_reviews_workspace_sentiment ON public.product_reviews USING btree (workspace_id, sentiment);


--
-- Name: ix_product_score_evidences_score_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_score_evidences_score_id ON public.product_score_evidences USING btree (product_score_id);


--
-- Name: ix_product_score_evidences_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_score_evidences_workspace_id ON public.product_score_evidences USING btree (workspace_id);


--
-- Name: ix_product_scores_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_scores_product_id ON public.product_scores USING btree (product_id);


--
-- Name: ix_product_scores_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_scores_workspace_id ON public.product_scores USING btree (workspace_id);


--
-- Name: ix_product_sources_captured; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_sources_captured ON public.product_sources USING btree (workspace_id, captured_at);


--
-- Name: ix_product_sources_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_sources_product_id ON public.product_sources USING btree (product_id);


--
-- Name: ix_product_sources_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_sources_workspace_id ON public.product_sources USING btree (workspace_id);


--
-- Name: ix_product_validation_cases_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_validation_cases_product_id ON public.product_validation_cases USING btree (product_id);


--
-- Name: ix_product_validation_cases_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_validation_cases_workspace_id ON public.product_validation_cases USING btree (workspace_id);


--
-- Name: ix_products_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_status ON public.products USING btree (status);


--
-- Name: ix_products_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_workspace_id ON public.products USING btree (workspace_id);


--
-- Name: ix_prompts_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompts_name ON public.prompts USING btree (name);


--
-- Name: ix_prompts_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompts_workspace_id ON public.prompts USING btree (workspace_id);


--
-- Name: ix_purchase_order_items_po_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_items_po_id ON public.purchase_order_items USING btree (purchase_order_id);


--
-- Name: ix_purchase_order_items_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_order_items_product_id ON public.purchase_order_items USING btree (product_id);


--
-- Name: ix_purchase_orders_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_supplier_id ON public.purchase_orders USING btree (supplier_id);


--
-- Name: ix_purchase_orders_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_purchase_orders_workspace_status ON public.purchase_orders USING btree (workspace_id, status);


--
-- Name: ix_recommendations_workspace_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommendations_workspace_domain ON public.business_recommendations USING btree (workspace_id, domain);


--
-- Name: ix_recommendations_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommendations_workspace_status ON public.business_recommendations USING btree (workspace_id, status);


--
-- Name: ix_refund_cases_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refund_cases_customer_id ON public.refund_cases USING btree (customer_id);


--
-- Name: ix_refund_cases_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refund_cases_order_id ON public.refund_cases USING btree (order_id);


--
-- Name: ix_refund_cases_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refund_cases_product_id ON public.refund_cases USING btree (product_id);


--
-- Name: ix_refund_cases_workspace_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refund_cases_workspace_category ON public.refund_cases USING btree (workspace_id, category);


--
-- Name: ix_refund_cases_workspace_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refund_cases_workspace_product ON public.refund_cases USING btree (workspace_id, product_id);


--
-- Name: ix_rule_execution_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rule_execution_created ON public.rule_execution_logs USING btree (workspace_id, created_at DESC);


--
-- Name: ix_rule_execution_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rule_execution_rule_id ON public.rule_execution_logs USING btree (rule_id);


--
-- Name: ix_rules_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rules_category ON public.rules USING btree (category);


--
-- Name: ix_rules_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rules_workspace_id ON public.rules USING btree (workspace_id);


--
-- Name: ix_sc_knowledge_entry_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_knowledge_entry_type ON public.supply_chain_knowledge_entries USING btree (entry_type);


--
-- Name: ix_sc_knowledge_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_knowledge_product_id ON public.supply_chain_knowledge_entries USING btree (product_id);


--
-- Name: ix_sc_knowledge_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sc_knowledge_supplier_id ON public.supply_chain_knowledge_entries USING btree (supplier_id);


--
-- Name: ix_score_calibration_runs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_score_calibration_runs_status ON public.score_calibration_runs USING btree (workspace_id, status);


--
-- Name: ix_score_calibration_runs_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_score_calibration_runs_workspace ON public.score_calibration_runs USING btree (workspace_id);


--
-- Name: ix_shipments_purchase_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shipments_purchase_order_id ON public.shipment_records USING btree (purchase_order_id);


--
-- Name: ix_shipments_workspace_carrier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shipments_workspace_carrier ON public.shipment_records USING btree (workspace_id, carrier);


--
-- Name: ix_shipments_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shipments_workspace_status ON public.shipment_records USING btree (workspace_id, status);


--
-- Name: ix_sourcing_candidates_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sourcing_candidates_product ON public.product_sourcing_candidates USING btree (workspace_id, product_id);


--
-- Name: ix_sourcing_candidates_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sourcing_candidates_workspace_id ON public.product_sourcing_candidates USING btree (workspace_id);


--
-- Name: ix_supplier_evaluations_workspace_bucket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supplier_evaluations_workspace_bucket ON public.supplier_ai_evaluations USING btree (workspace_id, confidence_bucket);


--
-- Name: ix_supplier_evaluations_workspace_supplier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supplier_evaluations_workspace_supplier ON public.supplier_ai_evaluations USING btree (workspace_id, supplier_id);


--
-- Name: ix_supplier_pattern_runs_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supplier_pattern_runs_supplier_id ON public.supplier_pattern_runs USING btree (supplier_id);


--
-- Name: ix_supplier_pattern_runs_workspace_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supplier_pattern_runs_workspace_type ON public.supplier_pattern_runs USING btree (workspace_id, pattern_type);


--
-- Name: ix_supplier_profiles_supplier_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supplier_profiles_supplier_id ON public.supplier_profiles USING btree (supplier_id);


--
-- Name: ix_supplier_profiles_workspace_risk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supplier_profiles_workspace_risk ON public.supplier_profiles USING btree (workspace_id, risk_level);


--
-- Name: ix_suppliers_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_suppliers_workspace_id ON public.suppliers USING btree (workspace_id);


--
-- Name: ix_supply_chain_calibration_workspace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supply_chain_calibration_workspace_status ON public.supply_chain_calibration_runs USING btree (workspace_id, status);


--
-- Name: ix_supply_chain_knowledge_workspace_cat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supply_chain_knowledge_workspace_cat ON public.supply_chain_knowledge_entries USING btree (workspace_id, category);


--
-- Name: ix_supply_chain_knowledge_workspace_supplier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_supply_chain_knowledge_workspace_supplier ON public.supply_chain_knowledge_entries USING btree (workspace_id, supplier_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_woocommerce_draft_payloads_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_woocommerce_draft_payloads_product_id ON public.woocommerce_draft_payloads USING btree (product_id);


--
-- Name: ix_woocommerce_draft_payloads_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_woocommerce_draft_payloads_workspace_id ON public.woocommerce_draft_payloads USING btree (workspace_id);


--
-- Name: ix_workspace_identity_links_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workspace_identity_links_workspace_id ON public.workspace_identity_links USING btree (workspace_id);


--
-- Name: uq_agent_alerts_ws_dedup_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_agent_alerts_ws_dedup_active ON public.agent_alerts USING btree (workspace_id, dedup_key) WHERE ((status)::text = ANY ((ARRAY['open'::character varying, 'acknowledged'::character varying])::text[]));


--
-- Name: uq_agent_approvals_dlq_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_agent_approvals_dlq_pending ON public.agent_approvals USING btree (workspace_id, entity_id) WHERE (((approval_type)::text = 'DLQ_REPLAY'::text) AND ((status)::text = ANY ((ARRAY['pending'::character varying, 'warning'::character varying])::text[])));


--
-- Name: uq_agent_budget_pol_ws_agent_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_agent_budget_pol_ws_agent_current ON public.agent_budget_policies USING btree (workspace_id, agent_id) WHERE is_current;


--
-- Name: uq_agent_exec_pol_ws_agent_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_agent_exec_pol_ws_agent_current ON public.agent_execution_policies USING btree (workspace_id, agent_id) WHERE is_current;


--
-- Name: uq_agent_tasks_ws_agent_idem; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_agent_tasks_ws_agent_idem ON public.agent_tasks USING btree (workspace_id, agent_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: uq_agent_versions_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_agent_versions_active ON public.agent_versions USING btree (workspace_id, agent_id) WHERE ((status)::text = 'active'::text);


--
-- Name: activity_plans activity_plans_parent_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_plans
    ADD CONSTRAINT activity_plans_parent_plan_id_fkey FOREIGN KEY (parent_plan_id) REFERENCES public.activity_plans(id) ON DELETE SET NULL;


--
-- Name: agent_alerts agent_alerts_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_alerts
    ADD CONSTRAINT agent_alerts_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_approvals agent_approvals_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_approvals
    ADD CONSTRAINT agent_approvals_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_approvals agent_approvals_target_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_approvals
    ADD CONSTRAINT agent_approvals_target_task_id_fkey FOREIGN KEY (target_task_id) REFERENCES public.agent_tasks(id) ON DELETE SET NULL;


--
-- Name: agent_budget_policies agent_budget_policies_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_budget_policies
    ADD CONSTRAINT agent_budget_policies_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_evaluations agent_evaluations_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_evaluations
    ADD CONSTRAINT agent_evaluations_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_execution_policies agent_execution_policies_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_execution_policies
    ADD CONSTRAINT agent_execution_policies_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_executions agent_executions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_executions agent_executions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.agent_tasks(id) ON DELETE SET NULL;


--
-- Name: agent_memory agent_memory_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_metrics agent_metrics_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_metrics
    ADD CONSTRAINT agent_metrics_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_task_attempts agent_task_attempts_execution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_attempts
    ADD CONSTRAINT agent_task_attempts_execution_id_fkey FOREIGN KEY (execution_id) REFERENCES public.agent_executions(id) ON DELETE SET NULL;


--
-- Name: agent_task_attempts agent_task_attempts_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_task_attempts
    ADD CONSTRAINT agent_task_attempts_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.agent_tasks(id) ON DELETE CASCADE;


--
-- Name: agent_tasks agent_tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_tasks
    ADD CONSTRAINT agent_tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: agent_versions agent_versions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT agent_versions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: campaign_ai_evaluations campaign_ai_evaluations_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_ai_evaluations
    ADD CONSTRAINT campaign_ai_evaluations_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON DELETE SET NULL;


--
-- Name: campaigns campaigns_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: creative_analysis_runs creative_analysis_runs_creative_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.creative_analysis_runs
    ADD CONSTRAINT creative_analysis_runs_creative_id_fkey FOREIGN KEY (creative_id) REFERENCES public.creative_assets(id) ON DELETE SET NULL;


--
-- Name: creative_assets creative_assets_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.creative_assets
    ADD CONSTRAINT creative_assets_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: customer_ai_evaluations customer_ai_evaluations_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ai_evaluations
    ADD CONSTRAINT customer_ai_evaluations_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_profiles(id) ON DELETE SET NULL;


--
-- Name: customer_feedback customer_feedback_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_feedback
    ADD CONSTRAINT customer_feedback_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: customer_interactions customer_interactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_interactions
    ADD CONSTRAINT customer_interactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_profiles(id) ON DELETE SET NULL;


--
-- Name: customer_interactions customer_interactions_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_interactions
    ADD CONSTRAINT customer_interactions_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: customer_knowledge_entries customer_knowledge_entries_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_knowledge_entries
    ADD CONSTRAINT customer_knowledge_entries_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_profiles(id) ON DELETE SET NULL;


--
-- Name: customer_knowledge_entries customer_knowledge_entries_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_knowledge_entries
    ADD CONSTRAINT customer_knowledge_entries_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: customer_pattern_runs customer_pattern_runs_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_pattern_runs
    ADD CONSTRAINT customer_pattern_runs_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_profiles(id) ON DELETE SET NULL;


--
-- Name: product_experiments fk_product_experiments_decision; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_experiments
    ADD CONSTRAINT fk_product_experiments_decision FOREIGN KEY (decision_id) REFERENCES public.product_decisions(id) ON DELETE SET NULL;


--
-- Name: image_generation_tasks image_generation_tasks_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_generation_tasks
    ADD CONSTRAINT image_generation_tasks_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: influencer_collaborations influencer_collaborations_activity_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.influencer_collaborations
    ADD CONSTRAINT influencer_collaborations_activity_plan_id_fkey FOREIGN KEY (activity_plan_id) REFERENCES public.activity_plans(id) ON DELETE SET NULL;


--
-- Name: influencer_collaborations influencer_collaborations_influencer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.influencer_collaborations
    ADD CONSTRAINT influencer_collaborations_influencer_id_fkey FOREIGN KEY (influencer_id) REFERENCES public.influencers(id) ON DELETE CASCADE;


--
-- Name: inventory_snapshots inventory_snapshots_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_snapshots
    ADD CONSTRAINT inventory_snapshots_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: logistics_ai_evaluations logistics_ai_evaluations_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_ai_evaluations
    ADD CONSTRAINT logistics_ai_evaluations_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipment_records(id) ON DELETE SET NULL;


--
-- Name: logistics_events logistics_events_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_events
    ADD CONSTRAINT logistics_events_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipment_records(id) ON DELETE CASCADE;


--
-- Name: logistics_pattern_runs logistics_pattern_runs_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logistics_pattern_runs
    ADD CONSTRAINT logistics_pattern_runs_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipment_records(id) ON DELETE SET NULL;


--
-- Name: marketing_experiments marketing_experiments_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_experiments
    ADD CONSTRAINT marketing_experiments_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: marketing_knowledge_entries marketing_knowledge_entries_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_knowledge_entries
    ADD CONSTRAINT marketing_knowledge_entries_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON DELETE SET NULL;


--
-- Name: marketing_knowledge_entries marketing_knowledge_entries_creative_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_knowledge_entries
    ADD CONSTRAINT marketing_knowledge_entries_creative_id_fkey FOREIGN KEY (creative_id) REFERENCES public.creative_assets(id) ON DELETE SET NULL;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: product_ai_evaluations product_ai_evaluations_analysis_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ai_evaluations
    ADD CONSTRAINT product_ai_evaluations_analysis_run_id_fkey FOREIGN KEY (analysis_run_id) REFERENCES public.product_analysis_runs(id) ON DELETE SET NULL;


--
-- Name: product_ai_evaluations product_ai_evaluations_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ai_evaluations
    ADD CONSTRAINT product_ai_evaluations_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.product_experiments(id) ON DELETE SET NULL;


--
-- Name: product_ai_evaluations product_ai_evaluations_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_ai_evaluations
    ADD CONSTRAINT product_ai_evaluations_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: product_analysis_runs product_analysis_runs_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_analysis_runs
    ADD CONSTRAINT product_analysis_runs_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: product_cost product_cost_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_cost
    ADD CONSTRAINT product_cost_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_cost_snapshots product_cost_snapshots_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_cost_snapshots
    ADD CONSTRAINT product_cost_snapshots_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_decisions product_decisions_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_decisions
    ADD CONSTRAINT product_decisions_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_experiments product_experiments_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_experiments
    ADD CONSTRAINT product_experiments_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_knowledge_entries product_knowledge_entries_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_knowledge_entries
    ADD CONSTRAINT product_knowledge_entries_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: product_reviews product_reviews_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_reviews
    ADD CONSTRAINT product_reviews_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: product_score_evidences product_score_evidences_product_score_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_score_evidences
    ADD CONSTRAINT product_score_evidences_product_score_id_fkey FOREIGN KEY (product_score_id) REFERENCES public.product_scores(id) ON DELETE CASCADE;


--
-- Name: product_scores product_scores_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_scores
    ADD CONSTRAINT product_scores_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_sources product_sources_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sources
    ADD CONSTRAINT product_sources_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: product_sources product_sources_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sources
    ADD CONSTRAINT product_sources_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- Name: product_sourcing_candidates product_sourcing_candidates_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sourcing_candidates
    ADD CONSTRAINT product_sourcing_candidates_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_sourcing_candidates product_sourcing_candidates_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sourcing_candidates
    ADD CONSTRAINT product_sourcing_candidates_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- Name: refund_cases refund_cases_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_cases
    ADD CONSTRAINT refund_cases_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer_profiles(id) ON DELETE SET NULL;


--
-- Name: refund_cases refund_cases_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_cases
    ADD CONSTRAINT refund_cases_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: refund_cases refund_cases_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_cases
    ADD CONSTRAINT refund_cases_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: shipment_records shipment_records_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_records
    ADD CONSTRAINT shipment_records_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE SET NULL;


--
-- Name: supplier_ai_evaluations supplier_ai_evaluations_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_ai_evaluations
    ADD CONSTRAINT supplier_ai_evaluations_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- Name: supplier_pattern_runs supplier_pattern_runs_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_pattern_runs
    ADD CONSTRAINT supplier_pattern_runs_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- Name: supplier_profiles supplier_profiles_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_profiles
    ADD CONSTRAINT supplier_profiles_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- Name: supply_chain_knowledge_entries supply_chain_knowledge_entries_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_chain_knowledge_entries
    ADD CONSTRAINT supply_chain_knowledge_entries_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: supply_chain_knowledge_entries supply_chain_knowledge_entries_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_chain_knowledge_entries
    ADD CONSTRAINT supply_chain_knowledge_entries_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict U6O4pAJG8iTMJBNSK4vfNr709O8aPvFPSVj8dxjxpw9xz0hg30sX7KpoJf4n7io

